# Reused Let frontend

This directory is an intentional, self-contained snapshot of the reusable frontend from the former Wordlet compiler. It is the starting point for the complete ABC frontend. The project must adapt this code instead of rebuilding the language grammar and structured representations from scratch.

## Included

- `ast.asdl` and `ir.asdl`, with their generated Lua schema modules.
- The ASDL runtime and list implementation under `vendor/`.
- Diagnostics, lexer, parser and AST reflection.
- The explicit-profile compiler entry point in `let/compiler.lua`.
- Semantic type and structured-IR helpers, plus the reused structural/type verifier in `let/check.lua`.
- Schema-driven traversal, lexical capture resolution and typed-IR analysis.
- The production typed-IR backend in `let/abc.lua`. It lowers the implemented scalar boundary to verifier-accepted ABC instead of evaluating it in Lua.
- The VM-backed static execution bridge in `let/stage.lua`. It assembles and verifies the same lowered artifact, invokes `abc_vm` under an explicit host-selected policy, and decodes exact result cells.
- Parser/schema/traversal/compiler/lowering/staging tests and the SLet source examples.

These suites are part of `make validate`. `let/compiler.lua` selects Let or SLet explicitly, builds the ASDL AST, enforces profile restrictions and indexes module declarations. `Compiler.typed` constructs verified semantic `Ir.Fn` for either language, including Let dynamic operations and captures. `Compiler.typedFile(path)` constructs a profile-checked import graph without code generation; it returns `phase="typed-ir"`, the root `unit`, dependency-inclusive `functions`, `foreigns` and `modules`, with deterministic private identities.

**Executable lowering currently supports SLet only.** `Compiler.compile` and `Compiler.compileFile` carry SLet IR through the shared revision-6 ABC backend. The latter consumes the same `typedFile` import graph; there is no second import pipeline. Let ABC lowering reports `dynamic-lowering` even for scalar-only Let programs—it does not silently reinterpret Let as SLet. The obsolete profile-5 text emitter, managed descriptors and A-only dynamic instruction emission have been removed. Parsing/typechecking/IR tests are not evidence of dynamic runtime support.

`build/abc compile/run` therefore execute `.slet`, not `.let`, at this checkpoint. `Compiler.stage` executes supported entries only through `abc_vm` under an explicit interpreted, eager or lazy policy; `Compiler.specialize` re-enters ordinary IR and the C optimizer with typed cells returned by staging. Cells, aborts, resource failures, source maps and optimizer provenance return to the compiler. Unsupported forms reject explicitly, rather than executing through Lua or another backend. Full-suite integration remains incomplete while historical bytecode fixtures are migrated.

## Deliberately excluded

The snapshot does **not** contain `wordlet/eval.lua`, `wordlet/value.lua`, `wordlet/cabi.lua`, `wordlet/lower.lua`, `wordlet/jit.lua`, or the old compiler facade. ABC does not retain the Lua evaluator or direct source-to-C backend. User-authored executable computation, including compile-time computation, must lower to verified ABC bytecode and run through `abc_vm`.

Remaining frontend work includes recursive/exported types, methods and keyed supply, nested words, general block-bodied lambdas, raw-pointer source operations, `extern`/`defer`, module initialization/storage, managed/address-bearing sum ABIs, and completed-program ownership/provenance verification. SLet borrow proofs must remain separate from Let profile-5 GC reachability.

## Provenance

- Source checkout: `../wordlet.lua`
- Base revision: `4a4cbc023a4325be8f633734cca1653f7833b010`
- Snapshot time: `2026-10-05T05:53:23Z`
- Intentionally included source-worktree modifications: `ir.asdl`, `tests/schemas.lua`, `tools/embed.lua`, `wordlet/analysis.lua`, and `wordlet/schema/ir.lua`.
- Subsequent reuse: the profile-neutral structural/type portion of `wordlet/check.lua` was ported as `let/check.lua`; its evaluator-coupled lifetime entry was not copied.

The copied files are authoritative inside this repository. Build and validation do not read the sibling checkout. See `LICENSE.wordlet` and `vendor/LICENSE` for the retained license notices.

## ASDL workflow

`ast.asdl` and `ir.asdl` are the sources of truth. After changing either schema, regenerate the embedded modules and run the tests:

```sh
cd frontend
luajit tools/embed.lua
luajit tests/schemas.lua
luajit tests/walk.lua
luajit tests/parse.lua
luajit tests/compiler.lua
luajit tests/lowering.lua
luajit tests/staging.lua
```

Use the same AST for `.slet` and `.let`. The host-selected source profile controls later typing, ownership and lowering; the parser does not infer a profile from a filename.

