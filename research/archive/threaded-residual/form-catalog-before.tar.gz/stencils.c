#include <stdint.h>
#include <math.h>
#include <stddef.h>
typedef uint64_t abc_value;
#define ABC_JIT_CC __attribute__((preserve_none))
#define ABC_JIT_ARGS abc_value *asp, abc_value *bsp, abc_value *csp, abc_value r0, abc_value r1, abc_value r2, abc_value r3, abc_value r4, abc_value r5, abc_value r6, abc_value r7
#define ABC_JIT_PASS asp,bsp,csp,r0,r1,r2,r3,r4,r5,r6,r7
typedef ABC_JIT_CC abc_value (*abc_jit_fn)(ABC_JIT_ARGS);
typedef abc_value (*abc_lazy_prepare_fn)(abc_value);
typedef abc_value (*abc_resolve_fn)(abc_value,abc_value,uintptr_t,uintptr_t,uintptr_t,abc_value *);
typedef unsigned (*abc_foreign_bridge)(const void *,void (*)(void),const abc_value *,abc_value *);
typedef void *(*abc_memory_copy_fn)(void *,const void *,size_t);
#define TAIL __attribute__((musttail))
extern ABC_JIT_CC abc_value HOLE_NEXT(ABC_JIT_ARGS);
extern ABC_JIT_CC abc_value HOLE_TAKEN(ABC_JIT_ARGS);
extern char HOLE_IMM[], HOLE_IMM2[], HOLE_BIAS[], HOLE_FINAL[], HOLE_STATE[], HOLE_ERROR[];
static __attribute__((always_inline)) inline int64_t abc_signed(abc_value x){ return x<=INT64_MAX?(int64_t)x:-1-(int64_t)(UINT64_MAX-x); }
static __attribute__((always_inline)) inline abc_value vm_sar(abc_value x,abc_value n){ return n>=64?(x>>63?UINT64_MAX:0):(n?((x>>n)|(x>>63?UINT64_MAX<<(64-n):0)):x); }
static __attribute__((always_inline)) inline abc_value jit_pow(abc_value x,abc_value n){ abc_value r=1; while(n){if(n&1)r*=x;x*=x;n>>=1;}return r; }
static __attribute__((always_inline)) inline int32_t abc_i32_from_u64(abc_value x){ uint32_t lo=(uint32_t)x; return lo<UINT32_C(0x80000000)?(int32_t)lo:(int32_t)abc_signed((abc_value)lo|UINT64_C(0xffffffff00000000)); }
typedef union { abc_value u; double d; } jit_float_cast;
static __attribute__((always_inline)) inline double vm_float(abc_value x){jit_float_cast v={.u=x};return v.d;}
static __attribute__((always_inline)) inline abc_value vm_float_bits(double d){jit_float_cast v={.d=d};return v.u;}
static __attribute__((always_inline)) inline abc_value vm_fadd(abc_value x,abc_value y){return vm_float_bits(vm_float(x)+vm_float(y));}
static __attribute__((always_inline)) inline abc_value vm_fsub(abc_value x,abc_value y){return vm_float_bits(vm_float(x)-vm_float(y));}
static __attribute__((always_inline)) inline abc_value vm_fmul(abc_value x,abc_value y){return vm_float_bits(vm_float(x)*vm_float(y));}
static __attribute__((always_inline)) inline abc_value vm_fdiv(abc_value x,abc_value y){return vm_float_bits(vm_float(x)/vm_float(y));}
static __attribute__((always_inline)) inline int vm_flt(abc_value x,abc_value y){return vm_float(x)<vm_float(y);}
static __attribute__((always_inline)) inline int vm_fle(abc_value x,abc_value y){return vm_float(x)<=vm_float(y);}
static __attribute__((always_inline)) inline int vm_feq(abc_value x,abc_value y){return vm_float(x)==vm_float(y);}
static __attribute__((always_inline)) inline abc_value vm_u2f_bits(abc_value v,abc_value sign){if(!v)return sign;unsigned p=63u-(unsigned)__builtin_clzll(v);abc_value q;if(p<=52)q=v<<(52-p);else{unsigned s=p-52;abc_value rem=v&((UINT64_C(1)<<s)-1),half=UINT64_C(1)<<(s-1);q=v>>s;if(rem>half||(rem==half&&(q&1))){q++;if(q==UINT64_C(1)<<53){q>>=1;p++;}}}return sign|((abc_value)(p+1023)<<52)|(q&UINT64_C(0x000fffffffffffff));}
static __attribute__((always_inline)) inline abc_value vm_i2fs(abc_value x){abc_value s=x>>63?UINT64_C(0x8000000000000000):0;return vm_u2f_bits(s?0-x:x,s);}
static __attribute__((always_inline)) inline abc_value vm_i2fu(abc_value x){return vm_u2f_bits(x,0);}
static __attribute__((always_inline)) inline abc_value jit_error(void){abc_value x;__asm__("movabsq $HOLE_ERROR,%0":"=r"(x));return x;}
static __attribute__((always_inline)) inline abc_value jit_final(void){abc_value x;__asm__("movabsq $HOLE_FINAL,%0":"=r"(x));return x;}
#define NEXT TAIL return HOLE_NEXT(ABC_JIT_PASS);
ABC_JIT_CC abc_value const_0(ABC_JIT_ARGS) { __asm__("movabsq $HOLE_IMM,%0":"=r"(r0)); NEXT }
ABC_JIT_CC abc_value mov_0_1(ABC_JIT_ARGS) { r0=r1; NEXT }
ABC_JIT_CC abc_value mov_0_2(ABC_JIT_ARGS) { r0=r2; NEXT }
ABC_JIT_CC abc_value mov_0_3(ABC_JIT_ARGS) { r0=r3; NEXT }
ABC_JIT_CC abc_value mov_0_4(ABC_JIT_ARGS) { r0=r4; NEXT }
ABC_JIT_CC abc_value mov_0_5(ABC_JIT_ARGS) { r0=r5; NEXT }
ABC_JIT_CC abc_value mov_0_6(ABC_JIT_ARGS) { r0=r6; NEXT }
ABC_JIT_CC abc_value mov_0_7(ABC_JIT_ARGS) { r0=r7; NEXT }
ABC_JIT_CC abc_value const_1(ABC_JIT_ARGS) { __asm__("movabsq $HOLE_IMM,%0":"=r"(r1)); NEXT }
ABC_JIT_CC abc_value mov_1_0(ABC_JIT_ARGS) { r1=r0; NEXT }
ABC_JIT_CC abc_value mov_1_2(ABC_JIT_ARGS) { r1=r2; NEXT }
ABC_JIT_CC abc_value mov_1_3(ABC_JIT_ARGS) { r1=r3; NEXT }
ABC_JIT_CC abc_value mov_1_4(ABC_JIT_ARGS) { r1=r4; NEXT }
ABC_JIT_CC abc_value mov_1_5(ABC_JIT_ARGS) { r1=r5; NEXT }
ABC_JIT_CC abc_value mov_1_6(ABC_JIT_ARGS) { r1=r6; NEXT }
ABC_JIT_CC abc_value mov_1_7(ABC_JIT_ARGS) { r1=r7; NEXT }
ABC_JIT_CC abc_value const_2(ABC_JIT_ARGS) { __asm__("movabsq $HOLE_IMM,%0":"=r"(r2)); NEXT }
ABC_JIT_CC abc_value mov_2_0(ABC_JIT_ARGS) { r2=r0; NEXT }
ABC_JIT_CC abc_value mov_2_1(ABC_JIT_ARGS) { r2=r1; NEXT }
ABC_JIT_CC abc_value mov_2_3(ABC_JIT_ARGS) { r2=r3; NEXT }
ABC_JIT_CC abc_value mov_2_4(ABC_JIT_ARGS) { r2=r4; NEXT }
ABC_JIT_CC abc_value mov_2_5(ABC_JIT_ARGS) { r2=r5; NEXT }
ABC_JIT_CC abc_value mov_2_6(ABC_JIT_ARGS) { r2=r6; NEXT }
ABC_JIT_CC abc_value mov_2_7(ABC_JIT_ARGS) { r2=r7; NEXT }
ABC_JIT_CC abc_value const_3(ABC_JIT_ARGS) { __asm__("movabsq $HOLE_IMM,%0":"=r"(r3)); NEXT }
ABC_JIT_CC abc_value mov_3_0(ABC_JIT_ARGS) { r3=r0; NEXT }
ABC_JIT_CC abc_value mov_3_1(ABC_JIT_ARGS) { r3=r1; NEXT }
ABC_JIT_CC abc_value mov_3_2(ABC_JIT_ARGS) { r3=r2; NEXT }
ABC_JIT_CC abc_value mov_3_4(ABC_JIT_ARGS) { r3=r4; NEXT }
ABC_JIT_CC abc_value mov_3_5(ABC_JIT_ARGS) { r3=r5; NEXT }
ABC_JIT_CC abc_value mov_3_6(ABC_JIT_ARGS) { r3=r6; NEXT }
ABC_JIT_CC abc_value mov_3_7(ABC_JIT_ARGS) { r3=r7; NEXT }
ABC_JIT_CC abc_value const_4(ABC_JIT_ARGS) { __asm__("movabsq $HOLE_IMM,%0":"=r"(r4)); NEXT }
ABC_JIT_CC abc_value mov_4_0(ABC_JIT_ARGS) { r4=r0; NEXT }
ABC_JIT_CC abc_value mov_4_1(ABC_JIT_ARGS) { r4=r1; NEXT }
ABC_JIT_CC abc_value mov_4_2(ABC_JIT_ARGS) { r4=r2; NEXT }
ABC_JIT_CC abc_value mov_4_3(ABC_JIT_ARGS) { r4=r3; NEXT }
ABC_JIT_CC abc_value mov_4_5(ABC_JIT_ARGS) { r4=r5; NEXT }
ABC_JIT_CC abc_value mov_4_6(ABC_JIT_ARGS) { r4=r6; NEXT }
ABC_JIT_CC abc_value mov_4_7(ABC_JIT_ARGS) { r4=r7; NEXT }
ABC_JIT_CC abc_value const_5(ABC_JIT_ARGS) { __asm__("movabsq $HOLE_IMM,%0":"=r"(r5)); NEXT }
ABC_JIT_CC abc_value mov_5_0(ABC_JIT_ARGS) { r5=r0; NEXT }
ABC_JIT_CC abc_value mov_5_1(ABC_JIT_ARGS) { r5=r1; NEXT }
ABC_JIT_CC abc_value mov_5_2(ABC_JIT_ARGS) { r5=r2; NEXT }
ABC_JIT_CC abc_value mov_5_3(ABC_JIT_ARGS) { r5=r3; NEXT }
ABC_JIT_CC abc_value mov_5_4(ABC_JIT_ARGS) { r5=r4; NEXT }
ABC_JIT_CC abc_value mov_5_6(ABC_JIT_ARGS) { r5=r6; NEXT }
ABC_JIT_CC abc_value mov_5_7(ABC_JIT_ARGS) { r5=r7; NEXT }
ABC_JIT_CC abc_value const_6(ABC_JIT_ARGS) { __asm__("movabsq $HOLE_IMM,%0":"=r"(r6)); NEXT }
ABC_JIT_CC abc_value mov_6_0(ABC_JIT_ARGS) { r6=r0; NEXT }
ABC_JIT_CC abc_value mov_6_1(ABC_JIT_ARGS) { r6=r1; NEXT }
ABC_JIT_CC abc_value mov_6_2(ABC_JIT_ARGS) { r6=r2; NEXT }
ABC_JIT_CC abc_value mov_6_3(ABC_JIT_ARGS) { r6=r3; NEXT }
ABC_JIT_CC abc_value mov_6_4(ABC_JIT_ARGS) { r6=r4; NEXT }
ABC_JIT_CC abc_value mov_6_5(ABC_JIT_ARGS) { r6=r5; NEXT }
ABC_JIT_CC abc_value mov_6_7(ABC_JIT_ARGS) { r6=r7; NEXT }
ABC_JIT_CC abc_value const_7(ABC_JIT_ARGS) { __asm__("movabsq $HOLE_IMM,%0":"=r"(r7)); NEXT }
ABC_JIT_CC abc_value mov_7_0(ABC_JIT_ARGS) { r7=r0; NEXT }
ABC_JIT_CC abc_value mov_7_1(ABC_JIT_ARGS) { r7=r1; NEXT }
ABC_JIT_CC abc_value mov_7_2(ABC_JIT_ARGS) { r7=r2; NEXT }
ABC_JIT_CC abc_value mov_7_3(ABC_JIT_ARGS) { r7=r3; NEXT }
ABC_JIT_CC abc_value mov_7_4(ABC_JIT_ARGS) { r7=r4; NEXT }
ABC_JIT_CC abc_value mov_7_5(ABC_JIT_ARGS) { r7=r5; NEXT }
ABC_JIT_CC abc_value mov_7_6(ABC_JIT_ARGS) { r7=r6; NEXT }
ABC_JIT_CC abc_value add_0_0(ABC_JIT_ARGS) { r0=r0+r0; NEXT }
ABC_JIT_CC abc_value add_0_1(ABC_JIT_ARGS) { r0=r0+r1; NEXT }
ABC_JIT_CC abc_value add_0_2(ABC_JIT_ARGS) { r0=r0+r2; NEXT }
ABC_JIT_CC abc_value add_0_3(ABC_JIT_ARGS) { r0=r0+r3; NEXT }
ABC_JIT_CC abc_value add_0_4(ABC_JIT_ARGS) { r0=r0+r4; NEXT }
ABC_JIT_CC abc_value add_0_5(ABC_JIT_ARGS) { r0=r0+r5; NEXT }
ABC_JIT_CC abc_value add_0_6(ABC_JIT_ARGS) { r0=r0+r6; NEXT }
ABC_JIT_CC abc_value add_0_7(ABC_JIT_ARGS) { r0=r0+r7; NEXT }
ABC_JIT_CC abc_value add_1_0(ABC_JIT_ARGS) { r1=r1+r0; NEXT }
ABC_JIT_CC abc_value add_1_1(ABC_JIT_ARGS) { r1=r1+r1; NEXT }
ABC_JIT_CC abc_value add_1_2(ABC_JIT_ARGS) { r1=r1+r2; NEXT }
ABC_JIT_CC abc_value add_1_3(ABC_JIT_ARGS) { r1=r1+r3; NEXT }
ABC_JIT_CC abc_value add_1_4(ABC_JIT_ARGS) { r1=r1+r4; NEXT }
ABC_JIT_CC abc_value add_1_5(ABC_JIT_ARGS) { r1=r1+r5; NEXT }
ABC_JIT_CC abc_value add_1_6(ABC_JIT_ARGS) { r1=r1+r6; NEXT }
ABC_JIT_CC abc_value add_1_7(ABC_JIT_ARGS) { r1=r1+r7; NEXT }
ABC_JIT_CC abc_value add_2_0(ABC_JIT_ARGS) { r2=r2+r0; NEXT }
ABC_JIT_CC abc_value add_2_1(ABC_JIT_ARGS) { r2=r2+r1; NEXT }
ABC_JIT_CC abc_value add_2_2(ABC_JIT_ARGS) { r2=r2+r2; NEXT }
ABC_JIT_CC abc_value add_2_3(ABC_JIT_ARGS) { r2=r2+r3; NEXT }
ABC_JIT_CC abc_value add_2_4(ABC_JIT_ARGS) { r2=r2+r4; NEXT }
ABC_JIT_CC abc_value add_2_5(ABC_JIT_ARGS) { r2=r2+r5; NEXT }
ABC_JIT_CC abc_value add_2_6(ABC_JIT_ARGS) { r2=r2+r6; NEXT }
ABC_JIT_CC abc_value add_2_7(ABC_JIT_ARGS) { r2=r2+r7; NEXT }
ABC_JIT_CC abc_value add_3_0(ABC_JIT_ARGS) { r3=r3+r0; NEXT }
ABC_JIT_CC abc_value add_3_1(ABC_JIT_ARGS) { r3=r3+r1; NEXT }
ABC_JIT_CC abc_value add_3_2(ABC_JIT_ARGS) { r3=r3+r2; NEXT }
ABC_JIT_CC abc_value add_3_3(ABC_JIT_ARGS) { r3=r3+r3; NEXT }
ABC_JIT_CC abc_value add_3_4(ABC_JIT_ARGS) { r3=r3+r4; NEXT }
ABC_JIT_CC abc_value add_3_5(ABC_JIT_ARGS) { r3=r3+r5; NEXT }
ABC_JIT_CC abc_value add_3_6(ABC_JIT_ARGS) { r3=r3+r6; NEXT }
ABC_JIT_CC abc_value add_3_7(ABC_JIT_ARGS) { r3=r3+r7; NEXT }
ABC_JIT_CC abc_value add_4_0(ABC_JIT_ARGS) { r4=r4+r0; NEXT }
ABC_JIT_CC abc_value add_4_1(ABC_JIT_ARGS) { r4=r4+r1; NEXT }
ABC_JIT_CC abc_value add_4_2(ABC_JIT_ARGS) { r4=r4+r2; NEXT }
ABC_JIT_CC abc_value add_4_3(ABC_JIT_ARGS) { r4=r4+r3; NEXT }
ABC_JIT_CC abc_value add_4_4(ABC_JIT_ARGS) { r4=r4+r4; NEXT }
ABC_JIT_CC abc_value add_4_5(ABC_JIT_ARGS) { r4=r4+r5; NEXT }
ABC_JIT_CC abc_value add_4_6(ABC_JIT_ARGS) { r4=r4+r6; NEXT }
ABC_JIT_CC abc_value add_4_7(ABC_JIT_ARGS) { r4=r4+r7; NEXT }
ABC_JIT_CC abc_value add_5_0(ABC_JIT_ARGS) { r5=r5+r0; NEXT }
ABC_JIT_CC abc_value add_5_1(ABC_JIT_ARGS) { r5=r5+r1; NEXT }
ABC_JIT_CC abc_value add_5_2(ABC_JIT_ARGS) { r5=r5+r2; NEXT }
ABC_JIT_CC abc_value add_5_3(ABC_JIT_ARGS) { r5=r5+r3; NEXT }
ABC_JIT_CC abc_value add_5_4(ABC_JIT_ARGS) { r5=r5+r4; NEXT }
ABC_JIT_CC abc_value add_5_5(ABC_JIT_ARGS) { r5=r5+r5; NEXT }
ABC_JIT_CC abc_value add_5_6(ABC_JIT_ARGS) { r5=r5+r6; NEXT }
ABC_JIT_CC abc_value add_5_7(ABC_JIT_ARGS) { r5=r5+r7; NEXT }
ABC_JIT_CC abc_value add_6_0(ABC_JIT_ARGS) { r6=r6+r0; NEXT }
ABC_JIT_CC abc_value add_6_1(ABC_JIT_ARGS) { r6=r6+r1; NEXT }
ABC_JIT_CC abc_value add_6_2(ABC_JIT_ARGS) { r6=r6+r2; NEXT }
ABC_JIT_CC abc_value add_6_3(ABC_JIT_ARGS) { r6=r6+r3; NEXT }
ABC_JIT_CC abc_value add_6_4(ABC_JIT_ARGS) { r6=r6+r4; NEXT }
ABC_JIT_CC abc_value add_6_5(ABC_JIT_ARGS) { r6=r6+r5; NEXT }
ABC_JIT_CC abc_value add_6_6(ABC_JIT_ARGS) { r6=r6+r6; NEXT }
ABC_JIT_CC abc_value add_6_7(ABC_JIT_ARGS) { r6=r6+r7; NEXT }
ABC_JIT_CC abc_value add_7_0(ABC_JIT_ARGS) { r7=r7+r0; NEXT }
ABC_JIT_CC abc_value add_7_1(ABC_JIT_ARGS) { r7=r7+r1; NEXT }
ABC_JIT_CC abc_value add_7_2(ABC_JIT_ARGS) { r7=r7+r2; NEXT }
ABC_JIT_CC abc_value add_7_3(ABC_JIT_ARGS) { r7=r7+r3; NEXT }
ABC_JIT_CC abc_value add_7_4(ABC_JIT_ARGS) { r7=r7+r4; NEXT }
ABC_JIT_CC abc_value add_7_5(ABC_JIT_ARGS) { r7=r7+r5; NEXT }
ABC_JIT_CC abc_value add_7_6(ABC_JIT_ARGS) { r7=r7+r6; NEXT }
ABC_JIT_CC abc_value add_7_7(ABC_JIT_ARGS) { r7=r7+r7; NEXT }
ABC_JIT_CC abc_value sub_0_0(ABC_JIT_ARGS) { r0=r0-r0; NEXT }
ABC_JIT_CC abc_value sub_0_1(ABC_JIT_ARGS) { r0=r0-r1; NEXT }
ABC_JIT_CC abc_value sub_0_2(ABC_JIT_ARGS) { r0=r0-r2; NEXT }
ABC_JIT_CC abc_value sub_0_3(ABC_JIT_ARGS) { r0=r0-r3; NEXT }
ABC_JIT_CC abc_value sub_0_4(ABC_JIT_ARGS) { r0=r0-r4; NEXT }
ABC_JIT_CC abc_value sub_0_5(ABC_JIT_ARGS) { r0=r0-r5; NEXT }
ABC_JIT_CC abc_value sub_0_6(ABC_JIT_ARGS) { r0=r0-r6; NEXT }
ABC_JIT_CC abc_value sub_0_7(ABC_JIT_ARGS) { r0=r0-r7; NEXT }
ABC_JIT_CC abc_value sub_1_0(ABC_JIT_ARGS) { r1=r1-r0; NEXT }
ABC_JIT_CC abc_value sub_1_1(ABC_JIT_ARGS) { r1=r1-r1; NEXT }
ABC_JIT_CC abc_value sub_1_2(ABC_JIT_ARGS) { r1=r1-r2; NEXT }
ABC_JIT_CC abc_value sub_1_3(ABC_JIT_ARGS) { r1=r1-r3; NEXT }
ABC_JIT_CC abc_value sub_1_4(ABC_JIT_ARGS) { r1=r1-r4; NEXT }
ABC_JIT_CC abc_value sub_1_5(ABC_JIT_ARGS) { r1=r1-r5; NEXT }
ABC_JIT_CC abc_value sub_1_6(ABC_JIT_ARGS) { r1=r1-r6; NEXT }
ABC_JIT_CC abc_value sub_1_7(ABC_JIT_ARGS) { r1=r1-r7; NEXT }
ABC_JIT_CC abc_value sub_2_0(ABC_JIT_ARGS) { r2=r2-r0; NEXT }
ABC_JIT_CC abc_value sub_2_1(ABC_JIT_ARGS) { r2=r2-r1; NEXT }
ABC_JIT_CC abc_value sub_2_2(ABC_JIT_ARGS) { r2=r2-r2; NEXT }
ABC_JIT_CC abc_value sub_2_3(ABC_JIT_ARGS) { r2=r2-r3; NEXT }
ABC_JIT_CC abc_value sub_2_4(ABC_JIT_ARGS) { r2=r2-r4; NEXT }
ABC_JIT_CC abc_value sub_2_5(ABC_JIT_ARGS) { r2=r2-r5; NEXT }
ABC_JIT_CC abc_value sub_2_6(ABC_JIT_ARGS) { r2=r2-r6; NEXT }
ABC_JIT_CC abc_value sub_2_7(ABC_JIT_ARGS) { r2=r2-r7; NEXT }
ABC_JIT_CC abc_value sub_3_0(ABC_JIT_ARGS) { r3=r3-r0; NEXT }
ABC_JIT_CC abc_value sub_3_1(ABC_JIT_ARGS) { r3=r3-r1; NEXT }
ABC_JIT_CC abc_value sub_3_2(ABC_JIT_ARGS) { r3=r3-r2; NEXT }
ABC_JIT_CC abc_value sub_3_3(ABC_JIT_ARGS) { r3=r3-r3; NEXT }
ABC_JIT_CC abc_value sub_3_4(ABC_JIT_ARGS) { r3=r3-r4; NEXT }
ABC_JIT_CC abc_value sub_3_5(ABC_JIT_ARGS) { r3=r3-r5; NEXT }
ABC_JIT_CC abc_value sub_3_6(ABC_JIT_ARGS) { r3=r3-r6; NEXT }
ABC_JIT_CC abc_value sub_3_7(ABC_JIT_ARGS) { r3=r3-r7; NEXT }
ABC_JIT_CC abc_value sub_4_0(ABC_JIT_ARGS) { r4=r4-r0; NEXT }
ABC_JIT_CC abc_value sub_4_1(ABC_JIT_ARGS) { r4=r4-r1; NEXT }
ABC_JIT_CC abc_value sub_4_2(ABC_JIT_ARGS) { r4=r4-r2; NEXT }
ABC_JIT_CC abc_value sub_4_3(ABC_JIT_ARGS) { r4=r4-r3; NEXT }
ABC_JIT_CC abc_value sub_4_4(ABC_JIT_ARGS) { r4=r4-r4; NEXT }
ABC_JIT_CC abc_value sub_4_5(ABC_JIT_ARGS) { r4=r4-r5; NEXT }
ABC_JIT_CC abc_value sub_4_6(ABC_JIT_ARGS) { r4=r4-r6; NEXT }
ABC_JIT_CC abc_value sub_4_7(ABC_JIT_ARGS) { r4=r4-r7; NEXT }
ABC_JIT_CC abc_value sub_5_0(ABC_JIT_ARGS) { r5=r5-r0; NEXT }
ABC_JIT_CC abc_value sub_5_1(ABC_JIT_ARGS) { r5=r5-r1; NEXT }
ABC_JIT_CC abc_value sub_5_2(ABC_JIT_ARGS) { r5=r5-r2; NEXT }
ABC_JIT_CC abc_value sub_5_3(ABC_JIT_ARGS) { r5=r5-r3; NEXT }
ABC_JIT_CC abc_value sub_5_4(ABC_JIT_ARGS) { r5=r5-r4; NEXT }
ABC_JIT_CC abc_value sub_5_5(ABC_JIT_ARGS) { r5=r5-r5; NEXT }
ABC_JIT_CC abc_value sub_5_6(ABC_JIT_ARGS) { r5=r5-r6; NEXT }
ABC_JIT_CC abc_value sub_5_7(ABC_JIT_ARGS) { r5=r5-r7; NEXT }
ABC_JIT_CC abc_value sub_6_0(ABC_JIT_ARGS) { r6=r6-r0; NEXT }
ABC_JIT_CC abc_value sub_6_1(ABC_JIT_ARGS) { r6=r6-r1; NEXT }
ABC_JIT_CC abc_value sub_6_2(ABC_JIT_ARGS) { r6=r6-r2; NEXT }
ABC_JIT_CC abc_value sub_6_3(ABC_JIT_ARGS) { r6=r6-r3; NEXT }
ABC_JIT_CC abc_value sub_6_4(ABC_JIT_ARGS) { r6=r6-r4; NEXT }
ABC_JIT_CC abc_value sub_6_5(ABC_JIT_ARGS) { r6=r6-r5; NEXT }
ABC_JIT_CC abc_value sub_6_6(ABC_JIT_ARGS) { r6=r6-r6; NEXT }
ABC_JIT_CC abc_value sub_6_7(ABC_JIT_ARGS) { r6=r6-r7; NEXT }
ABC_JIT_CC abc_value sub_7_0(ABC_JIT_ARGS) { r7=r7-r0; NEXT }
ABC_JIT_CC abc_value sub_7_1(ABC_JIT_ARGS) { r7=r7-r1; NEXT }
ABC_JIT_CC abc_value sub_7_2(ABC_JIT_ARGS) { r7=r7-r2; NEXT }
ABC_JIT_CC abc_value sub_7_3(ABC_JIT_ARGS) { r7=r7-r3; NEXT }
ABC_JIT_CC abc_value sub_7_4(ABC_JIT_ARGS) { r7=r7-r4; NEXT }
ABC_JIT_CC abc_value sub_7_5(ABC_JIT_ARGS) { r7=r7-r5; NEXT }
ABC_JIT_CC abc_value sub_7_6(ABC_JIT_ARGS) { r7=r7-r6; NEXT }
ABC_JIT_CC abc_value sub_7_7(ABC_JIT_ARGS) { r7=r7-r7; NEXT }
ABC_JIT_CC abc_value mul_0_0(ABC_JIT_ARGS) { r0=r0*r0; NEXT }
ABC_JIT_CC abc_value mul_0_1(ABC_JIT_ARGS) { r0=r0*r1; NEXT }
ABC_JIT_CC abc_value mul_0_2(ABC_JIT_ARGS) { r0=r0*r2; NEXT }
ABC_JIT_CC abc_value mul_0_3(ABC_JIT_ARGS) { r0=r0*r3; NEXT }
ABC_JIT_CC abc_value mul_0_4(ABC_JIT_ARGS) { r0=r0*r4; NEXT }
ABC_JIT_CC abc_value mul_0_5(ABC_JIT_ARGS) { r0=r0*r5; NEXT }
ABC_JIT_CC abc_value mul_0_6(ABC_JIT_ARGS) { r0=r0*r6; NEXT }
ABC_JIT_CC abc_value mul_0_7(ABC_JIT_ARGS) { r0=r0*r7; NEXT }
ABC_JIT_CC abc_value mul_1_0(ABC_JIT_ARGS) { r1=r1*r0; NEXT }
ABC_JIT_CC abc_value mul_1_1(ABC_JIT_ARGS) { r1=r1*r1; NEXT }
ABC_JIT_CC abc_value mul_1_2(ABC_JIT_ARGS) { r1=r1*r2; NEXT }
ABC_JIT_CC abc_value mul_1_3(ABC_JIT_ARGS) { r1=r1*r3; NEXT }
ABC_JIT_CC abc_value mul_1_4(ABC_JIT_ARGS) { r1=r1*r4; NEXT }
ABC_JIT_CC abc_value mul_1_5(ABC_JIT_ARGS) { r1=r1*r5; NEXT }
ABC_JIT_CC abc_value mul_1_6(ABC_JIT_ARGS) { r1=r1*r6; NEXT }
ABC_JIT_CC abc_value mul_1_7(ABC_JIT_ARGS) { r1=r1*r7; NEXT }
ABC_JIT_CC abc_value mul_2_0(ABC_JIT_ARGS) { r2=r2*r0; NEXT }
ABC_JIT_CC abc_value mul_2_1(ABC_JIT_ARGS) { r2=r2*r1; NEXT }
ABC_JIT_CC abc_value mul_2_2(ABC_JIT_ARGS) { r2=r2*r2; NEXT }
ABC_JIT_CC abc_value mul_2_3(ABC_JIT_ARGS) { r2=r2*r3; NEXT }
ABC_JIT_CC abc_value mul_2_4(ABC_JIT_ARGS) { r2=r2*r4; NEXT }
ABC_JIT_CC abc_value mul_2_5(ABC_JIT_ARGS) { r2=r2*r5; NEXT }
ABC_JIT_CC abc_value mul_2_6(ABC_JIT_ARGS) { r2=r2*r6; NEXT }
ABC_JIT_CC abc_value mul_2_7(ABC_JIT_ARGS) { r2=r2*r7; NEXT }
ABC_JIT_CC abc_value mul_3_0(ABC_JIT_ARGS) { r3=r3*r0; NEXT }
ABC_JIT_CC abc_value mul_3_1(ABC_JIT_ARGS) { r3=r3*r1; NEXT }
ABC_JIT_CC abc_value mul_3_2(ABC_JIT_ARGS) { r3=r3*r2; NEXT }
ABC_JIT_CC abc_value mul_3_3(ABC_JIT_ARGS) { r3=r3*r3; NEXT }
ABC_JIT_CC abc_value mul_3_4(ABC_JIT_ARGS) { r3=r3*r4; NEXT }
ABC_JIT_CC abc_value mul_3_5(ABC_JIT_ARGS) { r3=r3*r5; NEXT }
ABC_JIT_CC abc_value mul_3_6(ABC_JIT_ARGS) { r3=r3*r6; NEXT }
ABC_JIT_CC abc_value mul_3_7(ABC_JIT_ARGS) { r3=r3*r7; NEXT }
ABC_JIT_CC abc_value mul_4_0(ABC_JIT_ARGS) { r4=r4*r0; NEXT }
ABC_JIT_CC abc_value mul_4_1(ABC_JIT_ARGS) { r4=r4*r1; NEXT }
ABC_JIT_CC abc_value mul_4_2(ABC_JIT_ARGS) { r4=r4*r2; NEXT }
ABC_JIT_CC abc_value mul_4_3(ABC_JIT_ARGS) { r4=r4*r3; NEXT }
ABC_JIT_CC abc_value mul_4_4(ABC_JIT_ARGS) { r4=r4*r4; NEXT }
ABC_JIT_CC abc_value mul_4_5(ABC_JIT_ARGS) { r4=r4*r5; NEXT }
ABC_JIT_CC abc_value mul_4_6(ABC_JIT_ARGS) { r4=r4*r6; NEXT }
ABC_JIT_CC abc_value mul_4_7(ABC_JIT_ARGS) { r4=r4*r7; NEXT }
ABC_JIT_CC abc_value mul_5_0(ABC_JIT_ARGS) { r5=r5*r0; NEXT }
ABC_JIT_CC abc_value mul_5_1(ABC_JIT_ARGS) { r5=r5*r1; NEXT }
ABC_JIT_CC abc_value mul_5_2(ABC_JIT_ARGS) { r5=r5*r2; NEXT }
ABC_JIT_CC abc_value mul_5_3(ABC_JIT_ARGS) { r5=r5*r3; NEXT }
ABC_JIT_CC abc_value mul_5_4(ABC_JIT_ARGS) { r5=r5*r4; NEXT }
ABC_JIT_CC abc_value mul_5_5(ABC_JIT_ARGS) { r5=r5*r5; NEXT }
ABC_JIT_CC abc_value mul_5_6(ABC_JIT_ARGS) { r5=r5*r6; NEXT }
ABC_JIT_CC abc_value mul_5_7(ABC_JIT_ARGS) { r5=r5*r7; NEXT }
ABC_JIT_CC abc_value mul_6_0(ABC_JIT_ARGS) { r6=r6*r0; NEXT }
ABC_JIT_CC abc_value mul_6_1(ABC_JIT_ARGS) { r6=r6*r1; NEXT }
ABC_JIT_CC abc_value mul_6_2(ABC_JIT_ARGS) { r6=r6*r2; NEXT }
ABC_JIT_CC abc_value mul_6_3(ABC_JIT_ARGS) { r6=r6*r3; NEXT }
ABC_JIT_CC abc_value mul_6_4(ABC_JIT_ARGS) { r6=r6*r4; NEXT }
ABC_JIT_CC abc_value mul_6_5(ABC_JIT_ARGS) { r6=r6*r5; NEXT }
ABC_JIT_CC abc_value mul_6_6(ABC_JIT_ARGS) { r6=r6*r6; NEXT }
ABC_JIT_CC abc_value mul_6_7(ABC_JIT_ARGS) { r6=r6*r7; NEXT }
ABC_JIT_CC abc_value mul_7_0(ABC_JIT_ARGS) { r7=r7*r0; NEXT }
ABC_JIT_CC abc_value mul_7_1(ABC_JIT_ARGS) { r7=r7*r1; NEXT }
ABC_JIT_CC abc_value mul_7_2(ABC_JIT_ARGS) { r7=r7*r2; NEXT }
ABC_JIT_CC abc_value mul_7_3(ABC_JIT_ARGS) { r7=r7*r3; NEXT }
ABC_JIT_CC abc_value mul_7_4(ABC_JIT_ARGS) { r7=r7*r4; NEXT }
ABC_JIT_CC abc_value mul_7_5(ABC_JIT_ARGS) { r7=r7*r5; NEXT }
ABC_JIT_CC abc_value mul_7_6(ABC_JIT_ARGS) { r7=r7*r6; NEXT }
ABC_JIT_CC abc_value mul_7_7(ABC_JIT_ARGS) { r7=r7*r7; NEXT }
ABC_JIT_CC abc_value divu_0_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r0=r0/r0; NEXT }
ABC_JIT_CC abc_value divu_0_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r0=r0/r1; NEXT }
ABC_JIT_CC abc_value divu_0_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r0=r0/r2; NEXT }
ABC_JIT_CC abc_value divu_0_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r0=r0/r3; NEXT }
ABC_JIT_CC abc_value divu_0_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r0=r0/r4; NEXT }
ABC_JIT_CC abc_value divu_0_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r0=r0/r5; NEXT }
ABC_JIT_CC abc_value divu_0_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r0=r0/r6; NEXT }
ABC_JIT_CC abc_value divu_0_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r0=r0/r7; NEXT }
ABC_JIT_CC abc_value divu_1_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r1=r1/r0; NEXT }
ABC_JIT_CC abc_value divu_1_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r1=r1/r1; NEXT }
ABC_JIT_CC abc_value divu_1_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r1=r1/r2; NEXT }
ABC_JIT_CC abc_value divu_1_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r1=r1/r3; NEXT }
ABC_JIT_CC abc_value divu_1_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r1=r1/r4; NEXT }
ABC_JIT_CC abc_value divu_1_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r1=r1/r5; NEXT }
ABC_JIT_CC abc_value divu_1_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r1=r1/r6; NEXT }
ABC_JIT_CC abc_value divu_1_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r1=r1/r7; NEXT }
ABC_JIT_CC abc_value divu_2_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r2=r2/r0; NEXT }
ABC_JIT_CC abc_value divu_2_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r2=r2/r1; NEXT }
ABC_JIT_CC abc_value divu_2_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r2=r2/r2; NEXT }
ABC_JIT_CC abc_value divu_2_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r2=r2/r3; NEXT }
ABC_JIT_CC abc_value divu_2_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r2=r2/r4; NEXT }
ABC_JIT_CC abc_value divu_2_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r2=r2/r5; NEXT }
ABC_JIT_CC abc_value divu_2_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r2=r2/r6; NEXT }
ABC_JIT_CC abc_value divu_2_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r2=r2/r7; NEXT }
ABC_JIT_CC abc_value divu_3_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r3=r3/r0; NEXT }
ABC_JIT_CC abc_value divu_3_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r3=r3/r1; NEXT }
ABC_JIT_CC abc_value divu_3_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r3=r3/r2; NEXT }
ABC_JIT_CC abc_value divu_3_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r3=r3/r3; NEXT }
ABC_JIT_CC abc_value divu_3_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r3=r3/r4; NEXT }
ABC_JIT_CC abc_value divu_3_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r3=r3/r5; NEXT }
ABC_JIT_CC abc_value divu_3_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r3=r3/r6; NEXT }
ABC_JIT_CC abc_value divu_3_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r3=r3/r7; NEXT }
ABC_JIT_CC abc_value divu_4_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r4=r4/r0; NEXT }
ABC_JIT_CC abc_value divu_4_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r4=r4/r1; NEXT }
ABC_JIT_CC abc_value divu_4_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r4=r4/r2; NEXT }
ABC_JIT_CC abc_value divu_4_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r4=r4/r3; NEXT }
ABC_JIT_CC abc_value divu_4_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r4=r4/r4; NEXT }
ABC_JIT_CC abc_value divu_4_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r4=r4/r5; NEXT }
ABC_JIT_CC abc_value divu_4_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r4=r4/r6; NEXT }
ABC_JIT_CC abc_value divu_4_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r4=r4/r7; NEXT }
ABC_JIT_CC abc_value divu_5_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r5=r5/r0; NEXT }
ABC_JIT_CC abc_value divu_5_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r5=r5/r1; NEXT }
ABC_JIT_CC abc_value divu_5_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r5=r5/r2; NEXT }
ABC_JIT_CC abc_value divu_5_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r5=r5/r3; NEXT }
ABC_JIT_CC abc_value divu_5_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r5=r5/r4; NEXT }
ABC_JIT_CC abc_value divu_5_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r5=r5/r5; NEXT }
ABC_JIT_CC abc_value divu_5_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r5=r5/r6; NEXT }
ABC_JIT_CC abc_value divu_5_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r5=r5/r7; NEXT }
ABC_JIT_CC abc_value divu_6_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r6=r6/r0; NEXT }
ABC_JIT_CC abc_value divu_6_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r6=r6/r1; NEXT }
ABC_JIT_CC abc_value divu_6_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r6=r6/r2; NEXT }
ABC_JIT_CC abc_value divu_6_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r6=r6/r3; NEXT }
ABC_JIT_CC abc_value divu_6_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r6=r6/r4; NEXT }
ABC_JIT_CC abc_value divu_6_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r6=r6/r5; NEXT }
ABC_JIT_CC abc_value divu_6_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r6=r6/r6; NEXT }
ABC_JIT_CC abc_value divu_6_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r6=r6/r7; NEXT }
ABC_JIT_CC abc_value divu_7_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r7=r7/r0; NEXT }
ABC_JIT_CC abc_value divu_7_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r7=r7/r1; NEXT }
ABC_JIT_CC abc_value divu_7_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r7=r7/r2; NEXT }
ABC_JIT_CC abc_value divu_7_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r7=r7/r3; NEXT }
ABC_JIT_CC abc_value divu_7_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r7=r7/r4; NEXT }
ABC_JIT_CC abc_value divu_7_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r7=r7/r5; NEXT }
ABC_JIT_CC abc_value divu_7_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r7=r7/r6; NEXT }
ABC_JIT_CC abc_value divu_7_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r7=r7/r7; NEXT }
ABC_JIT_CC abc_value divs_0_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r0=(r0==UINT64_MAX ? 0-r0 : (uint64_t)(abc_signed(r0)/abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value divs_0_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r0=(r1==UINT64_MAX ? 0-r0 : (uint64_t)(abc_signed(r0)/abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value divs_0_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r0=(r2==UINT64_MAX ? 0-r0 : (uint64_t)(abc_signed(r0)/abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value divs_0_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r0=(r3==UINT64_MAX ? 0-r0 : (uint64_t)(abc_signed(r0)/abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value divs_0_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r0=(r4==UINT64_MAX ? 0-r0 : (uint64_t)(abc_signed(r0)/abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value divs_0_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r0=(r5==UINT64_MAX ? 0-r0 : (uint64_t)(abc_signed(r0)/abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value divs_0_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r0=(r6==UINT64_MAX ? 0-r0 : (uint64_t)(abc_signed(r0)/abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value divs_0_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r0=(r7==UINT64_MAX ? 0-r0 : (uint64_t)(abc_signed(r0)/abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value divs_1_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r1=(r0==UINT64_MAX ? 0-r1 : (uint64_t)(abc_signed(r1)/abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value divs_1_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r1=(r1==UINT64_MAX ? 0-r1 : (uint64_t)(abc_signed(r1)/abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value divs_1_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r1=(r2==UINT64_MAX ? 0-r1 : (uint64_t)(abc_signed(r1)/abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value divs_1_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r1=(r3==UINT64_MAX ? 0-r1 : (uint64_t)(abc_signed(r1)/abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value divs_1_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r1=(r4==UINT64_MAX ? 0-r1 : (uint64_t)(abc_signed(r1)/abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value divs_1_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r1=(r5==UINT64_MAX ? 0-r1 : (uint64_t)(abc_signed(r1)/abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value divs_1_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r1=(r6==UINT64_MAX ? 0-r1 : (uint64_t)(abc_signed(r1)/abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value divs_1_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r1=(r7==UINT64_MAX ? 0-r1 : (uint64_t)(abc_signed(r1)/abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value divs_2_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r2=(r0==UINT64_MAX ? 0-r2 : (uint64_t)(abc_signed(r2)/abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value divs_2_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r2=(r1==UINT64_MAX ? 0-r2 : (uint64_t)(abc_signed(r2)/abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value divs_2_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r2=(r2==UINT64_MAX ? 0-r2 : (uint64_t)(abc_signed(r2)/abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value divs_2_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r2=(r3==UINT64_MAX ? 0-r2 : (uint64_t)(abc_signed(r2)/abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value divs_2_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r2=(r4==UINT64_MAX ? 0-r2 : (uint64_t)(abc_signed(r2)/abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value divs_2_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r2=(r5==UINT64_MAX ? 0-r2 : (uint64_t)(abc_signed(r2)/abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value divs_2_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r2=(r6==UINT64_MAX ? 0-r2 : (uint64_t)(abc_signed(r2)/abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value divs_2_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r2=(r7==UINT64_MAX ? 0-r2 : (uint64_t)(abc_signed(r2)/abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value divs_3_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r3=(r0==UINT64_MAX ? 0-r3 : (uint64_t)(abc_signed(r3)/abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value divs_3_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r3=(r1==UINT64_MAX ? 0-r3 : (uint64_t)(abc_signed(r3)/abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value divs_3_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r3=(r2==UINT64_MAX ? 0-r3 : (uint64_t)(abc_signed(r3)/abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value divs_3_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r3=(r3==UINT64_MAX ? 0-r3 : (uint64_t)(abc_signed(r3)/abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value divs_3_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r3=(r4==UINT64_MAX ? 0-r3 : (uint64_t)(abc_signed(r3)/abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value divs_3_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r3=(r5==UINT64_MAX ? 0-r3 : (uint64_t)(abc_signed(r3)/abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value divs_3_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r3=(r6==UINT64_MAX ? 0-r3 : (uint64_t)(abc_signed(r3)/abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value divs_3_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r3=(r7==UINT64_MAX ? 0-r3 : (uint64_t)(abc_signed(r3)/abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value divs_4_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r4=(r0==UINT64_MAX ? 0-r4 : (uint64_t)(abc_signed(r4)/abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value divs_4_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r4=(r1==UINT64_MAX ? 0-r4 : (uint64_t)(abc_signed(r4)/abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value divs_4_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r4=(r2==UINT64_MAX ? 0-r4 : (uint64_t)(abc_signed(r4)/abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value divs_4_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r4=(r3==UINT64_MAX ? 0-r4 : (uint64_t)(abc_signed(r4)/abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value divs_4_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r4=(r4==UINT64_MAX ? 0-r4 : (uint64_t)(abc_signed(r4)/abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value divs_4_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r4=(r5==UINT64_MAX ? 0-r4 : (uint64_t)(abc_signed(r4)/abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value divs_4_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r4=(r6==UINT64_MAX ? 0-r4 : (uint64_t)(abc_signed(r4)/abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value divs_4_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r4=(r7==UINT64_MAX ? 0-r4 : (uint64_t)(abc_signed(r4)/abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value divs_5_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r5=(r0==UINT64_MAX ? 0-r5 : (uint64_t)(abc_signed(r5)/abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value divs_5_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r5=(r1==UINT64_MAX ? 0-r5 : (uint64_t)(abc_signed(r5)/abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value divs_5_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r5=(r2==UINT64_MAX ? 0-r5 : (uint64_t)(abc_signed(r5)/abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value divs_5_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r5=(r3==UINT64_MAX ? 0-r5 : (uint64_t)(abc_signed(r5)/abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value divs_5_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r5=(r4==UINT64_MAX ? 0-r5 : (uint64_t)(abc_signed(r5)/abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value divs_5_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r5=(r5==UINT64_MAX ? 0-r5 : (uint64_t)(abc_signed(r5)/abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value divs_5_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r5=(r6==UINT64_MAX ? 0-r5 : (uint64_t)(abc_signed(r5)/abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value divs_5_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r5=(r7==UINT64_MAX ? 0-r5 : (uint64_t)(abc_signed(r5)/abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value divs_6_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r6=(r0==UINT64_MAX ? 0-r6 : (uint64_t)(abc_signed(r6)/abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value divs_6_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r6=(r1==UINT64_MAX ? 0-r6 : (uint64_t)(abc_signed(r6)/abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value divs_6_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r6=(r2==UINT64_MAX ? 0-r6 : (uint64_t)(abc_signed(r6)/abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value divs_6_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r6=(r3==UINT64_MAX ? 0-r6 : (uint64_t)(abc_signed(r6)/abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value divs_6_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r6=(r4==UINT64_MAX ? 0-r6 : (uint64_t)(abc_signed(r6)/abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value divs_6_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r6=(r5==UINT64_MAX ? 0-r6 : (uint64_t)(abc_signed(r6)/abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value divs_6_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r6=(r6==UINT64_MAX ? 0-r6 : (uint64_t)(abc_signed(r6)/abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value divs_6_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r6=(r7==UINT64_MAX ? 0-r6 : (uint64_t)(abc_signed(r6)/abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value divs_7_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r7=(r0==UINT64_MAX ? 0-r7 : (uint64_t)(abc_signed(r7)/abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value divs_7_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r7=(r1==UINT64_MAX ? 0-r7 : (uint64_t)(abc_signed(r7)/abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value divs_7_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r7=(r2==UINT64_MAX ? 0-r7 : (uint64_t)(abc_signed(r7)/abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value divs_7_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r7=(r3==UINT64_MAX ? 0-r7 : (uint64_t)(abc_signed(r7)/abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value divs_7_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r7=(r4==UINT64_MAX ? 0-r7 : (uint64_t)(abc_signed(r7)/abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value divs_7_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r7=(r5==UINT64_MAX ? 0-r7 : (uint64_t)(abc_signed(r7)/abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value divs_7_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r7=(r6==UINT64_MAX ? 0-r7 : (uint64_t)(abc_signed(r7)/abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value divs_7_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r7=(r7==UINT64_MAX ? 0-r7 : (uint64_t)(abc_signed(r7)/abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value remu_0_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r0=r0%r0; NEXT }
ABC_JIT_CC abc_value remu_0_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r0=r0%r1; NEXT }
ABC_JIT_CC abc_value remu_0_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r0=r0%r2; NEXT }
ABC_JIT_CC abc_value remu_0_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r0=r0%r3; NEXT }
ABC_JIT_CC abc_value remu_0_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r0=r0%r4; NEXT }
ABC_JIT_CC abc_value remu_0_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r0=r0%r5; NEXT }
ABC_JIT_CC abc_value remu_0_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r0=r0%r6; NEXT }
ABC_JIT_CC abc_value remu_0_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r0=r0%r7; NEXT }
ABC_JIT_CC abc_value remu_1_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r1=r1%r0; NEXT }
ABC_JIT_CC abc_value remu_1_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r1=r1%r1; NEXT }
ABC_JIT_CC abc_value remu_1_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r1=r1%r2; NEXT }
ABC_JIT_CC abc_value remu_1_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r1=r1%r3; NEXT }
ABC_JIT_CC abc_value remu_1_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r1=r1%r4; NEXT }
ABC_JIT_CC abc_value remu_1_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r1=r1%r5; NEXT }
ABC_JIT_CC abc_value remu_1_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r1=r1%r6; NEXT }
ABC_JIT_CC abc_value remu_1_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r1=r1%r7; NEXT }
ABC_JIT_CC abc_value remu_2_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r2=r2%r0; NEXT }
ABC_JIT_CC abc_value remu_2_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r2=r2%r1; NEXT }
ABC_JIT_CC abc_value remu_2_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r2=r2%r2; NEXT }
ABC_JIT_CC abc_value remu_2_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r2=r2%r3; NEXT }
ABC_JIT_CC abc_value remu_2_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r2=r2%r4; NEXT }
ABC_JIT_CC abc_value remu_2_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r2=r2%r5; NEXT }
ABC_JIT_CC abc_value remu_2_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r2=r2%r6; NEXT }
ABC_JIT_CC abc_value remu_2_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r2=r2%r7; NEXT }
ABC_JIT_CC abc_value remu_3_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r3=r3%r0; NEXT }
ABC_JIT_CC abc_value remu_3_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r3=r3%r1; NEXT }
ABC_JIT_CC abc_value remu_3_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r3=r3%r2; NEXT }
ABC_JIT_CC abc_value remu_3_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r3=r3%r3; NEXT }
ABC_JIT_CC abc_value remu_3_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r3=r3%r4; NEXT }
ABC_JIT_CC abc_value remu_3_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r3=r3%r5; NEXT }
ABC_JIT_CC abc_value remu_3_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r3=r3%r6; NEXT }
ABC_JIT_CC abc_value remu_3_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r3=r3%r7; NEXT }
ABC_JIT_CC abc_value remu_4_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r4=r4%r0; NEXT }
ABC_JIT_CC abc_value remu_4_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r4=r4%r1; NEXT }
ABC_JIT_CC abc_value remu_4_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r4=r4%r2; NEXT }
ABC_JIT_CC abc_value remu_4_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r4=r4%r3; NEXT }
ABC_JIT_CC abc_value remu_4_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r4=r4%r4; NEXT }
ABC_JIT_CC abc_value remu_4_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r4=r4%r5; NEXT }
ABC_JIT_CC abc_value remu_4_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r4=r4%r6; NEXT }
ABC_JIT_CC abc_value remu_4_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r4=r4%r7; NEXT }
ABC_JIT_CC abc_value remu_5_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r5=r5%r0; NEXT }
ABC_JIT_CC abc_value remu_5_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r5=r5%r1; NEXT }
ABC_JIT_CC abc_value remu_5_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r5=r5%r2; NEXT }
ABC_JIT_CC abc_value remu_5_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r5=r5%r3; NEXT }
ABC_JIT_CC abc_value remu_5_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r5=r5%r4; NEXT }
ABC_JIT_CC abc_value remu_5_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r5=r5%r5; NEXT }
ABC_JIT_CC abc_value remu_5_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r5=r5%r6; NEXT }
ABC_JIT_CC abc_value remu_5_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r5=r5%r7; NEXT }
ABC_JIT_CC abc_value remu_6_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r6=r6%r0; NEXT }
ABC_JIT_CC abc_value remu_6_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r6=r6%r1; NEXT }
ABC_JIT_CC abc_value remu_6_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r6=r6%r2; NEXT }
ABC_JIT_CC abc_value remu_6_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r6=r6%r3; NEXT }
ABC_JIT_CC abc_value remu_6_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r6=r6%r4; NEXT }
ABC_JIT_CC abc_value remu_6_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r6=r6%r5; NEXT }
ABC_JIT_CC abc_value remu_6_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r6=r6%r6; NEXT }
ABC_JIT_CC abc_value remu_6_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r6=r6%r7; NEXT }
ABC_JIT_CC abc_value remu_7_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r7=r7%r0; NEXT }
ABC_JIT_CC abc_value remu_7_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r7=r7%r1; NEXT }
ABC_JIT_CC abc_value remu_7_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r7=r7%r2; NEXT }
ABC_JIT_CC abc_value remu_7_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r7=r7%r3; NEXT }
ABC_JIT_CC abc_value remu_7_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r7=r7%r4; NEXT }
ABC_JIT_CC abc_value remu_7_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r7=r7%r5; NEXT }
ABC_JIT_CC abc_value remu_7_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r7=r7%r6; NEXT }
ABC_JIT_CC abc_value remu_7_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r7=r7%r7; NEXT }
ABC_JIT_CC abc_value rems_0_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r0=(r0==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r0)%abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value rems_0_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r0=(r1==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r0)%abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value rems_0_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r0=(r2==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r0)%abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value rems_0_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r0=(r3==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r0)%abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value rems_0_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r0=(r4==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r0)%abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value rems_0_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r0=(r5==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r0)%abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value rems_0_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r0=(r6==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r0)%abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value rems_0_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r0=(r7==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r0)%abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value rems_1_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r1=(r0==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r1)%abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value rems_1_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r1=(r1==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r1)%abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value rems_1_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r1=(r2==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r1)%abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value rems_1_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r1=(r3==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r1)%abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value rems_1_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r1=(r4==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r1)%abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value rems_1_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r1=(r5==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r1)%abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value rems_1_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r1=(r6==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r1)%abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value rems_1_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r1=(r7==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r1)%abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value rems_2_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r2=(r0==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r2)%abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value rems_2_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r2=(r1==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r2)%abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value rems_2_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r2=(r2==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r2)%abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value rems_2_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r2=(r3==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r2)%abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value rems_2_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r2=(r4==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r2)%abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value rems_2_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r2=(r5==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r2)%abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value rems_2_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r2=(r6==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r2)%abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value rems_2_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r2=(r7==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r2)%abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value rems_3_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r3=(r0==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r3)%abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value rems_3_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r3=(r1==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r3)%abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value rems_3_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r3=(r2==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r3)%abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value rems_3_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r3=(r3==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r3)%abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value rems_3_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r3=(r4==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r3)%abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value rems_3_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r3=(r5==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r3)%abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value rems_3_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r3=(r6==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r3)%abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value rems_3_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r3=(r7==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r3)%abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value rems_4_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r4=(r0==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r4)%abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value rems_4_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r4=(r1==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r4)%abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value rems_4_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r4=(r2==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r4)%abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value rems_4_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r4=(r3==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r4)%abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value rems_4_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r4=(r4==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r4)%abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value rems_4_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r4=(r5==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r4)%abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value rems_4_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r4=(r6==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r4)%abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value rems_4_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r4=(r7==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r4)%abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value rems_5_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r5=(r0==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r5)%abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value rems_5_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r5=(r1==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r5)%abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value rems_5_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r5=(r2==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r5)%abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value rems_5_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r5=(r3==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r5)%abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value rems_5_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r5=(r4==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r5)%abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value rems_5_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r5=(r5==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r5)%abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value rems_5_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r5=(r6==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r5)%abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value rems_5_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r5=(r7==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r5)%abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value rems_6_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r6=(r0==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r6)%abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value rems_6_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r6=(r1==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r6)%abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value rems_6_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r6=(r2==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r6)%abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value rems_6_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r6=(r3==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r6)%abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value rems_6_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r6=(r4==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r6)%abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value rems_6_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r6=(r5==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r6)%abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value rems_6_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r6=(r6==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r6)%abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value rems_6_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r6=(r7==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r6)%abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value rems_7_0(ABC_JIT_ARGS) { if(!r0)return jit_error(); r7=(r0==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r7)%abc_signed(r0))); NEXT }
ABC_JIT_CC abc_value rems_7_1(ABC_JIT_ARGS) { if(!r1)return jit_error(); r7=(r1==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r7)%abc_signed(r1))); NEXT }
ABC_JIT_CC abc_value rems_7_2(ABC_JIT_ARGS) { if(!r2)return jit_error(); r7=(r2==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r7)%abc_signed(r2))); NEXT }
ABC_JIT_CC abc_value rems_7_3(ABC_JIT_ARGS) { if(!r3)return jit_error(); r7=(r3==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r7)%abc_signed(r3))); NEXT }
ABC_JIT_CC abc_value rems_7_4(ABC_JIT_ARGS) { if(!r4)return jit_error(); r7=(r4==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r7)%abc_signed(r4))); NEXT }
ABC_JIT_CC abc_value rems_7_5(ABC_JIT_ARGS) { if(!r5)return jit_error(); r7=(r5==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r7)%abc_signed(r5))); NEXT }
ABC_JIT_CC abc_value rems_7_6(ABC_JIT_ARGS) { if(!r6)return jit_error(); r7=(r6==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r7)%abc_signed(r6))); NEXT }
ABC_JIT_CC abc_value rems_7_7(ABC_JIT_ARGS) { if(!r7)return jit_error(); r7=(r7==UINT64_MAX ? 0 : (uint64_t)(abc_signed(r7)%abc_signed(r7))); NEXT }
ABC_JIT_CC abc_value and_0_0(ABC_JIT_ARGS) { r0=r0&r0; NEXT }
ABC_JIT_CC abc_value and_0_1(ABC_JIT_ARGS) { r0=r0&r1; NEXT }
ABC_JIT_CC abc_value and_0_2(ABC_JIT_ARGS) { r0=r0&r2; NEXT }
ABC_JIT_CC abc_value and_0_3(ABC_JIT_ARGS) { r0=r0&r3; NEXT }
ABC_JIT_CC abc_value and_0_4(ABC_JIT_ARGS) { r0=r0&r4; NEXT }
ABC_JIT_CC abc_value and_0_5(ABC_JIT_ARGS) { r0=r0&r5; NEXT }
ABC_JIT_CC abc_value and_0_6(ABC_JIT_ARGS) { r0=r0&r6; NEXT }
ABC_JIT_CC abc_value and_0_7(ABC_JIT_ARGS) { r0=r0&r7; NEXT }
ABC_JIT_CC abc_value and_1_0(ABC_JIT_ARGS) { r1=r1&r0; NEXT }
ABC_JIT_CC abc_value and_1_1(ABC_JIT_ARGS) { r1=r1&r1; NEXT }
ABC_JIT_CC abc_value and_1_2(ABC_JIT_ARGS) { r1=r1&r2; NEXT }
ABC_JIT_CC abc_value and_1_3(ABC_JIT_ARGS) { r1=r1&r3; NEXT }
ABC_JIT_CC abc_value and_1_4(ABC_JIT_ARGS) { r1=r1&r4; NEXT }
ABC_JIT_CC abc_value and_1_5(ABC_JIT_ARGS) { r1=r1&r5; NEXT }
ABC_JIT_CC abc_value and_1_6(ABC_JIT_ARGS) { r1=r1&r6; NEXT }
ABC_JIT_CC abc_value and_1_7(ABC_JIT_ARGS) { r1=r1&r7; NEXT }
ABC_JIT_CC abc_value and_2_0(ABC_JIT_ARGS) { r2=r2&r0; NEXT }
ABC_JIT_CC abc_value and_2_1(ABC_JIT_ARGS) { r2=r2&r1; NEXT }
ABC_JIT_CC abc_value and_2_2(ABC_JIT_ARGS) { r2=r2&r2; NEXT }
ABC_JIT_CC abc_value and_2_3(ABC_JIT_ARGS) { r2=r2&r3; NEXT }
ABC_JIT_CC abc_value and_2_4(ABC_JIT_ARGS) { r2=r2&r4; NEXT }
ABC_JIT_CC abc_value and_2_5(ABC_JIT_ARGS) { r2=r2&r5; NEXT }
ABC_JIT_CC abc_value and_2_6(ABC_JIT_ARGS) { r2=r2&r6; NEXT }
ABC_JIT_CC abc_value and_2_7(ABC_JIT_ARGS) { r2=r2&r7; NEXT }
ABC_JIT_CC abc_value and_3_0(ABC_JIT_ARGS) { r3=r3&r0; NEXT }
ABC_JIT_CC abc_value and_3_1(ABC_JIT_ARGS) { r3=r3&r1; NEXT }
ABC_JIT_CC abc_value and_3_2(ABC_JIT_ARGS) { r3=r3&r2; NEXT }
ABC_JIT_CC abc_value and_3_3(ABC_JIT_ARGS) { r3=r3&r3; NEXT }
ABC_JIT_CC abc_value and_3_4(ABC_JIT_ARGS) { r3=r3&r4; NEXT }
ABC_JIT_CC abc_value and_3_5(ABC_JIT_ARGS) { r3=r3&r5; NEXT }
ABC_JIT_CC abc_value and_3_6(ABC_JIT_ARGS) { r3=r3&r6; NEXT }
ABC_JIT_CC abc_value and_3_7(ABC_JIT_ARGS) { r3=r3&r7; NEXT }
ABC_JIT_CC abc_value and_4_0(ABC_JIT_ARGS) { r4=r4&r0; NEXT }
ABC_JIT_CC abc_value and_4_1(ABC_JIT_ARGS) { r4=r4&r1; NEXT }
ABC_JIT_CC abc_value and_4_2(ABC_JIT_ARGS) { r4=r4&r2; NEXT }
ABC_JIT_CC abc_value and_4_3(ABC_JIT_ARGS) { r4=r4&r3; NEXT }
ABC_JIT_CC abc_value and_4_4(ABC_JIT_ARGS) { r4=r4&r4; NEXT }
ABC_JIT_CC abc_value and_4_5(ABC_JIT_ARGS) { r4=r4&r5; NEXT }
ABC_JIT_CC abc_value and_4_6(ABC_JIT_ARGS) { r4=r4&r6; NEXT }
ABC_JIT_CC abc_value and_4_7(ABC_JIT_ARGS) { r4=r4&r7; NEXT }
ABC_JIT_CC abc_value and_5_0(ABC_JIT_ARGS) { r5=r5&r0; NEXT }
ABC_JIT_CC abc_value and_5_1(ABC_JIT_ARGS) { r5=r5&r1; NEXT }
ABC_JIT_CC abc_value and_5_2(ABC_JIT_ARGS) { r5=r5&r2; NEXT }
ABC_JIT_CC abc_value and_5_3(ABC_JIT_ARGS) { r5=r5&r3; NEXT }
ABC_JIT_CC abc_value and_5_4(ABC_JIT_ARGS) { r5=r5&r4; NEXT }
ABC_JIT_CC abc_value and_5_5(ABC_JIT_ARGS) { r5=r5&r5; NEXT }
ABC_JIT_CC abc_value and_5_6(ABC_JIT_ARGS) { r5=r5&r6; NEXT }
ABC_JIT_CC abc_value and_5_7(ABC_JIT_ARGS) { r5=r5&r7; NEXT }
ABC_JIT_CC abc_value and_6_0(ABC_JIT_ARGS) { r6=r6&r0; NEXT }
ABC_JIT_CC abc_value and_6_1(ABC_JIT_ARGS) { r6=r6&r1; NEXT }
ABC_JIT_CC abc_value and_6_2(ABC_JIT_ARGS) { r6=r6&r2; NEXT }
ABC_JIT_CC abc_value and_6_3(ABC_JIT_ARGS) { r6=r6&r3; NEXT }
ABC_JIT_CC abc_value and_6_4(ABC_JIT_ARGS) { r6=r6&r4; NEXT }
ABC_JIT_CC abc_value and_6_5(ABC_JIT_ARGS) { r6=r6&r5; NEXT }
ABC_JIT_CC abc_value and_6_6(ABC_JIT_ARGS) { r6=r6&r6; NEXT }
ABC_JIT_CC abc_value and_6_7(ABC_JIT_ARGS) { r6=r6&r7; NEXT }
ABC_JIT_CC abc_value and_7_0(ABC_JIT_ARGS) { r7=r7&r0; NEXT }
ABC_JIT_CC abc_value and_7_1(ABC_JIT_ARGS) { r7=r7&r1; NEXT }
ABC_JIT_CC abc_value and_7_2(ABC_JIT_ARGS) { r7=r7&r2; NEXT }
ABC_JIT_CC abc_value and_7_3(ABC_JIT_ARGS) { r7=r7&r3; NEXT }
ABC_JIT_CC abc_value and_7_4(ABC_JIT_ARGS) { r7=r7&r4; NEXT }
ABC_JIT_CC abc_value and_7_5(ABC_JIT_ARGS) { r7=r7&r5; NEXT }
ABC_JIT_CC abc_value and_7_6(ABC_JIT_ARGS) { r7=r7&r6; NEXT }
ABC_JIT_CC abc_value and_7_7(ABC_JIT_ARGS) { r7=r7&r7; NEXT }
ABC_JIT_CC abc_value or_0_0(ABC_JIT_ARGS) { r0=r0|r0; NEXT }
ABC_JIT_CC abc_value or_0_1(ABC_JIT_ARGS) { r0=r0|r1; NEXT }
ABC_JIT_CC abc_value or_0_2(ABC_JIT_ARGS) { r0=r0|r2; NEXT }
ABC_JIT_CC abc_value or_0_3(ABC_JIT_ARGS) { r0=r0|r3; NEXT }
ABC_JIT_CC abc_value or_0_4(ABC_JIT_ARGS) { r0=r0|r4; NEXT }
ABC_JIT_CC abc_value or_0_5(ABC_JIT_ARGS) { r0=r0|r5; NEXT }
ABC_JIT_CC abc_value or_0_6(ABC_JIT_ARGS) { r0=r0|r6; NEXT }
ABC_JIT_CC abc_value or_0_7(ABC_JIT_ARGS) { r0=r0|r7; NEXT }
ABC_JIT_CC abc_value or_1_0(ABC_JIT_ARGS) { r1=r1|r0; NEXT }
ABC_JIT_CC abc_value or_1_1(ABC_JIT_ARGS) { r1=r1|r1; NEXT }
ABC_JIT_CC abc_value or_1_2(ABC_JIT_ARGS) { r1=r1|r2; NEXT }
ABC_JIT_CC abc_value or_1_3(ABC_JIT_ARGS) { r1=r1|r3; NEXT }
ABC_JIT_CC abc_value or_1_4(ABC_JIT_ARGS) { r1=r1|r4; NEXT }
ABC_JIT_CC abc_value or_1_5(ABC_JIT_ARGS) { r1=r1|r5; NEXT }
ABC_JIT_CC abc_value or_1_6(ABC_JIT_ARGS) { r1=r1|r6; NEXT }
ABC_JIT_CC abc_value or_1_7(ABC_JIT_ARGS) { r1=r1|r7; NEXT }
ABC_JIT_CC abc_value or_2_0(ABC_JIT_ARGS) { r2=r2|r0; NEXT }
ABC_JIT_CC abc_value or_2_1(ABC_JIT_ARGS) { r2=r2|r1; NEXT }
ABC_JIT_CC abc_value or_2_2(ABC_JIT_ARGS) { r2=r2|r2; NEXT }
ABC_JIT_CC abc_value or_2_3(ABC_JIT_ARGS) { r2=r2|r3; NEXT }
ABC_JIT_CC abc_value or_2_4(ABC_JIT_ARGS) { r2=r2|r4; NEXT }
ABC_JIT_CC abc_value or_2_5(ABC_JIT_ARGS) { r2=r2|r5; NEXT }
ABC_JIT_CC abc_value or_2_6(ABC_JIT_ARGS) { r2=r2|r6; NEXT }
ABC_JIT_CC abc_value or_2_7(ABC_JIT_ARGS) { r2=r2|r7; NEXT }
ABC_JIT_CC abc_value or_3_0(ABC_JIT_ARGS) { r3=r3|r0; NEXT }
ABC_JIT_CC abc_value or_3_1(ABC_JIT_ARGS) { r3=r3|r1; NEXT }
ABC_JIT_CC abc_value or_3_2(ABC_JIT_ARGS) { r3=r3|r2; NEXT }
ABC_JIT_CC abc_value or_3_3(ABC_JIT_ARGS) { r3=r3|r3; NEXT }
ABC_JIT_CC abc_value or_3_4(ABC_JIT_ARGS) { r3=r3|r4; NEXT }
ABC_JIT_CC abc_value or_3_5(ABC_JIT_ARGS) { r3=r3|r5; NEXT }
ABC_JIT_CC abc_value or_3_6(ABC_JIT_ARGS) { r3=r3|r6; NEXT }
ABC_JIT_CC abc_value or_3_7(ABC_JIT_ARGS) { r3=r3|r7; NEXT }
ABC_JIT_CC abc_value or_4_0(ABC_JIT_ARGS) { r4=r4|r0; NEXT }
ABC_JIT_CC abc_value or_4_1(ABC_JIT_ARGS) { r4=r4|r1; NEXT }
ABC_JIT_CC abc_value or_4_2(ABC_JIT_ARGS) { r4=r4|r2; NEXT }
ABC_JIT_CC abc_value or_4_3(ABC_JIT_ARGS) { r4=r4|r3; NEXT }
ABC_JIT_CC abc_value or_4_4(ABC_JIT_ARGS) { r4=r4|r4; NEXT }
ABC_JIT_CC abc_value or_4_5(ABC_JIT_ARGS) { r4=r4|r5; NEXT }
ABC_JIT_CC abc_value or_4_6(ABC_JIT_ARGS) { r4=r4|r6; NEXT }
ABC_JIT_CC abc_value or_4_7(ABC_JIT_ARGS) { r4=r4|r7; NEXT }
ABC_JIT_CC abc_value or_5_0(ABC_JIT_ARGS) { r5=r5|r0; NEXT }
ABC_JIT_CC abc_value or_5_1(ABC_JIT_ARGS) { r5=r5|r1; NEXT }
ABC_JIT_CC abc_value or_5_2(ABC_JIT_ARGS) { r5=r5|r2; NEXT }
ABC_JIT_CC abc_value or_5_3(ABC_JIT_ARGS) { r5=r5|r3; NEXT }
ABC_JIT_CC abc_value or_5_4(ABC_JIT_ARGS) { r5=r5|r4; NEXT }
ABC_JIT_CC abc_value or_5_5(ABC_JIT_ARGS) { r5=r5|r5; NEXT }
ABC_JIT_CC abc_value or_5_6(ABC_JIT_ARGS) { r5=r5|r6; NEXT }
ABC_JIT_CC abc_value or_5_7(ABC_JIT_ARGS) { r5=r5|r7; NEXT }
ABC_JIT_CC abc_value or_6_0(ABC_JIT_ARGS) { r6=r6|r0; NEXT }
ABC_JIT_CC abc_value or_6_1(ABC_JIT_ARGS) { r6=r6|r1; NEXT }
ABC_JIT_CC abc_value or_6_2(ABC_JIT_ARGS) { r6=r6|r2; NEXT }
ABC_JIT_CC abc_value or_6_3(ABC_JIT_ARGS) { r6=r6|r3; NEXT }
ABC_JIT_CC abc_value or_6_4(ABC_JIT_ARGS) { r6=r6|r4; NEXT }
ABC_JIT_CC abc_value or_6_5(ABC_JIT_ARGS) { r6=r6|r5; NEXT }
ABC_JIT_CC abc_value or_6_6(ABC_JIT_ARGS) { r6=r6|r6; NEXT }
ABC_JIT_CC abc_value or_6_7(ABC_JIT_ARGS) { r6=r6|r7; NEXT }
ABC_JIT_CC abc_value or_7_0(ABC_JIT_ARGS) { r7=r7|r0; NEXT }
ABC_JIT_CC abc_value or_7_1(ABC_JIT_ARGS) { r7=r7|r1; NEXT }
ABC_JIT_CC abc_value or_7_2(ABC_JIT_ARGS) { r7=r7|r2; NEXT }
ABC_JIT_CC abc_value or_7_3(ABC_JIT_ARGS) { r7=r7|r3; NEXT }
ABC_JIT_CC abc_value or_7_4(ABC_JIT_ARGS) { r7=r7|r4; NEXT }
ABC_JIT_CC abc_value or_7_5(ABC_JIT_ARGS) { r7=r7|r5; NEXT }
ABC_JIT_CC abc_value or_7_6(ABC_JIT_ARGS) { r7=r7|r6; NEXT }
ABC_JIT_CC abc_value or_7_7(ABC_JIT_ARGS) { r7=r7|r7; NEXT }
ABC_JIT_CC abc_value xor_0_0(ABC_JIT_ARGS) { r0=r0^r0; NEXT }
ABC_JIT_CC abc_value xor_0_1(ABC_JIT_ARGS) { r0=r0^r1; NEXT }
ABC_JIT_CC abc_value xor_0_2(ABC_JIT_ARGS) { r0=r0^r2; NEXT }
ABC_JIT_CC abc_value xor_0_3(ABC_JIT_ARGS) { r0=r0^r3; NEXT }
ABC_JIT_CC abc_value xor_0_4(ABC_JIT_ARGS) { r0=r0^r4; NEXT }
ABC_JIT_CC abc_value xor_0_5(ABC_JIT_ARGS) { r0=r0^r5; NEXT }
ABC_JIT_CC abc_value xor_0_6(ABC_JIT_ARGS) { r0=r0^r6; NEXT }
ABC_JIT_CC abc_value xor_0_7(ABC_JIT_ARGS) { r0=r0^r7; NEXT }
ABC_JIT_CC abc_value xor_1_0(ABC_JIT_ARGS) { r1=r1^r0; NEXT }
ABC_JIT_CC abc_value xor_1_1(ABC_JIT_ARGS) { r1=r1^r1; NEXT }
ABC_JIT_CC abc_value xor_1_2(ABC_JIT_ARGS) { r1=r1^r2; NEXT }
ABC_JIT_CC abc_value xor_1_3(ABC_JIT_ARGS) { r1=r1^r3; NEXT }
ABC_JIT_CC abc_value xor_1_4(ABC_JIT_ARGS) { r1=r1^r4; NEXT }
ABC_JIT_CC abc_value xor_1_5(ABC_JIT_ARGS) { r1=r1^r5; NEXT }
ABC_JIT_CC abc_value xor_1_6(ABC_JIT_ARGS) { r1=r1^r6; NEXT }
ABC_JIT_CC abc_value xor_1_7(ABC_JIT_ARGS) { r1=r1^r7; NEXT }
ABC_JIT_CC abc_value xor_2_0(ABC_JIT_ARGS) { r2=r2^r0; NEXT }
ABC_JIT_CC abc_value xor_2_1(ABC_JIT_ARGS) { r2=r2^r1; NEXT }
ABC_JIT_CC abc_value xor_2_2(ABC_JIT_ARGS) { r2=r2^r2; NEXT }
ABC_JIT_CC abc_value xor_2_3(ABC_JIT_ARGS) { r2=r2^r3; NEXT }
ABC_JIT_CC abc_value xor_2_4(ABC_JIT_ARGS) { r2=r2^r4; NEXT }
ABC_JIT_CC abc_value xor_2_5(ABC_JIT_ARGS) { r2=r2^r5; NEXT }
ABC_JIT_CC abc_value xor_2_6(ABC_JIT_ARGS) { r2=r2^r6; NEXT }
ABC_JIT_CC abc_value xor_2_7(ABC_JIT_ARGS) { r2=r2^r7; NEXT }
ABC_JIT_CC abc_value xor_3_0(ABC_JIT_ARGS) { r3=r3^r0; NEXT }
ABC_JIT_CC abc_value xor_3_1(ABC_JIT_ARGS) { r3=r3^r1; NEXT }
ABC_JIT_CC abc_value xor_3_2(ABC_JIT_ARGS) { r3=r3^r2; NEXT }
ABC_JIT_CC abc_value xor_3_3(ABC_JIT_ARGS) { r3=r3^r3; NEXT }
ABC_JIT_CC abc_value xor_3_4(ABC_JIT_ARGS) { r3=r3^r4; NEXT }
ABC_JIT_CC abc_value xor_3_5(ABC_JIT_ARGS) { r3=r3^r5; NEXT }
ABC_JIT_CC abc_value xor_3_6(ABC_JIT_ARGS) { r3=r3^r6; NEXT }
ABC_JIT_CC abc_value xor_3_7(ABC_JIT_ARGS) { r3=r3^r7; NEXT }
ABC_JIT_CC abc_value xor_4_0(ABC_JIT_ARGS) { r4=r4^r0; NEXT }
ABC_JIT_CC abc_value xor_4_1(ABC_JIT_ARGS) { r4=r4^r1; NEXT }
ABC_JIT_CC abc_value xor_4_2(ABC_JIT_ARGS) { r4=r4^r2; NEXT }
ABC_JIT_CC abc_value xor_4_3(ABC_JIT_ARGS) { r4=r4^r3; NEXT }
ABC_JIT_CC abc_value xor_4_4(ABC_JIT_ARGS) { r4=r4^r4; NEXT }
ABC_JIT_CC abc_value xor_4_5(ABC_JIT_ARGS) { r4=r4^r5; NEXT }
ABC_JIT_CC abc_value xor_4_6(ABC_JIT_ARGS) { r4=r4^r6; NEXT }
ABC_JIT_CC abc_value xor_4_7(ABC_JIT_ARGS) { r4=r4^r7; NEXT }
ABC_JIT_CC abc_value xor_5_0(ABC_JIT_ARGS) { r5=r5^r0; NEXT }
ABC_JIT_CC abc_value xor_5_1(ABC_JIT_ARGS) { r5=r5^r1; NEXT }
ABC_JIT_CC abc_value xor_5_2(ABC_JIT_ARGS) { r5=r5^r2; NEXT }
ABC_JIT_CC abc_value xor_5_3(ABC_JIT_ARGS) { r5=r5^r3; NEXT }
ABC_JIT_CC abc_value xor_5_4(ABC_JIT_ARGS) { r5=r5^r4; NEXT }
ABC_JIT_CC abc_value xor_5_5(ABC_JIT_ARGS) { r5=r5^r5; NEXT }
ABC_JIT_CC abc_value xor_5_6(ABC_JIT_ARGS) { r5=r5^r6; NEXT }
ABC_JIT_CC abc_value xor_5_7(ABC_JIT_ARGS) { r5=r5^r7; NEXT }
ABC_JIT_CC abc_value xor_6_0(ABC_JIT_ARGS) { r6=r6^r0; NEXT }
ABC_JIT_CC abc_value xor_6_1(ABC_JIT_ARGS) { r6=r6^r1; NEXT }
ABC_JIT_CC abc_value xor_6_2(ABC_JIT_ARGS) { r6=r6^r2; NEXT }
ABC_JIT_CC abc_value xor_6_3(ABC_JIT_ARGS) { r6=r6^r3; NEXT }
ABC_JIT_CC abc_value xor_6_4(ABC_JIT_ARGS) { r6=r6^r4; NEXT }
ABC_JIT_CC abc_value xor_6_5(ABC_JIT_ARGS) { r6=r6^r5; NEXT }
ABC_JIT_CC abc_value xor_6_6(ABC_JIT_ARGS) { r6=r6^r6; NEXT }
ABC_JIT_CC abc_value xor_6_7(ABC_JIT_ARGS) { r6=r6^r7; NEXT }
ABC_JIT_CC abc_value xor_7_0(ABC_JIT_ARGS) { r7=r7^r0; NEXT }
ABC_JIT_CC abc_value xor_7_1(ABC_JIT_ARGS) { r7=r7^r1; NEXT }
ABC_JIT_CC abc_value xor_7_2(ABC_JIT_ARGS) { r7=r7^r2; NEXT }
ABC_JIT_CC abc_value xor_7_3(ABC_JIT_ARGS) { r7=r7^r3; NEXT }
ABC_JIT_CC abc_value xor_7_4(ABC_JIT_ARGS) { r7=r7^r4; NEXT }
ABC_JIT_CC abc_value xor_7_5(ABC_JIT_ARGS) { r7=r7^r5; NEXT }
ABC_JIT_CC abc_value xor_7_6(ABC_JIT_ARGS) { r7=r7^r6; NEXT }
ABC_JIT_CC abc_value xor_7_7(ABC_JIT_ARGS) { r7=r7^r7; NEXT }
ABC_JIT_CC abc_value shl_0_0(ABC_JIT_ARGS) { r0=(r0>=64 ? 0 : r0<<r0); NEXT }
ABC_JIT_CC abc_value shl_0_1(ABC_JIT_ARGS) { r0=(r1>=64 ? 0 : r0<<r1); NEXT }
ABC_JIT_CC abc_value shl_0_2(ABC_JIT_ARGS) { r0=(r2>=64 ? 0 : r0<<r2); NEXT }
ABC_JIT_CC abc_value shl_0_3(ABC_JIT_ARGS) { r0=(r3>=64 ? 0 : r0<<r3); NEXT }
ABC_JIT_CC abc_value shl_0_4(ABC_JIT_ARGS) { r0=(r4>=64 ? 0 : r0<<r4); NEXT }
ABC_JIT_CC abc_value shl_0_5(ABC_JIT_ARGS) { r0=(r5>=64 ? 0 : r0<<r5); NEXT }
ABC_JIT_CC abc_value shl_0_6(ABC_JIT_ARGS) { r0=(r6>=64 ? 0 : r0<<r6); NEXT }
ABC_JIT_CC abc_value shl_0_7(ABC_JIT_ARGS) { r0=(r7>=64 ? 0 : r0<<r7); NEXT }
ABC_JIT_CC abc_value shl_1_0(ABC_JIT_ARGS) { r1=(r0>=64 ? 0 : r1<<r0); NEXT }
ABC_JIT_CC abc_value shl_1_1(ABC_JIT_ARGS) { r1=(r1>=64 ? 0 : r1<<r1); NEXT }
ABC_JIT_CC abc_value shl_1_2(ABC_JIT_ARGS) { r1=(r2>=64 ? 0 : r1<<r2); NEXT }
ABC_JIT_CC abc_value shl_1_3(ABC_JIT_ARGS) { r1=(r3>=64 ? 0 : r1<<r3); NEXT }
ABC_JIT_CC abc_value shl_1_4(ABC_JIT_ARGS) { r1=(r4>=64 ? 0 : r1<<r4); NEXT }
ABC_JIT_CC abc_value shl_1_5(ABC_JIT_ARGS) { r1=(r5>=64 ? 0 : r1<<r5); NEXT }
ABC_JIT_CC abc_value shl_1_6(ABC_JIT_ARGS) { r1=(r6>=64 ? 0 : r1<<r6); NEXT }
ABC_JIT_CC abc_value shl_1_7(ABC_JIT_ARGS) { r1=(r7>=64 ? 0 : r1<<r7); NEXT }
ABC_JIT_CC abc_value shl_2_0(ABC_JIT_ARGS) { r2=(r0>=64 ? 0 : r2<<r0); NEXT }
ABC_JIT_CC abc_value shl_2_1(ABC_JIT_ARGS) { r2=(r1>=64 ? 0 : r2<<r1); NEXT }
ABC_JIT_CC abc_value shl_2_2(ABC_JIT_ARGS) { r2=(r2>=64 ? 0 : r2<<r2); NEXT }
ABC_JIT_CC abc_value shl_2_3(ABC_JIT_ARGS) { r2=(r3>=64 ? 0 : r2<<r3); NEXT }
ABC_JIT_CC abc_value shl_2_4(ABC_JIT_ARGS) { r2=(r4>=64 ? 0 : r2<<r4); NEXT }
ABC_JIT_CC abc_value shl_2_5(ABC_JIT_ARGS) { r2=(r5>=64 ? 0 : r2<<r5); NEXT }
ABC_JIT_CC abc_value shl_2_6(ABC_JIT_ARGS) { r2=(r6>=64 ? 0 : r2<<r6); NEXT }
ABC_JIT_CC abc_value shl_2_7(ABC_JIT_ARGS) { r2=(r7>=64 ? 0 : r2<<r7); NEXT }
ABC_JIT_CC abc_value shl_3_0(ABC_JIT_ARGS) { r3=(r0>=64 ? 0 : r3<<r0); NEXT }
ABC_JIT_CC abc_value shl_3_1(ABC_JIT_ARGS) { r3=(r1>=64 ? 0 : r3<<r1); NEXT }
ABC_JIT_CC abc_value shl_3_2(ABC_JIT_ARGS) { r3=(r2>=64 ? 0 : r3<<r2); NEXT }
ABC_JIT_CC abc_value shl_3_3(ABC_JIT_ARGS) { r3=(r3>=64 ? 0 : r3<<r3); NEXT }
ABC_JIT_CC abc_value shl_3_4(ABC_JIT_ARGS) { r3=(r4>=64 ? 0 : r3<<r4); NEXT }
ABC_JIT_CC abc_value shl_3_5(ABC_JIT_ARGS) { r3=(r5>=64 ? 0 : r3<<r5); NEXT }
ABC_JIT_CC abc_value shl_3_6(ABC_JIT_ARGS) { r3=(r6>=64 ? 0 : r3<<r6); NEXT }
ABC_JIT_CC abc_value shl_3_7(ABC_JIT_ARGS) { r3=(r7>=64 ? 0 : r3<<r7); NEXT }
ABC_JIT_CC abc_value shl_4_0(ABC_JIT_ARGS) { r4=(r0>=64 ? 0 : r4<<r0); NEXT }
ABC_JIT_CC abc_value shl_4_1(ABC_JIT_ARGS) { r4=(r1>=64 ? 0 : r4<<r1); NEXT }
ABC_JIT_CC abc_value shl_4_2(ABC_JIT_ARGS) { r4=(r2>=64 ? 0 : r4<<r2); NEXT }
ABC_JIT_CC abc_value shl_4_3(ABC_JIT_ARGS) { r4=(r3>=64 ? 0 : r4<<r3); NEXT }
ABC_JIT_CC abc_value shl_4_4(ABC_JIT_ARGS) { r4=(r4>=64 ? 0 : r4<<r4); NEXT }
ABC_JIT_CC abc_value shl_4_5(ABC_JIT_ARGS) { r4=(r5>=64 ? 0 : r4<<r5); NEXT }
ABC_JIT_CC abc_value shl_4_6(ABC_JIT_ARGS) { r4=(r6>=64 ? 0 : r4<<r6); NEXT }
ABC_JIT_CC abc_value shl_4_7(ABC_JIT_ARGS) { r4=(r7>=64 ? 0 : r4<<r7); NEXT }
ABC_JIT_CC abc_value shl_5_0(ABC_JIT_ARGS) { r5=(r0>=64 ? 0 : r5<<r0); NEXT }
ABC_JIT_CC abc_value shl_5_1(ABC_JIT_ARGS) { r5=(r1>=64 ? 0 : r5<<r1); NEXT }
ABC_JIT_CC abc_value shl_5_2(ABC_JIT_ARGS) { r5=(r2>=64 ? 0 : r5<<r2); NEXT }
ABC_JIT_CC abc_value shl_5_3(ABC_JIT_ARGS) { r5=(r3>=64 ? 0 : r5<<r3); NEXT }
ABC_JIT_CC abc_value shl_5_4(ABC_JIT_ARGS) { r5=(r4>=64 ? 0 : r5<<r4); NEXT }
ABC_JIT_CC abc_value shl_5_5(ABC_JIT_ARGS) { r5=(r5>=64 ? 0 : r5<<r5); NEXT }
ABC_JIT_CC abc_value shl_5_6(ABC_JIT_ARGS) { r5=(r6>=64 ? 0 : r5<<r6); NEXT }
ABC_JIT_CC abc_value shl_5_7(ABC_JIT_ARGS) { r5=(r7>=64 ? 0 : r5<<r7); NEXT }
ABC_JIT_CC abc_value shl_6_0(ABC_JIT_ARGS) { r6=(r0>=64 ? 0 : r6<<r0); NEXT }
ABC_JIT_CC abc_value shl_6_1(ABC_JIT_ARGS) { r6=(r1>=64 ? 0 : r6<<r1); NEXT }
ABC_JIT_CC abc_value shl_6_2(ABC_JIT_ARGS) { r6=(r2>=64 ? 0 : r6<<r2); NEXT }
ABC_JIT_CC abc_value shl_6_3(ABC_JIT_ARGS) { r6=(r3>=64 ? 0 : r6<<r3); NEXT }
ABC_JIT_CC abc_value shl_6_4(ABC_JIT_ARGS) { r6=(r4>=64 ? 0 : r6<<r4); NEXT }
ABC_JIT_CC abc_value shl_6_5(ABC_JIT_ARGS) { r6=(r5>=64 ? 0 : r6<<r5); NEXT }
ABC_JIT_CC abc_value shl_6_6(ABC_JIT_ARGS) { r6=(r6>=64 ? 0 : r6<<r6); NEXT }
ABC_JIT_CC abc_value shl_6_7(ABC_JIT_ARGS) { r6=(r7>=64 ? 0 : r6<<r7); NEXT }
ABC_JIT_CC abc_value shl_7_0(ABC_JIT_ARGS) { r7=(r0>=64 ? 0 : r7<<r0); NEXT }
ABC_JIT_CC abc_value shl_7_1(ABC_JIT_ARGS) { r7=(r1>=64 ? 0 : r7<<r1); NEXT }
ABC_JIT_CC abc_value shl_7_2(ABC_JIT_ARGS) { r7=(r2>=64 ? 0 : r7<<r2); NEXT }
ABC_JIT_CC abc_value shl_7_3(ABC_JIT_ARGS) { r7=(r3>=64 ? 0 : r7<<r3); NEXT }
ABC_JIT_CC abc_value shl_7_4(ABC_JIT_ARGS) { r7=(r4>=64 ? 0 : r7<<r4); NEXT }
ABC_JIT_CC abc_value shl_7_5(ABC_JIT_ARGS) { r7=(r5>=64 ? 0 : r7<<r5); NEXT }
ABC_JIT_CC abc_value shl_7_6(ABC_JIT_ARGS) { r7=(r6>=64 ? 0 : r7<<r6); NEXT }
ABC_JIT_CC abc_value shl_7_7(ABC_JIT_ARGS) { r7=(r7>=64 ? 0 : r7<<r7); NEXT }
ABC_JIT_CC abc_value shr_0_0(ABC_JIT_ARGS) { r0=(r0>=64 ? 0 : r0>>r0); NEXT }
ABC_JIT_CC abc_value shr_0_1(ABC_JIT_ARGS) { r0=(r1>=64 ? 0 : r0>>r1); NEXT }
ABC_JIT_CC abc_value shr_0_2(ABC_JIT_ARGS) { r0=(r2>=64 ? 0 : r0>>r2); NEXT }
ABC_JIT_CC abc_value shr_0_3(ABC_JIT_ARGS) { r0=(r3>=64 ? 0 : r0>>r3); NEXT }
ABC_JIT_CC abc_value shr_0_4(ABC_JIT_ARGS) { r0=(r4>=64 ? 0 : r0>>r4); NEXT }
ABC_JIT_CC abc_value shr_0_5(ABC_JIT_ARGS) { r0=(r5>=64 ? 0 : r0>>r5); NEXT }
ABC_JIT_CC abc_value shr_0_6(ABC_JIT_ARGS) { r0=(r6>=64 ? 0 : r0>>r6); NEXT }
ABC_JIT_CC abc_value shr_0_7(ABC_JIT_ARGS) { r0=(r7>=64 ? 0 : r0>>r7); NEXT }
ABC_JIT_CC abc_value shr_1_0(ABC_JIT_ARGS) { r1=(r0>=64 ? 0 : r1>>r0); NEXT }
ABC_JIT_CC abc_value shr_1_1(ABC_JIT_ARGS) { r1=(r1>=64 ? 0 : r1>>r1); NEXT }
ABC_JIT_CC abc_value shr_1_2(ABC_JIT_ARGS) { r1=(r2>=64 ? 0 : r1>>r2); NEXT }
ABC_JIT_CC abc_value shr_1_3(ABC_JIT_ARGS) { r1=(r3>=64 ? 0 : r1>>r3); NEXT }
ABC_JIT_CC abc_value shr_1_4(ABC_JIT_ARGS) { r1=(r4>=64 ? 0 : r1>>r4); NEXT }
ABC_JIT_CC abc_value shr_1_5(ABC_JIT_ARGS) { r1=(r5>=64 ? 0 : r1>>r5); NEXT }
ABC_JIT_CC abc_value shr_1_6(ABC_JIT_ARGS) { r1=(r6>=64 ? 0 : r1>>r6); NEXT }
ABC_JIT_CC abc_value shr_1_7(ABC_JIT_ARGS) { r1=(r7>=64 ? 0 : r1>>r7); NEXT }
ABC_JIT_CC abc_value shr_2_0(ABC_JIT_ARGS) { r2=(r0>=64 ? 0 : r2>>r0); NEXT }
ABC_JIT_CC abc_value shr_2_1(ABC_JIT_ARGS) { r2=(r1>=64 ? 0 : r2>>r1); NEXT }
ABC_JIT_CC abc_value shr_2_2(ABC_JIT_ARGS) { r2=(r2>=64 ? 0 : r2>>r2); NEXT }
ABC_JIT_CC abc_value shr_2_3(ABC_JIT_ARGS) { r2=(r3>=64 ? 0 : r2>>r3); NEXT }
ABC_JIT_CC abc_value shr_2_4(ABC_JIT_ARGS) { r2=(r4>=64 ? 0 : r2>>r4); NEXT }
ABC_JIT_CC abc_value shr_2_5(ABC_JIT_ARGS) { r2=(r5>=64 ? 0 : r2>>r5); NEXT }
ABC_JIT_CC abc_value shr_2_6(ABC_JIT_ARGS) { r2=(r6>=64 ? 0 : r2>>r6); NEXT }
ABC_JIT_CC abc_value shr_2_7(ABC_JIT_ARGS) { r2=(r7>=64 ? 0 : r2>>r7); NEXT }
ABC_JIT_CC abc_value shr_3_0(ABC_JIT_ARGS) { r3=(r0>=64 ? 0 : r3>>r0); NEXT }
ABC_JIT_CC abc_value shr_3_1(ABC_JIT_ARGS) { r3=(r1>=64 ? 0 : r3>>r1); NEXT }
ABC_JIT_CC abc_value shr_3_2(ABC_JIT_ARGS) { r3=(r2>=64 ? 0 : r3>>r2); NEXT }
ABC_JIT_CC abc_value shr_3_3(ABC_JIT_ARGS) { r3=(r3>=64 ? 0 : r3>>r3); NEXT }
ABC_JIT_CC abc_value shr_3_4(ABC_JIT_ARGS) { r3=(r4>=64 ? 0 : r3>>r4); NEXT }
ABC_JIT_CC abc_value shr_3_5(ABC_JIT_ARGS) { r3=(r5>=64 ? 0 : r3>>r5); NEXT }
ABC_JIT_CC abc_value shr_3_6(ABC_JIT_ARGS) { r3=(r6>=64 ? 0 : r3>>r6); NEXT }
ABC_JIT_CC abc_value shr_3_7(ABC_JIT_ARGS) { r3=(r7>=64 ? 0 : r3>>r7); NEXT }
ABC_JIT_CC abc_value shr_4_0(ABC_JIT_ARGS) { r4=(r0>=64 ? 0 : r4>>r0); NEXT }
ABC_JIT_CC abc_value shr_4_1(ABC_JIT_ARGS) { r4=(r1>=64 ? 0 : r4>>r1); NEXT }
ABC_JIT_CC abc_value shr_4_2(ABC_JIT_ARGS) { r4=(r2>=64 ? 0 : r4>>r2); NEXT }
ABC_JIT_CC abc_value shr_4_3(ABC_JIT_ARGS) { r4=(r3>=64 ? 0 : r4>>r3); NEXT }
ABC_JIT_CC abc_value shr_4_4(ABC_JIT_ARGS) { r4=(r4>=64 ? 0 : r4>>r4); NEXT }
ABC_JIT_CC abc_value shr_4_5(ABC_JIT_ARGS) { r4=(r5>=64 ? 0 : r4>>r5); NEXT }
ABC_JIT_CC abc_value shr_4_6(ABC_JIT_ARGS) { r4=(r6>=64 ? 0 : r4>>r6); NEXT }
ABC_JIT_CC abc_value shr_4_7(ABC_JIT_ARGS) { r4=(r7>=64 ? 0 : r4>>r7); NEXT }
ABC_JIT_CC abc_value shr_5_0(ABC_JIT_ARGS) { r5=(r0>=64 ? 0 : r5>>r0); NEXT }
ABC_JIT_CC abc_value shr_5_1(ABC_JIT_ARGS) { r5=(r1>=64 ? 0 : r5>>r1); NEXT }
ABC_JIT_CC abc_value shr_5_2(ABC_JIT_ARGS) { r5=(r2>=64 ? 0 : r5>>r2); NEXT }
ABC_JIT_CC abc_value shr_5_3(ABC_JIT_ARGS) { r5=(r3>=64 ? 0 : r5>>r3); NEXT }
ABC_JIT_CC abc_value shr_5_4(ABC_JIT_ARGS) { r5=(r4>=64 ? 0 : r5>>r4); NEXT }
ABC_JIT_CC abc_value shr_5_5(ABC_JIT_ARGS) { r5=(r5>=64 ? 0 : r5>>r5); NEXT }
ABC_JIT_CC abc_value shr_5_6(ABC_JIT_ARGS) { r5=(r6>=64 ? 0 : r5>>r6); NEXT }
ABC_JIT_CC abc_value shr_5_7(ABC_JIT_ARGS) { r5=(r7>=64 ? 0 : r5>>r7); NEXT }
ABC_JIT_CC abc_value shr_6_0(ABC_JIT_ARGS) { r6=(r0>=64 ? 0 : r6>>r0); NEXT }
ABC_JIT_CC abc_value shr_6_1(ABC_JIT_ARGS) { r6=(r1>=64 ? 0 : r6>>r1); NEXT }
ABC_JIT_CC abc_value shr_6_2(ABC_JIT_ARGS) { r6=(r2>=64 ? 0 : r6>>r2); NEXT }
ABC_JIT_CC abc_value shr_6_3(ABC_JIT_ARGS) { r6=(r3>=64 ? 0 : r6>>r3); NEXT }
ABC_JIT_CC abc_value shr_6_4(ABC_JIT_ARGS) { r6=(r4>=64 ? 0 : r6>>r4); NEXT }
ABC_JIT_CC abc_value shr_6_5(ABC_JIT_ARGS) { r6=(r5>=64 ? 0 : r6>>r5); NEXT }
ABC_JIT_CC abc_value shr_6_6(ABC_JIT_ARGS) { r6=(r6>=64 ? 0 : r6>>r6); NEXT }
ABC_JIT_CC abc_value shr_6_7(ABC_JIT_ARGS) { r6=(r7>=64 ? 0 : r6>>r7); NEXT }
ABC_JIT_CC abc_value shr_7_0(ABC_JIT_ARGS) { r7=(r0>=64 ? 0 : r7>>r0); NEXT }
ABC_JIT_CC abc_value shr_7_1(ABC_JIT_ARGS) { r7=(r1>=64 ? 0 : r7>>r1); NEXT }
ABC_JIT_CC abc_value shr_7_2(ABC_JIT_ARGS) { r7=(r2>=64 ? 0 : r7>>r2); NEXT }
ABC_JIT_CC abc_value shr_7_3(ABC_JIT_ARGS) { r7=(r3>=64 ? 0 : r7>>r3); NEXT }
ABC_JIT_CC abc_value shr_7_4(ABC_JIT_ARGS) { r7=(r4>=64 ? 0 : r7>>r4); NEXT }
ABC_JIT_CC abc_value shr_7_5(ABC_JIT_ARGS) { r7=(r5>=64 ? 0 : r7>>r5); NEXT }
ABC_JIT_CC abc_value shr_7_6(ABC_JIT_ARGS) { r7=(r6>=64 ? 0 : r7>>r6); NEXT }
ABC_JIT_CC abc_value shr_7_7(ABC_JIT_ARGS) { r7=(r7>=64 ? 0 : r7>>r7); NEXT }
ABC_JIT_CC abc_value sar_0_0(ABC_JIT_ARGS) { r0=vm_sar(r0,r0); NEXT }
ABC_JIT_CC abc_value sar_0_1(ABC_JIT_ARGS) { r0=vm_sar(r0,r1); NEXT }
ABC_JIT_CC abc_value sar_0_2(ABC_JIT_ARGS) { r0=vm_sar(r0,r2); NEXT }
ABC_JIT_CC abc_value sar_0_3(ABC_JIT_ARGS) { r0=vm_sar(r0,r3); NEXT }
ABC_JIT_CC abc_value sar_0_4(ABC_JIT_ARGS) { r0=vm_sar(r0,r4); NEXT }
ABC_JIT_CC abc_value sar_0_5(ABC_JIT_ARGS) { r0=vm_sar(r0,r5); NEXT }
ABC_JIT_CC abc_value sar_0_6(ABC_JIT_ARGS) { r0=vm_sar(r0,r6); NEXT }
ABC_JIT_CC abc_value sar_0_7(ABC_JIT_ARGS) { r0=vm_sar(r0,r7); NEXT }
ABC_JIT_CC abc_value sar_1_0(ABC_JIT_ARGS) { r1=vm_sar(r1,r0); NEXT }
ABC_JIT_CC abc_value sar_1_1(ABC_JIT_ARGS) { r1=vm_sar(r1,r1); NEXT }
ABC_JIT_CC abc_value sar_1_2(ABC_JIT_ARGS) { r1=vm_sar(r1,r2); NEXT }
ABC_JIT_CC abc_value sar_1_3(ABC_JIT_ARGS) { r1=vm_sar(r1,r3); NEXT }
ABC_JIT_CC abc_value sar_1_4(ABC_JIT_ARGS) { r1=vm_sar(r1,r4); NEXT }
ABC_JIT_CC abc_value sar_1_5(ABC_JIT_ARGS) { r1=vm_sar(r1,r5); NEXT }
ABC_JIT_CC abc_value sar_1_6(ABC_JIT_ARGS) { r1=vm_sar(r1,r6); NEXT }
ABC_JIT_CC abc_value sar_1_7(ABC_JIT_ARGS) { r1=vm_sar(r1,r7); NEXT }
ABC_JIT_CC abc_value sar_2_0(ABC_JIT_ARGS) { r2=vm_sar(r2,r0); NEXT }
ABC_JIT_CC abc_value sar_2_1(ABC_JIT_ARGS) { r2=vm_sar(r2,r1); NEXT }
ABC_JIT_CC abc_value sar_2_2(ABC_JIT_ARGS) { r2=vm_sar(r2,r2); NEXT }
ABC_JIT_CC abc_value sar_2_3(ABC_JIT_ARGS) { r2=vm_sar(r2,r3); NEXT }
ABC_JIT_CC abc_value sar_2_4(ABC_JIT_ARGS) { r2=vm_sar(r2,r4); NEXT }
ABC_JIT_CC abc_value sar_2_5(ABC_JIT_ARGS) { r2=vm_sar(r2,r5); NEXT }
ABC_JIT_CC abc_value sar_2_6(ABC_JIT_ARGS) { r2=vm_sar(r2,r6); NEXT }
ABC_JIT_CC abc_value sar_2_7(ABC_JIT_ARGS) { r2=vm_sar(r2,r7); NEXT }
ABC_JIT_CC abc_value sar_3_0(ABC_JIT_ARGS) { r3=vm_sar(r3,r0); NEXT }
ABC_JIT_CC abc_value sar_3_1(ABC_JIT_ARGS) { r3=vm_sar(r3,r1); NEXT }
ABC_JIT_CC abc_value sar_3_2(ABC_JIT_ARGS) { r3=vm_sar(r3,r2); NEXT }
ABC_JIT_CC abc_value sar_3_3(ABC_JIT_ARGS) { r3=vm_sar(r3,r3); NEXT }
ABC_JIT_CC abc_value sar_3_4(ABC_JIT_ARGS) { r3=vm_sar(r3,r4); NEXT }
ABC_JIT_CC abc_value sar_3_5(ABC_JIT_ARGS) { r3=vm_sar(r3,r5); NEXT }
ABC_JIT_CC abc_value sar_3_6(ABC_JIT_ARGS) { r3=vm_sar(r3,r6); NEXT }
ABC_JIT_CC abc_value sar_3_7(ABC_JIT_ARGS) { r3=vm_sar(r3,r7); NEXT }
ABC_JIT_CC abc_value sar_4_0(ABC_JIT_ARGS) { r4=vm_sar(r4,r0); NEXT }
ABC_JIT_CC abc_value sar_4_1(ABC_JIT_ARGS) { r4=vm_sar(r4,r1); NEXT }
ABC_JIT_CC abc_value sar_4_2(ABC_JIT_ARGS) { r4=vm_sar(r4,r2); NEXT }
ABC_JIT_CC abc_value sar_4_3(ABC_JIT_ARGS) { r4=vm_sar(r4,r3); NEXT }
ABC_JIT_CC abc_value sar_4_4(ABC_JIT_ARGS) { r4=vm_sar(r4,r4); NEXT }
ABC_JIT_CC abc_value sar_4_5(ABC_JIT_ARGS) { r4=vm_sar(r4,r5); NEXT }
ABC_JIT_CC abc_value sar_4_6(ABC_JIT_ARGS) { r4=vm_sar(r4,r6); NEXT }
ABC_JIT_CC abc_value sar_4_7(ABC_JIT_ARGS) { r4=vm_sar(r4,r7); NEXT }
ABC_JIT_CC abc_value sar_5_0(ABC_JIT_ARGS) { r5=vm_sar(r5,r0); NEXT }
ABC_JIT_CC abc_value sar_5_1(ABC_JIT_ARGS) { r5=vm_sar(r5,r1); NEXT }
ABC_JIT_CC abc_value sar_5_2(ABC_JIT_ARGS) { r5=vm_sar(r5,r2); NEXT }
ABC_JIT_CC abc_value sar_5_3(ABC_JIT_ARGS) { r5=vm_sar(r5,r3); NEXT }
ABC_JIT_CC abc_value sar_5_4(ABC_JIT_ARGS) { r5=vm_sar(r5,r4); NEXT }
ABC_JIT_CC abc_value sar_5_5(ABC_JIT_ARGS) { r5=vm_sar(r5,r5); NEXT }
ABC_JIT_CC abc_value sar_5_6(ABC_JIT_ARGS) { r5=vm_sar(r5,r6); NEXT }
ABC_JIT_CC abc_value sar_5_7(ABC_JIT_ARGS) { r5=vm_sar(r5,r7); NEXT }
ABC_JIT_CC abc_value sar_6_0(ABC_JIT_ARGS) { r6=vm_sar(r6,r0); NEXT }
ABC_JIT_CC abc_value sar_6_1(ABC_JIT_ARGS) { r6=vm_sar(r6,r1); NEXT }
ABC_JIT_CC abc_value sar_6_2(ABC_JIT_ARGS) { r6=vm_sar(r6,r2); NEXT }
ABC_JIT_CC abc_value sar_6_3(ABC_JIT_ARGS) { r6=vm_sar(r6,r3); NEXT }
ABC_JIT_CC abc_value sar_6_4(ABC_JIT_ARGS) { r6=vm_sar(r6,r4); NEXT }
ABC_JIT_CC abc_value sar_6_5(ABC_JIT_ARGS) { r6=vm_sar(r6,r5); NEXT }
ABC_JIT_CC abc_value sar_6_6(ABC_JIT_ARGS) { r6=vm_sar(r6,r6); NEXT }
ABC_JIT_CC abc_value sar_6_7(ABC_JIT_ARGS) { r6=vm_sar(r6,r7); NEXT }
ABC_JIT_CC abc_value sar_7_0(ABC_JIT_ARGS) { r7=vm_sar(r7,r0); NEXT }
ABC_JIT_CC abc_value sar_7_1(ABC_JIT_ARGS) { r7=vm_sar(r7,r1); NEXT }
ABC_JIT_CC abc_value sar_7_2(ABC_JIT_ARGS) { r7=vm_sar(r7,r2); NEXT }
ABC_JIT_CC abc_value sar_7_3(ABC_JIT_ARGS) { r7=vm_sar(r7,r3); NEXT }
ABC_JIT_CC abc_value sar_7_4(ABC_JIT_ARGS) { r7=vm_sar(r7,r4); NEXT }
ABC_JIT_CC abc_value sar_7_5(ABC_JIT_ARGS) { r7=vm_sar(r7,r5); NEXT }
ABC_JIT_CC abc_value sar_7_6(ABC_JIT_ARGS) { r7=vm_sar(r7,r6); NEXT }
ABC_JIT_CC abc_value sar_7_7(ABC_JIT_ARGS) { r7=vm_sar(r7,r7); NEXT }
ABC_JIT_CC abc_value eq_0_0(ABC_JIT_ARGS) { r0=r0==r0; NEXT }
ABC_JIT_CC abc_value eq_0_1(ABC_JIT_ARGS) { r0=r0==r1; NEXT }
ABC_JIT_CC abc_value eq_0_2(ABC_JIT_ARGS) { r0=r0==r2; NEXT }
ABC_JIT_CC abc_value eq_0_3(ABC_JIT_ARGS) { r0=r0==r3; NEXT }
ABC_JIT_CC abc_value eq_0_4(ABC_JIT_ARGS) { r0=r0==r4; NEXT }
ABC_JIT_CC abc_value eq_0_5(ABC_JIT_ARGS) { r0=r0==r5; NEXT }
ABC_JIT_CC abc_value eq_0_6(ABC_JIT_ARGS) { r0=r0==r6; NEXT }
ABC_JIT_CC abc_value eq_0_7(ABC_JIT_ARGS) { r0=r0==r7; NEXT }
ABC_JIT_CC abc_value eq_1_0(ABC_JIT_ARGS) { r1=r1==r0; NEXT }
ABC_JIT_CC abc_value eq_1_1(ABC_JIT_ARGS) { r1=r1==r1; NEXT }
ABC_JIT_CC abc_value eq_1_2(ABC_JIT_ARGS) { r1=r1==r2; NEXT }
ABC_JIT_CC abc_value eq_1_3(ABC_JIT_ARGS) { r1=r1==r3; NEXT }
ABC_JIT_CC abc_value eq_1_4(ABC_JIT_ARGS) { r1=r1==r4; NEXT }
ABC_JIT_CC abc_value eq_1_5(ABC_JIT_ARGS) { r1=r1==r5; NEXT }
ABC_JIT_CC abc_value eq_1_6(ABC_JIT_ARGS) { r1=r1==r6; NEXT }
ABC_JIT_CC abc_value eq_1_7(ABC_JIT_ARGS) { r1=r1==r7; NEXT }
ABC_JIT_CC abc_value eq_2_0(ABC_JIT_ARGS) { r2=r2==r0; NEXT }
ABC_JIT_CC abc_value eq_2_1(ABC_JIT_ARGS) { r2=r2==r1; NEXT }
ABC_JIT_CC abc_value eq_2_2(ABC_JIT_ARGS) { r2=r2==r2; NEXT }
ABC_JIT_CC abc_value eq_2_3(ABC_JIT_ARGS) { r2=r2==r3; NEXT }
ABC_JIT_CC abc_value eq_2_4(ABC_JIT_ARGS) { r2=r2==r4; NEXT }
ABC_JIT_CC abc_value eq_2_5(ABC_JIT_ARGS) { r2=r2==r5; NEXT }
ABC_JIT_CC abc_value eq_2_6(ABC_JIT_ARGS) { r2=r2==r6; NEXT }
ABC_JIT_CC abc_value eq_2_7(ABC_JIT_ARGS) { r2=r2==r7; NEXT }
ABC_JIT_CC abc_value eq_3_0(ABC_JIT_ARGS) { r3=r3==r0; NEXT }
ABC_JIT_CC abc_value eq_3_1(ABC_JIT_ARGS) { r3=r3==r1; NEXT }
ABC_JIT_CC abc_value eq_3_2(ABC_JIT_ARGS) { r3=r3==r2; NEXT }
ABC_JIT_CC abc_value eq_3_3(ABC_JIT_ARGS) { r3=r3==r3; NEXT }
ABC_JIT_CC abc_value eq_3_4(ABC_JIT_ARGS) { r3=r3==r4; NEXT }
ABC_JIT_CC abc_value eq_3_5(ABC_JIT_ARGS) { r3=r3==r5; NEXT }
ABC_JIT_CC abc_value eq_3_6(ABC_JIT_ARGS) { r3=r3==r6; NEXT }
ABC_JIT_CC abc_value eq_3_7(ABC_JIT_ARGS) { r3=r3==r7; NEXT }
ABC_JIT_CC abc_value eq_4_0(ABC_JIT_ARGS) { r4=r4==r0; NEXT }
ABC_JIT_CC abc_value eq_4_1(ABC_JIT_ARGS) { r4=r4==r1; NEXT }
ABC_JIT_CC abc_value eq_4_2(ABC_JIT_ARGS) { r4=r4==r2; NEXT }
ABC_JIT_CC abc_value eq_4_3(ABC_JIT_ARGS) { r4=r4==r3; NEXT }
ABC_JIT_CC abc_value eq_4_4(ABC_JIT_ARGS) { r4=r4==r4; NEXT }
ABC_JIT_CC abc_value eq_4_5(ABC_JIT_ARGS) { r4=r4==r5; NEXT }
ABC_JIT_CC abc_value eq_4_6(ABC_JIT_ARGS) { r4=r4==r6; NEXT }
ABC_JIT_CC abc_value eq_4_7(ABC_JIT_ARGS) { r4=r4==r7; NEXT }
ABC_JIT_CC abc_value eq_5_0(ABC_JIT_ARGS) { r5=r5==r0; NEXT }
ABC_JIT_CC abc_value eq_5_1(ABC_JIT_ARGS) { r5=r5==r1; NEXT }
ABC_JIT_CC abc_value eq_5_2(ABC_JIT_ARGS) { r5=r5==r2; NEXT }
ABC_JIT_CC abc_value eq_5_3(ABC_JIT_ARGS) { r5=r5==r3; NEXT }
ABC_JIT_CC abc_value eq_5_4(ABC_JIT_ARGS) { r5=r5==r4; NEXT }
ABC_JIT_CC abc_value eq_5_5(ABC_JIT_ARGS) { r5=r5==r5; NEXT }
ABC_JIT_CC abc_value eq_5_6(ABC_JIT_ARGS) { r5=r5==r6; NEXT }
ABC_JIT_CC abc_value eq_5_7(ABC_JIT_ARGS) { r5=r5==r7; NEXT }
ABC_JIT_CC abc_value eq_6_0(ABC_JIT_ARGS) { r6=r6==r0; NEXT }
ABC_JIT_CC abc_value eq_6_1(ABC_JIT_ARGS) { r6=r6==r1; NEXT }
ABC_JIT_CC abc_value eq_6_2(ABC_JIT_ARGS) { r6=r6==r2; NEXT }
ABC_JIT_CC abc_value eq_6_3(ABC_JIT_ARGS) { r6=r6==r3; NEXT }
ABC_JIT_CC abc_value eq_6_4(ABC_JIT_ARGS) { r6=r6==r4; NEXT }
ABC_JIT_CC abc_value eq_6_5(ABC_JIT_ARGS) { r6=r6==r5; NEXT }
ABC_JIT_CC abc_value eq_6_6(ABC_JIT_ARGS) { r6=r6==r6; NEXT }
ABC_JIT_CC abc_value eq_6_7(ABC_JIT_ARGS) { r6=r6==r7; NEXT }
ABC_JIT_CC abc_value eq_7_0(ABC_JIT_ARGS) { r7=r7==r0; NEXT }
ABC_JIT_CC abc_value eq_7_1(ABC_JIT_ARGS) { r7=r7==r1; NEXT }
ABC_JIT_CC abc_value eq_7_2(ABC_JIT_ARGS) { r7=r7==r2; NEXT }
ABC_JIT_CC abc_value eq_7_3(ABC_JIT_ARGS) { r7=r7==r3; NEXT }
ABC_JIT_CC abc_value eq_7_4(ABC_JIT_ARGS) { r7=r7==r4; NEXT }
ABC_JIT_CC abc_value eq_7_5(ABC_JIT_ARGS) { r7=r7==r5; NEXT }
ABC_JIT_CC abc_value eq_7_6(ABC_JIT_ARGS) { r7=r7==r6; NEXT }
ABC_JIT_CC abc_value eq_7_7(ABC_JIT_ARGS) { r7=r7==r7; NEXT }
ABC_JIT_CC abc_value ne_0_0(ABC_JIT_ARGS) { r0=r0!=r0; NEXT }
ABC_JIT_CC abc_value ne_0_1(ABC_JIT_ARGS) { r0=r0!=r1; NEXT }
ABC_JIT_CC abc_value ne_0_2(ABC_JIT_ARGS) { r0=r0!=r2; NEXT }
ABC_JIT_CC abc_value ne_0_3(ABC_JIT_ARGS) { r0=r0!=r3; NEXT }
ABC_JIT_CC abc_value ne_0_4(ABC_JIT_ARGS) { r0=r0!=r4; NEXT }
ABC_JIT_CC abc_value ne_0_5(ABC_JIT_ARGS) { r0=r0!=r5; NEXT }
ABC_JIT_CC abc_value ne_0_6(ABC_JIT_ARGS) { r0=r0!=r6; NEXT }
ABC_JIT_CC abc_value ne_0_7(ABC_JIT_ARGS) { r0=r0!=r7; NEXT }
ABC_JIT_CC abc_value ne_1_0(ABC_JIT_ARGS) { r1=r1!=r0; NEXT }
ABC_JIT_CC abc_value ne_1_1(ABC_JIT_ARGS) { r1=r1!=r1; NEXT }
ABC_JIT_CC abc_value ne_1_2(ABC_JIT_ARGS) { r1=r1!=r2; NEXT }
ABC_JIT_CC abc_value ne_1_3(ABC_JIT_ARGS) { r1=r1!=r3; NEXT }
ABC_JIT_CC abc_value ne_1_4(ABC_JIT_ARGS) { r1=r1!=r4; NEXT }
ABC_JIT_CC abc_value ne_1_5(ABC_JIT_ARGS) { r1=r1!=r5; NEXT }
ABC_JIT_CC abc_value ne_1_6(ABC_JIT_ARGS) { r1=r1!=r6; NEXT }
ABC_JIT_CC abc_value ne_1_7(ABC_JIT_ARGS) { r1=r1!=r7; NEXT }
ABC_JIT_CC abc_value ne_2_0(ABC_JIT_ARGS) { r2=r2!=r0; NEXT }
ABC_JIT_CC abc_value ne_2_1(ABC_JIT_ARGS) { r2=r2!=r1; NEXT }
ABC_JIT_CC abc_value ne_2_2(ABC_JIT_ARGS) { r2=r2!=r2; NEXT }
ABC_JIT_CC abc_value ne_2_3(ABC_JIT_ARGS) { r2=r2!=r3; NEXT }
ABC_JIT_CC abc_value ne_2_4(ABC_JIT_ARGS) { r2=r2!=r4; NEXT }
ABC_JIT_CC abc_value ne_2_5(ABC_JIT_ARGS) { r2=r2!=r5; NEXT }
ABC_JIT_CC abc_value ne_2_6(ABC_JIT_ARGS) { r2=r2!=r6; NEXT }
ABC_JIT_CC abc_value ne_2_7(ABC_JIT_ARGS) { r2=r2!=r7; NEXT }
ABC_JIT_CC abc_value ne_3_0(ABC_JIT_ARGS) { r3=r3!=r0; NEXT }
ABC_JIT_CC abc_value ne_3_1(ABC_JIT_ARGS) { r3=r3!=r1; NEXT }
ABC_JIT_CC abc_value ne_3_2(ABC_JIT_ARGS) { r3=r3!=r2; NEXT }
ABC_JIT_CC abc_value ne_3_3(ABC_JIT_ARGS) { r3=r3!=r3; NEXT }
ABC_JIT_CC abc_value ne_3_4(ABC_JIT_ARGS) { r3=r3!=r4; NEXT }
ABC_JIT_CC abc_value ne_3_5(ABC_JIT_ARGS) { r3=r3!=r5; NEXT }
ABC_JIT_CC abc_value ne_3_6(ABC_JIT_ARGS) { r3=r3!=r6; NEXT }
ABC_JIT_CC abc_value ne_3_7(ABC_JIT_ARGS) { r3=r3!=r7; NEXT }
ABC_JIT_CC abc_value ne_4_0(ABC_JIT_ARGS) { r4=r4!=r0; NEXT }
ABC_JIT_CC abc_value ne_4_1(ABC_JIT_ARGS) { r4=r4!=r1; NEXT }
ABC_JIT_CC abc_value ne_4_2(ABC_JIT_ARGS) { r4=r4!=r2; NEXT }
ABC_JIT_CC abc_value ne_4_3(ABC_JIT_ARGS) { r4=r4!=r3; NEXT }
ABC_JIT_CC abc_value ne_4_4(ABC_JIT_ARGS) { r4=r4!=r4; NEXT }
ABC_JIT_CC abc_value ne_4_5(ABC_JIT_ARGS) { r4=r4!=r5; NEXT }
ABC_JIT_CC abc_value ne_4_6(ABC_JIT_ARGS) { r4=r4!=r6; NEXT }
ABC_JIT_CC abc_value ne_4_7(ABC_JIT_ARGS) { r4=r4!=r7; NEXT }
ABC_JIT_CC abc_value ne_5_0(ABC_JIT_ARGS) { r5=r5!=r0; NEXT }
ABC_JIT_CC abc_value ne_5_1(ABC_JIT_ARGS) { r5=r5!=r1; NEXT }
ABC_JIT_CC abc_value ne_5_2(ABC_JIT_ARGS) { r5=r5!=r2; NEXT }
ABC_JIT_CC abc_value ne_5_3(ABC_JIT_ARGS) { r5=r5!=r3; NEXT }
ABC_JIT_CC abc_value ne_5_4(ABC_JIT_ARGS) { r5=r5!=r4; NEXT }
ABC_JIT_CC abc_value ne_5_5(ABC_JIT_ARGS) { r5=r5!=r5; NEXT }
ABC_JIT_CC abc_value ne_5_6(ABC_JIT_ARGS) { r5=r5!=r6; NEXT }
ABC_JIT_CC abc_value ne_5_7(ABC_JIT_ARGS) { r5=r5!=r7; NEXT }
ABC_JIT_CC abc_value ne_6_0(ABC_JIT_ARGS) { r6=r6!=r0; NEXT }
ABC_JIT_CC abc_value ne_6_1(ABC_JIT_ARGS) { r6=r6!=r1; NEXT }
ABC_JIT_CC abc_value ne_6_2(ABC_JIT_ARGS) { r6=r6!=r2; NEXT }
ABC_JIT_CC abc_value ne_6_3(ABC_JIT_ARGS) { r6=r6!=r3; NEXT }
ABC_JIT_CC abc_value ne_6_4(ABC_JIT_ARGS) { r6=r6!=r4; NEXT }
ABC_JIT_CC abc_value ne_6_5(ABC_JIT_ARGS) { r6=r6!=r5; NEXT }
ABC_JIT_CC abc_value ne_6_6(ABC_JIT_ARGS) { r6=r6!=r6; NEXT }
ABC_JIT_CC abc_value ne_6_7(ABC_JIT_ARGS) { r6=r6!=r7; NEXT }
ABC_JIT_CC abc_value ne_7_0(ABC_JIT_ARGS) { r7=r7!=r0; NEXT }
ABC_JIT_CC abc_value ne_7_1(ABC_JIT_ARGS) { r7=r7!=r1; NEXT }
ABC_JIT_CC abc_value ne_7_2(ABC_JIT_ARGS) { r7=r7!=r2; NEXT }
ABC_JIT_CC abc_value ne_7_3(ABC_JIT_ARGS) { r7=r7!=r3; NEXT }
ABC_JIT_CC abc_value ne_7_4(ABC_JIT_ARGS) { r7=r7!=r4; NEXT }
ABC_JIT_CC abc_value ne_7_5(ABC_JIT_ARGS) { r7=r7!=r5; NEXT }
ABC_JIT_CC abc_value ne_7_6(ABC_JIT_ARGS) { r7=r7!=r6; NEXT }
ABC_JIT_CC abc_value ne_7_7(ABC_JIT_ARGS) { r7=r7!=r7; NEXT }
ABC_JIT_CC abc_value lt_0_0(ABC_JIT_ARGS) { r0=abc_signed(r0)<abc_signed(r0); NEXT }
ABC_JIT_CC abc_value lt_0_1(ABC_JIT_ARGS) { r0=abc_signed(r0)<abc_signed(r1); NEXT }
ABC_JIT_CC abc_value lt_0_2(ABC_JIT_ARGS) { r0=abc_signed(r0)<abc_signed(r2); NEXT }
ABC_JIT_CC abc_value lt_0_3(ABC_JIT_ARGS) { r0=abc_signed(r0)<abc_signed(r3); NEXT }
ABC_JIT_CC abc_value lt_0_4(ABC_JIT_ARGS) { r0=abc_signed(r0)<abc_signed(r4); NEXT }
ABC_JIT_CC abc_value lt_0_5(ABC_JIT_ARGS) { r0=abc_signed(r0)<abc_signed(r5); NEXT }
ABC_JIT_CC abc_value lt_0_6(ABC_JIT_ARGS) { r0=abc_signed(r0)<abc_signed(r6); NEXT }
ABC_JIT_CC abc_value lt_0_7(ABC_JIT_ARGS) { r0=abc_signed(r0)<abc_signed(r7); NEXT }
ABC_JIT_CC abc_value lt_1_0(ABC_JIT_ARGS) { r1=abc_signed(r1)<abc_signed(r0); NEXT }
ABC_JIT_CC abc_value lt_1_1(ABC_JIT_ARGS) { r1=abc_signed(r1)<abc_signed(r1); NEXT }
ABC_JIT_CC abc_value lt_1_2(ABC_JIT_ARGS) { r1=abc_signed(r1)<abc_signed(r2); NEXT }
ABC_JIT_CC abc_value lt_1_3(ABC_JIT_ARGS) { r1=abc_signed(r1)<abc_signed(r3); NEXT }
ABC_JIT_CC abc_value lt_1_4(ABC_JIT_ARGS) { r1=abc_signed(r1)<abc_signed(r4); NEXT }
ABC_JIT_CC abc_value lt_1_5(ABC_JIT_ARGS) { r1=abc_signed(r1)<abc_signed(r5); NEXT }
ABC_JIT_CC abc_value lt_1_6(ABC_JIT_ARGS) { r1=abc_signed(r1)<abc_signed(r6); NEXT }
ABC_JIT_CC abc_value lt_1_7(ABC_JIT_ARGS) { r1=abc_signed(r1)<abc_signed(r7); NEXT }
ABC_JIT_CC abc_value lt_2_0(ABC_JIT_ARGS) { r2=abc_signed(r2)<abc_signed(r0); NEXT }
ABC_JIT_CC abc_value lt_2_1(ABC_JIT_ARGS) { r2=abc_signed(r2)<abc_signed(r1); NEXT }
ABC_JIT_CC abc_value lt_2_2(ABC_JIT_ARGS) { r2=abc_signed(r2)<abc_signed(r2); NEXT }
ABC_JIT_CC abc_value lt_2_3(ABC_JIT_ARGS) { r2=abc_signed(r2)<abc_signed(r3); NEXT }
ABC_JIT_CC abc_value lt_2_4(ABC_JIT_ARGS) { r2=abc_signed(r2)<abc_signed(r4); NEXT }
ABC_JIT_CC abc_value lt_2_5(ABC_JIT_ARGS) { r2=abc_signed(r2)<abc_signed(r5); NEXT }
ABC_JIT_CC abc_value lt_2_6(ABC_JIT_ARGS) { r2=abc_signed(r2)<abc_signed(r6); NEXT }
ABC_JIT_CC abc_value lt_2_7(ABC_JIT_ARGS) { r2=abc_signed(r2)<abc_signed(r7); NEXT }
ABC_JIT_CC abc_value lt_3_0(ABC_JIT_ARGS) { r3=abc_signed(r3)<abc_signed(r0); NEXT }
ABC_JIT_CC abc_value lt_3_1(ABC_JIT_ARGS) { r3=abc_signed(r3)<abc_signed(r1); NEXT }
ABC_JIT_CC abc_value lt_3_2(ABC_JIT_ARGS) { r3=abc_signed(r3)<abc_signed(r2); NEXT }
ABC_JIT_CC abc_value lt_3_3(ABC_JIT_ARGS) { r3=abc_signed(r3)<abc_signed(r3); NEXT }
ABC_JIT_CC abc_value lt_3_4(ABC_JIT_ARGS) { r3=abc_signed(r3)<abc_signed(r4); NEXT }
ABC_JIT_CC abc_value lt_3_5(ABC_JIT_ARGS) { r3=abc_signed(r3)<abc_signed(r5); NEXT }
ABC_JIT_CC abc_value lt_3_6(ABC_JIT_ARGS) { r3=abc_signed(r3)<abc_signed(r6); NEXT }
ABC_JIT_CC abc_value lt_3_7(ABC_JIT_ARGS) { r3=abc_signed(r3)<abc_signed(r7); NEXT }
ABC_JIT_CC abc_value lt_4_0(ABC_JIT_ARGS) { r4=abc_signed(r4)<abc_signed(r0); NEXT }
ABC_JIT_CC abc_value lt_4_1(ABC_JIT_ARGS) { r4=abc_signed(r4)<abc_signed(r1); NEXT }
ABC_JIT_CC abc_value lt_4_2(ABC_JIT_ARGS) { r4=abc_signed(r4)<abc_signed(r2); NEXT }
ABC_JIT_CC abc_value lt_4_3(ABC_JIT_ARGS) { r4=abc_signed(r4)<abc_signed(r3); NEXT }
ABC_JIT_CC abc_value lt_4_4(ABC_JIT_ARGS) { r4=abc_signed(r4)<abc_signed(r4); NEXT }
ABC_JIT_CC abc_value lt_4_5(ABC_JIT_ARGS) { r4=abc_signed(r4)<abc_signed(r5); NEXT }
ABC_JIT_CC abc_value lt_4_6(ABC_JIT_ARGS) { r4=abc_signed(r4)<abc_signed(r6); NEXT }
ABC_JIT_CC abc_value lt_4_7(ABC_JIT_ARGS) { r4=abc_signed(r4)<abc_signed(r7); NEXT }
ABC_JIT_CC abc_value lt_5_0(ABC_JIT_ARGS) { r5=abc_signed(r5)<abc_signed(r0); NEXT }
ABC_JIT_CC abc_value lt_5_1(ABC_JIT_ARGS) { r5=abc_signed(r5)<abc_signed(r1); NEXT }
ABC_JIT_CC abc_value lt_5_2(ABC_JIT_ARGS) { r5=abc_signed(r5)<abc_signed(r2); NEXT }
ABC_JIT_CC abc_value lt_5_3(ABC_JIT_ARGS) { r5=abc_signed(r5)<abc_signed(r3); NEXT }
ABC_JIT_CC abc_value lt_5_4(ABC_JIT_ARGS) { r5=abc_signed(r5)<abc_signed(r4); NEXT }
ABC_JIT_CC abc_value lt_5_5(ABC_JIT_ARGS) { r5=abc_signed(r5)<abc_signed(r5); NEXT }
ABC_JIT_CC abc_value lt_5_6(ABC_JIT_ARGS) { r5=abc_signed(r5)<abc_signed(r6); NEXT }
ABC_JIT_CC abc_value lt_5_7(ABC_JIT_ARGS) { r5=abc_signed(r5)<abc_signed(r7); NEXT }
ABC_JIT_CC abc_value lt_6_0(ABC_JIT_ARGS) { r6=abc_signed(r6)<abc_signed(r0); NEXT }
ABC_JIT_CC abc_value lt_6_1(ABC_JIT_ARGS) { r6=abc_signed(r6)<abc_signed(r1); NEXT }
ABC_JIT_CC abc_value lt_6_2(ABC_JIT_ARGS) { r6=abc_signed(r6)<abc_signed(r2); NEXT }
ABC_JIT_CC abc_value lt_6_3(ABC_JIT_ARGS) { r6=abc_signed(r6)<abc_signed(r3); NEXT }
ABC_JIT_CC abc_value lt_6_4(ABC_JIT_ARGS) { r6=abc_signed(r6)<abc_signed(r4); NEXT }
ABC_JIT_CC abc_value lt_6_5(ABC_JIT_ARGS) { r6=abc_signed(r6)<abc_signed(r5); NEXT }
ABC_JIT_CC abc_value lt_6_6(ABC_JIT_ARGS) { r6=abc_signed(r6)<abc_signed(r6); NEXT }
ABC_JIT_CC abc_value lt_6_7(ABC_JIT_ARGS) { r6=abc_signed(r6)<abc_signed(r7); NEXT }
ABC_JIT_CC abc_value lt_7_0(ABC_JIT_ARGS) { r7=abc_signed(r7)<abc_signed(r0); NEXT }
ABC_JIT_CC abc_value lt_7_1(ABC_JIT_ARGS) { r7=abc_signed(r7)<abc_signed(r1); NEXT }
ABC_JIT_CC abc_value lt_7_2(ABC_JIT_ARGS) { r7=abc_signed(r7)<abc_signed(r2); NEXT }
ABC_JIT_CC abc_value lt_7_3(ABC_JIT_ARGS) { r7=abc_signed(r7)<abc_signed(r3); NEXT }
ABC_JIT_CC abc_value lt_7_4(ABC_JIT_ARGS) { r7=abc_signed(r7)<abc_signed(r4); NEXT }
ABC_JIT_CC abc_value lt_7_5(ABC_JIT_ARGS) { r7=abc_signed(r7)<abc_signed(r5); NEXT }
ABC_JIT_CC abc_value lt_7_6(ABC_JIT_ARGS) { r7=abc_signed(r7)<abc_signed(r6); NEXT }
ABC_JIT_CC abc_value lt_7_7(ABC_JIT_ARGS) { r7=abc_signed(r7)<abc_signed(r7); NEXT }
ABC_JIT_CC abc_value le_0_0(ABC_JIT_ARGS) { r0=abc_signed(r0)<=abc_signed(r0); NEXT }
ABC_JIT_CC abc_value le_0_1(ABC_JIT_ARGS) { r0=abc_signed(r0)<=abc_signed(r1); NEXT }
ABC_JIT_CC abc_value le_0_2(ABC_JIT_ARGS) { r0=abc_signed(r0)<=abc_signed(r2); NEXT }
ABC_JIT_CC abc_value le_0_3(ABC_JIT_ARGS) { r0=abc_signed(r0)<=abc_signed(r3); NEXT }
ABC_JIT_CC abc_value le_0_4(ABC_JIT_ARGS) { r0=abc_signed(r0)<=abc_signed(r4); NEXT }
ABC_JIT_CC abc_value le_0_5(ABC_JIT_ARGS) { r0=abc_signed(r0)<=abc_signed(r5); NEXT }
ABC_JIT_CC abc_value le_0_6(ABC_JIT_ARGS) { r0=abc_signed(r0)<=abc_signed(r6); NEXT }
ABC_JIT_CC abc_value le_0_7(ABC_JIT_ARGS) { r0=abc_signed(r0)<=abc_signed(r7); NEXT }
ABC_JIT_CC abc_value le_1_0(ABC_JIT_ARGS) { r1=abc_signed(r1)<=abc_signed(r0); NEXT }
ABC_JIT_CC abc_value le_1_1(ABC_JIT_ARGS) { r1=abc_signed(r1)<=abc_signed(r1); NEXT }
ABC_JIT_CC abc_value le_1_2(ABC_JIT_ARGS) { r1=abc_signed(r1)<=abc_signed(r2); NEXT }
ABC_JIT_CC abc_value le_1_3(ABC_JIT_ARGS) { r1=abc_signed(r1)<=abc_signed(r3); NEXT }
ABC_JIT_CC abc_value le_1_4(ABC_JIT_ARGS) { r1=abc_signed(r1)<=abc_signed(r4); NEXT }
ABC_JIT_CC abc_value le_1_5(ABC_JIT_ARGS) { r1=abc_signed(r1)<=abc_signed(r5); NEXT }
ABC_JIT_CC abc_value le_1_6(ABC_JIT_ARGS) { r1=abc_signed(r1)<=abc_signed(r6); NEXT }
ABC_JIT_CC abc_value le_1_7(ABC_JIT_ARGS) { r1=abc_signed(r1)<=abc_signed(r7); NEXT }
ABC_JIT_CC abc_value le_2_0(ABC_JIT_ARGS) { r2=abc_signed(r2)<=abc_signed(r0); NEXT }
ABC_JIT_CC abc_value le_2_1(ABC_JIT_ARGS) { r2=abc_signed(r2)<=abc_signed(r1); NEXT }
ABC_JIT_CC abc_value le_2_2(ABC_JIT_ARGS) { r2=abc_signed(r2)<=abc_signed(r2); NEXT }
ABC_JIT_CC abc_value le_2_3(ABC_JIT_ARGS) { r2=abc_signed(r2)<=abc_signed(r3); NEXT }
ABC_JIT_CC abc_value le_2_4(ABC_JIT_ARGS) { r2=abc_signed(r2)<=abc_signed(r4); NEXT }
ABC_JIT_CC abc_value le_2_5(ABC_JIT_ARGS) { r2=abc_signed(r2)<=abc_signed(r5); NEXT }
ABC_JIT_CC abc_value le_2_6(ABC_JIT_ARGS) { r2=abc_signed(r2)<=abc_signed(r6); NEXT }
ABC_JIT_CC abc_value le_2_7(ABC_JIT_ARGS) { r2=abc_signed(r2)<=abc_signed(r7); NEXT }
ABC_JIT_CC abc_value le_3_0(ABC_JIT_ARGS) { r3=abc_signed(r3)<=abc_signed(r0); NEXT }
ABC_JIT_CC abc_value le_3_1(ABC_JIT_ARGS) { r3=abc_signed(r3)<=abc_signed(r1); NEXT }
ABC_JIT_CC abc_value le_3_2(ABC_JIT_ARGS) { r3=abc_signed(r3)<=abc_signed(r2); NEXT }
ABC_JIT_CC abc_value le_3_3(ABC_JIT_ARGS) { r3=abc_signed(r3)<=abc_signed(r3); NEXT }
ABC_JIT_CC abc_value le_3_4(ABC_JIT_ARGS) { r3=abc_signed(r3)<=abc_signed(r4); NEXT }
ABC_JIT_CC abc_value le_3_5(ABC_JIT_ARGS) { r3=abc_signed(r3)<=abc_signed(r5); NEXT }
ABC_JIT_CC abc_value le_3_6(ABC_JIT_ARGS) { r3=abc_signed(r3)<=abc_signed(r6); NEXT }
ABC_JIT_CC abc_value le_3_7(ABC_JIT_ARGS) { r3=abc_signed(r3)<=abc_signed(r7); NEXT }
ABC_JIT_CC abc_value le_4_0(ABC_JIT_ARGS) { r4=abc_signed(r4)<=abc_signed(r0); NEXT }
ABC_JIT_CC abc_value le_4_1(ABC_JIT_ARGS) { r4=abc_signed(r4)<=abc_signed(r1); NEXT }
ABC_JIT_CC abc_value le_4_2(ABC_JIT_ARGS) { r4=abc_signed(r4)<=abc_signed(r2); NEXT }
ABC_JIT_CC abc_value le_4_3(ABC_JIT_ARGS) { r4=abc_signed(r4)<=abc_signed(r3); NEXT }
ABC_JIT_CC abc_value le_4_4(ABC_JIT_ARGS) { r4=abc_signed(r4)<=abc_signed(r4); NEXT }
ABC_JIT_CC abc_value le_4_5(ABC_JIT_ARGS) { r4=abc_signed(r4)<=abc_signed(r5); NEXT }
ABC_JIT_CC abc_value le_4_6(ABC_JIT_ARGS) { r4=abc_signed(r4)<=abc_signed(r6); NEXT }
ABC_JIT_CC abc_value le_4_7(ABC_JIT_ARGS) { r4=abc_signed(r4)<=abc_signed(r7); NEXT }
ABC_JIT_CC abc_value le_5_0(ABC_JIT_ARGS) { r5=abc_signed(r5)<=abc_signed(r0); NEXT }
ABC_JIT_CC abc_value le_5_1(ABC_JIT_ARGS) { r5=abc_signed(r5)<=abc_signed(r1); NEXT }
ABC_JIT_CC abc_value le_5_2(ABC_JIT_ARGS) { r5=abc_signed(r5)<=abc_signed(r2); NEXT }
ABC_JIT_CC abc_value le_5_3(ABC_JIT_ARGS) { r5=abc_signed(r5)<=abc_signed(r3); NEXT }
ABC_JIT_CC abc_value le_5_4(ABC_JIT_ARGS) { r5=abc_signed(r5)<=abc_signed(r4); NEXT }
ABC_JIT_CC abc_value le_5_5(ABC_JIT_ARGS) { r5=abc_signed(r5)<=abc_signed(r5); NEXT }
ABC_JIT_CC abc_value le_5_6(ABC_JIT_ARGS) { r5=abc_signed(r5)<=abc_signed(r6); NEXT }
ABC_JIT_CC abc_value le_5_7(ABC_JIT_ARGS) { r5=abc_signed(r5)<=abc_signed(r7); NEXT }
ABC_JIT_CC abc_value le_6_0(ABC_JIT_ARGS) { r6=abc_signed(r6)<=abc_signed(r0); NEXT }
ABC_JIT_CC abc_value le_6_1(ABC_JIT_ARGS) { r6=abc_signed(r6)<=abc_signed(r1); NEXT }
ABC_JIT_CC abc_value le_6_2(ABC_JIT_ARGS) { r6=abc_signed(r6)<=abc_signed(r2); NEXT }
ABC_JIT_CC abc_value le_6_3(ABC_JIT_ARGS) { r6=abc_signed(r6)<=abc_signed(r3); NEXT }
ABC_JIT_CC abc_value le_6_4(ABC_JIT_ARGS) { r6=abc_signed(r6)<=abc_signed(r4); NEXT }
ABC_JIT_CC abc_value le_6_5(ABC_JIT_ARGS) { r6=abc_signed(r6)<=abc_signed(r5); NEXT }
ABC_JIT_CC abc_value le_6_6(ABC_JIT_ARGS) { r6=abc_signed(r6)<=abc_signed(r6); NEXT }
ABC_JIT_CC abc_value le_6_7(ABC_JIT_ARGS) { r6=abc_signed(r6)<=abc_signed(r7); NEXT }
ABC_JIT_CC abc_value le_7_0(ABC_JIT_ARGS) { r7=abc_signed(r7)<=abc_signed(r0); NEXT }
ABC_JIT_CC abc_value le_7_1(ABC_JIT_ARGS) { r7=abc_signed(r7)<=abc_signed(r1); NEXT }
ABC_JIT_CC abc_value le_7_2(ABC_JIT_ARGS) { r7=abc_signed(r7)<=abc_signed(r2); NEXT }
ABC_JIT_CC abc_value le_7_3(ABC_JIT_ARGS) { r7=abc_signed(r7)<=abc_signed(r3); NEXT }
ABC_JIT_CC abc_value le_7_4(ABC_JIT_ARGS) { r7=abc_signed(r7)<=abc_signed(r4); NEXT }
ABC_JIT_CC abc_value le_7_5(ABC_JIT_ARGS) { r7=abc_signed(r7)<=abc_signed(r5); NEXT }
ABC_JIT_CC abc_value le_7_6(ABC_JIT_ARGS) { r7=abc_signed(r7)<=abc_signed(r6); NEXT }
ABC_JIT_CC abc_value le_7_7(ABC_JIT_ARGS) { r7=abc_signed(r7)<=abc_signed(r7); NEXT }
ABC_JIT_CC abc_value ltu_0_0(ABC_JIT_ARGS) { r0=r0<r0; NEXT }
ABC_JIT_CC abc_value ltu_0_1(ABC_JIT_ARGS) { r0=r0<r1; NEXT }
ABC_JIT_CC abc_value ltu_0_2(ABC_JIT_ARGS) { r0=r0<r2; NEXT }
ABC_JIT_CC abc_value ltu_0_3(ABC_JIT_ARGS) { r0=r0<r3; NEXT }
ABC_JIT_CC abc_value ltu_0_4(ABC_JIT_ARGS) { r0=r0<r4; NEXT }
ABC_JIT_CC abc_value ltu_0_5(ABC_JIT_ARGS) { r0=r0<r5; NEXT }
ABC_JIT_CC abc_value ltu_0_6(ABC_JIT_ARGS) { r0=r0<r6; NEXT }
ABC_JIT_CC abc_value ltu_0_7(ABC_JIT_ARGS) { r0=r0<r7; NEXT }
ABC_JIT_CC abc_value ltu_1_0(ABC_JIT_ARGS) { r1=r1<r0; NEXT }
ABC_JIT_CC abc_value ltu_1_1(ABC_JIT_ARGS) { r1=r1<r1; NEXT }
ABC_JIT_CC abc_value ltu_1_2(ABC_JIT_ARGS) { r1=r1<r2; NEXT }
ABC_JIT_CC abc_value ltu_1_3(ABC_JIT_ARGS) { r1=r1<r3; NEXT }
ABC_JIT_CC abc_value ltu_1_4(ABC_JIT_ARGS) { r1=r1<r4; NEXT }
ABC_JIT_CC abc_value ltu_1_5(ABC_JIT_ARGS) { r1=r1<r5; NEXT }
ABC_JIT_CC abc_value ltu_1_6(ABC_JIT_ARGS) { r1=r1<r6; NEXT }
ABC_JIT_CC abc_value ltu_1_7(ABC_JIT_ARGS) { r1=r1<r7; NEXT }
ABC_JIT_CC abc_value ltu_2_0(ABC_JIT_ARGS) { r2=r2<r0; NEXT }
ABC_JIT_CC abc_value ltu_2_1(ABC_JIT_ARGS) { r2=r2<r1; NEXT }
ABC_JIT_CC abc_value ltu_2_2(ABC_JIT_ARGS) { r2=r2<r2; NEXT }
ABC_JIT_CC abc_value ltu_2_3(ABC_JIT_ARGS) { r2=r2<r3; NEXT }
ABC_JIT_CC abc_value ltu_2_4(ABC_JIT_ARGS) { r2=r2<r4; NEXT }
ABC_JIT_CC abc_value ltu_2_5(ABC_JIT_ARGS) { r2=r2<r5; NEXT }
ABC_JIT_CC abc_value ltu_2_6(ABC_JIT_ARGS) { r2=r2<r6; NEXT }
ABC_JIT_CC abc_value ltu_2_7(ABC_JIT_ARGS) { r2=r2<r7; NEXT }
ABC_JIT_CC abc_value ltu_3_0(ABC_JIT_ARGS) { r3=r3<r0; NEXT }
ABC_JIT_CC abc_value ltu_3_1(ABC_JIT_ARGS) { r3=r3<r1; NEXT }
ABC_JIT_CC abc_value ltu_3_2(ABC_JIT_ARGS) { r3=r3<r2; NEXT }
ABC_JIT_CC abc_value ltu_3_3(ABC_JIT_ARGS) { r3=r3<r3; NEXT }
ABC_JIT_CC abc_value ltu_3_4(ABC_JIT_ARGS) { r3=r3<r4; NEXT }
ABC_JIT_CC abc_value ltu_3_5(ABC_JIT_ARGS) { r3=r3<r5; NEXT }
ABC_JIT_CC abc_value ltu_3_6(ABC_JIT_ARGS) { r3=r3<r6; NEXT }
ABC_JIT_CC abc_value ltu_3_7(ABC_JIT_ARGS) { r3=r3<r7; NEXT }
ABC_JIT_CC abc_value ltu_4_0(ABC_JIT_ARGS) { r4=r4<r0; NEXT }
ABC_JIT_CC abc_value ltu_4_1(ABC_JIT_ARGS) { r4=r4<r1; NEXT }
ABC_JIT_CC abc_value ltu_4_2(ABC_JIT_ARGS) { r4=r4<r2; NEXT }
ABC_JIT_CC abc_value ltu_4_3(ABC_JIT_ARGS) { r4=r4<r3; NEXT }
ABC_JIT_CC abc_value ltu_4_4(ABC_JIT_ARGS) { r4=r4<r4; NEXT }
ABC_JIT_CC abc_value ltu_4_5(ABC_JIT_ARGS) { r4=r4<r5; NEXT }
ABC_JIT_CC abc_value ltu_4_6(ABC_JIT_ARGS) { r4=r4<r6; NEXT }
ABC_JIT_CC abc_value ltu_4_7(ABC_JIT_ARGS) { r4=r4<r7; NEXT }
ABC_JIT_CC abc_value ltu_5_0(ABC_JIT_ARGS) { r5=r5<r0; NEXT }
ABC_JIT_CC abc_value ltu_5_1(ABC_JIT_ARGS) { r5=r5<r1; NEXT }
ABC_JIT_CC abc_value ltu_5_2(ABC_JIT_ARGS) { r5=r5<r2; NEXT }
ABC_JIT_CC abc_value ltu_5_3(ABC_JIT_ARGS) { r5=r5<r3; NEXT }
ABC_JIT_CC abc_value ltu_5_4(ABC_JIT_ARGS) { r5=r5<r4; NEXT }
ABC_JIT_CC abc_value ltu_5_5(ABC_JIT_ARGS) { r5=r5<r5; NEXT }
ABC_JIT_CC abc_value ltu_5_6(ABC_JIT_ARGS) { r5=r5<r6; NEXT }
ABC_JIT_CC abc_value ltu_5_7(ABC_JIT_ARGS) { r5=r5<r7; NEXT }
ABC_JIT_CC abc_value ltu_6_0(ABC_JIT_ARGS) { r6=r6<r0; NEXT }
ABC_JIT_CC abc_value ltu_6_1(ABC_JIT_ARGS) { r6=r6<r1; NEXT }
ABC_JIT_CC abc_value ltu_6_2(ABC_JIT_ARGS) { r6=r6<r2; NEXT }
ABC_JIT_CC abc_value ltu_6_3(ABC_JIT_ARGS) { r6=r6<r3; NEXT }
ABC_JIT_CC abc_value ltu_6_4(ABC_JIT_ARGS) { r6=r6<r4; NEXT }
ABC_JIT_CC abc_value ltu_6_5(ABC_JIT_ARGS) { r6=r6<r5; NEXT }
ABC_JIT_CC abc_value ltu_6_6(ABC_JIT_ARGS) { r6=r6<r6; NEXT }
ABC_JIT_CC abc_value ltu_6_7(ABC_JIT_ARGS) { r6=r6<r7; NEXT }
ABC_JIT_CC abc_value ltu_7_0(ABC_JIT_ARGS) { r7=r7<r0; NEXT }
ABC_JIT_CC abc_value ltu_7_1(ABC_JIT_ARGS) { r7=r7<r1; NEXT }
ABC_JIT_CC abc_value ltu_7_2(ABC_JIT_ARGS) { r7=r7<r2; NEXT }
ABC_JIT_CC abc_value ltu_7_3(ABC_JIT_ARGS) { r7=r7<r3; NEXT }
ABC_JIT_CC abc_value ltu_7_4(ABC_JIT_ARGS) { r7=r7<r4; NEXT }
ABC_JIT_CC abc_value ltu_7_5(ABC_JIT_ARGS) { r7=r7<r5; NEXT }
ABC_JIT_CC abc_value ltu_7_6(ABC_JIT_ARGS) { r7=r7<r6; NEXT }
ABC_JIT_CC abc_value ltu_7_7(ABC_JIT_ARGS) { r7=r7<r7; NEXT }
ABC_JIT_CC abc_value leu_0_0(ABC_JIT_ARGS) { r0=r0<=r0; NEXT }
ABC_JIT_CC abc_value leu_0_1(ABC_JIT_ARGS) { r0=r0<=r1; NEXT }
ABC_JIT_CC abc_value leu_0_2(ABC_JIT_ARGS) { r0=r0<=r2; NEXT }
ABC_JIT_CC abc_value leu_0_3(ABC_JIT_ARGS) { r0=r0<=r3; NEXT }
ABC_JIT_CC abc_value leu_0_4(ABC_JIT_ARGS) { r0=r0<=r4; NEXT }
ABC_JIT_CC abc_value leu_0_5(ABC_JIT_ARGS) { r0=r0<=r5; NEXT }
ABC_JIT_CC abc_value leu_0_6(ABC_JIT_ARGS) { r0=r0<=r6; NEXT }
ABC_JIT_CC abc_value leu_0_7(ABC_JIT_ARGS) { r0=r0<=r7; NEXT }
ABC_JIT_CC abc_value leu_1_0(ABC_JIT_ARGS) { r1=r1<=r0; NEXT }
ABC_JIT_CC abc_value leu_1_1(ABC_JIT_ARGS) { r1=r1<=r1; NEXT }
ABC_JIT_CC abc_value leu_1_2(ABC_JIT_ARGS) { r1=r1<=r2; NEXT }
ABC_JIT_CC abc_value leu_1_3(ABC_JIT_ARGS) { r1=r1<=r3; NEXT }
ABC_JIT_CC abc_value leu_1_4(ABC_JIT_ARGS) { r1=r1<=r4; NEXT }
ABC_JIT_CC abc_value leu_1_5(ABC_JIT_ARGS) { r1=r1<=r5; NEXT }
ABC_JIT_CC abc_value leu_1_6(ABC_JIT_ARGS) { r1=r1<=r6; NEXT }
ABC_JIT_CC abc_value leu_1_7(ABC_JIT_ARGS) { r1=r1<=r7; NEXT }
ABC_JIT_CC abc_value leu_2_0(ABC_JIT_ARGS) { r2=r2<=r0; NEXT }
ABC_JIT_CC abc_value leu_2_1(ABC_JIT_ARGS) { r2=r2<=r1; NEXT }
ABC_JIT_CC abc_value leu_2_2(ABC_JIT_ARGS) { r2=r2<=r2; NEXT }
ABC_JIT_CC abc_value leu_2_3(ABC_JIT_ARGS) { r2=r2<=r3; NEXT }
ABC_JIT_CC abc_value leu_2_4(ABC_JIT_ARGS) { r2=r2<=r4; NEXT }
ABC_JIT_CC abc_value leu_2_5(ABC_JIT_ARGS) { r2=r2<=r5; NEXT }
ABC_JIT_CC abc_value leu_2_6(ABC_JIT_ARGS) { r2=r2<=r6; NEXT }
ABC_JIT_CC abc_value leu_2_7(ABC_JIT_ARGS) { r2=r2<=r7; NEXT }
ABC_JIT_CC abc_value leu_3_0(ABC_JIT_ARGS) { r3=r3<=r0; NEXT }
ABC_JIT_CC abc_value leu_3_1(ABC_JIT_ARGS) { r3=r3<=r1; NEXT }
ABC_JIT_CC abc_value leu_3_2(ABC_JIT_ARGS) { r3=r3<=r2; NEXT }
ABC_JIT_CC abc_value leu_3_3(ABC_JIT_ARGS) { r3=r3<=r3; NEXT }
ABC_JIT_CC abc_value leu_3_4(ABC_JIT_ARGS) { r3=r3<=r4; NEXT }
ABC_JIT_CC abc_value leu_3_5(ABC_JIT_ARGS) { r3=r3<=r5; NEXT }
ABC_JIT_CC abc_value leu_3_6(ABC_JIT_ARGS) { r3=r3<=r6; NEXT }
ABC_JIT_CC abc_value leu_3_7(ABC_JIT_ARGS) { r3=r3<=r7; NEXT }
ABC_JIT_CC abc_value leu_4_0(ABC_JIT_ARGS) { r4=r4<=r0; NEXT }
ABC_JIT_CC abc_value leu_4_1(ABC_JIT_ARGS) { r4=r4<=r1; NEXT }
ABC_JIT_CC abc_value leu_4_2(ABC_JIT_ARGS) { r4=r4<=r2; NEXT }
ABC_JIT_CC abc_value leu_4_3(ABC_JIT_ARGS) { r4=r4<=r3; NEXT }
ABC_JIT_CC abc_value leu_4_4(ABC_JIT_ARGS) { r4=r4<=r4; NEXT }
ABC_JIT_CC abc_value leu_4_5(ABC_JIT_ARGS) { r4=r4<=r5; NEXT }
ABC_JIT_CC abc_value leu_4_6(ABC_JIT_ARGS) { r4=r4<=r6; NEXT }
ABC_JIT_CC abc_value leu_4_7(ABC_JIT_ARGS) { r4=r4<=r7; NEXT }
ABC_JIT_CC abc_value leu_5_0(ABC_JIT_ARGS) { r5=r5<=r0; NEXT }
ABC_JIT_CC abc_value leu_5_1(ABC_JIT_ARGS) { r5=r5<=r1; NEXT }
ABC_JIT_CC abc_value leu_5_2(ABC_JIT_ARGS) { r5=r5<=r2; NEXT }
ABC_JIT_CC abc_value leu_5_3(ABC_JIT_ARGS) { r5=r5<=r3; NEXT }
ABC_JIT_CC abc_value leu_5_4(ABC_JIT_ARGS) { r5=r5<=r4; NEXT }
ABC_JIT_CC abc_value leu_5_5(ABC_JIT_ARGS) { r5=r5<=r5; NEXT }
ABC_JIT_CC abc_value leu_5_6(ABC_JIT_ARGS) { r5=r5<=r6; NEXT }
ABC_JIT_CC abc_value leu_5_7(ABC_JIT_ARGS) { r5=r5<=r7; NEXT }
ABC_JIT_CC abc_value leu_6_0(ABC_JIT_ARGS) { r6=r6<=r0; NEXT }
ABC_JIT_CC abc_value leu_6_1(ABC_JIT_ARGS) { r6=r6<=r1; NEXT }
ABC_JIT_CC abc_value leu_6_2(ABC_JIT_ARGS) { r6=r6<=r2; NEXT }
ABC_JIT_CC abc_value leu_6_3(ABC_JIT_ARGS) { r6=r6<=r3; NEXT }
ABC_JIT_CC abc_value leu_6_4(ABC_JIT_ARGS) { r6=r6<=r4; NEXT }
ABC_JIT_CC abc_value leu_6_5(ABC_JIT_ARGS) { r6=r6<=r5; NEXT }
ABC_JIT_CC abc_value leu_6_6(ABC_JIT_ARGS) { r6=r6<=r6; NEXT }
ABC_JIT_CC abc_value leu_6_7(ABC_JIT_ARGS) { r6=r6<=r7; NEXT }
ABC_JIT_CC abc_value leu_7_0(ABC_JIT_ARGS) { r7=r7<=r0; NEXT }
ABC_JIT_CC abc_value leu_7_1(ABC_JIT_ARGS) { r7=r7<=r1; NEXT }
ABC_JIT_CC abc_value leu_7_2(ABC_JIT_ARGS) { r7=r7<=r2; NEXT }
ABC_JIT_CC abc_value leu_7_3(ABC_JIT_ARGS) { r7=r7<=r3; NEXT }
ABC_JIT_CC abc_value leu_7_4(ABC_JIT_ARGS) { r7=r7<=r4; NEXT }
ABC_JIT_CC abc_value leu_7_5(ABC_JIT_ARGS) { r7=r7<=r5; NEXT }
ABC_JIT_CC abc_value leu_7_6(ABC_JIT_ARGS) { r7=r7<=r6; NEXT }
ABC_JIT_CC abc_value leu_7_7(ABC_JIT_ARGS) { r7=r7<=r7; NEXT }
ABC_JIT_CC abc_value u32_add_0_0(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r0):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_add_0_1(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r0):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_add_0_2(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r0):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_add_0_3(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r0):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_add_0_4(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r0):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_add_0_5(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r0):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_add_0_6(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r0):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_add_0_7(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r0):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_add_1_0(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r1):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_add_1_1(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r1):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_add_1_2(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r1):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_add_1_3(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r1):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_add_1_4(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r1):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_add_1_5(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r1):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_add_1_6(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r1):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_add_1_7(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r1):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_add_2_0(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r2):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_add_2_1(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r2):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_add_2_2(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r2):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_add_2_3(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r2):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_add_2_4(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r2):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_add_2_5(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r2):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_add_2_6(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r2):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_add_2_7(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r2):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_add_3_0(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r3):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_add_3_1(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r3):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_add_3_2(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r3):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_add_3_3(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r3):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_add_3_4(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r3):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_add_3_5(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r3):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_add_3_6(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r3):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_add_3_7(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r3):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_add_4_0(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r4):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_add_4_1(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r4):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_add_4_2(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r4):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_add_4_3(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r4):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_add_4_4(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r4):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_add_4_5(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r4):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_add_4_6(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r4):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_add_4_7(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r4):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_add_5_0(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r5):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_add_5_1(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r5):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_add_5_2(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r5):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_add_5_3(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r5):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_add_5_4(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r5):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_add_5_5(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r5):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_add_5_6(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r5):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_add_5_7(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r5):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_add_6_0(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r6):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_add_6_1(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r6):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_add_6_2(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r6):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_add_6_3(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r6):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_add_6_4(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r6):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_add_6_5(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r6):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_add_6_6(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r6):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_add_6_7(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r6):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_add_7_0(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r7):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_add_7_1(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r7):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_add_7_2(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r7):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_add_7_3(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r7):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_add_7_4(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r7):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_add_7_5(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r7):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_add_7_6(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r7):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_add_7_7(ABC_JIT_ARGS) { __asm__("addl %k1,%k0":"+r"(r7):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_sub_0_0(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r0):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_sub_0_1(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r0):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_sub_0_2(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r0):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_sub_0_3(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r0):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_sub_0_4(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r0):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_sub_0_5(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r0):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_sub_0_6(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r0):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_sub_0_7(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r0):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_sub_1_0(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r1):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_sub_1_1(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r1):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_sub_1_2(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r1):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_sub_1_3(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r1):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_sub_1_4(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r1):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_sub_1_5(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r1):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_sub_1_6(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r1):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_sub_1_7(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r1):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_sub_2_0(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r2):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_sub_2_1(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r2):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_sub_2_2(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r2):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_sub_2_3(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r2):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_sub_2_4(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r2):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_sub_2_5(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r2):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_sub_2_6(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r2):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_sub_2_7(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r2):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_sub_3_0(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r3):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_sub_3_1(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r3):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_sub_3_2(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r3):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_sub_3_3(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r3):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_sub_3_4(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r3):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_sub_3_5(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r3):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_sub_3_6(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r3):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_sub_3_7(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r3):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_sub_4_0(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r4):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_sub_4_1(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r4):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_sub_4_2(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r4):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_sub_4_3(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r4):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_sub_4_4(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r4):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_sub_4_5(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r4):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_sub_4_6(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r4):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_sub_4_7(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r4):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_sub_5_0(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r5):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_sub_5_1(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r5):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_sub_5_2(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r5):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_sub_5_3(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r5):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_sub_5_4(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r5):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_sub_5_5(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r5):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_sub_5_6(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r5):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_sub_5_7(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r5):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_sub_6_0(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r6):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_sub_6_1(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r6):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_sub_6_2(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r6):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_sub_6_3(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r6):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_sub_6_4(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r6):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_sub_6_5(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r6):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_sub_6_6(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r6):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_sub_6_7(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r6):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_sub_7_0(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r7):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_sub_7_1(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r7):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_sub_7_2(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r7):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_sub_7_3(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r7):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_sub_7_4(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r7):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_sub_7_5(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r7):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_sub_7_6(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r7):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_sub_7_7(ABC_JIT_ARGS) { __asm__("subl %k1,%k0":"+r"(r7):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_mul_0_0(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r0):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_mul_0_1(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r0):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_mul_0_2(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r0):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_mul_0_3(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r0):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_mul_0_4(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r0):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_mul_0_5(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r0):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_mul_0_6(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r0):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_mul_0_7(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r0):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_mul_1_0(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r1):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_mul_1_1(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r1):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_mul_1_2(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r1):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_mul_1_3(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r1):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_mul_1_4(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r1):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_mul_1_5(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r1):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_mul_1_6(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r1):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_mul_1_7(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r1):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_mul_2_0(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r2):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_mul_2_1(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r2):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_mul_2_2(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r2):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_mul_2_3(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r2):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_mul_2_4(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r2):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_mul_2_5(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r2):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_mul_2_6(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r2):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_mul_2_7(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r2):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_mul_3_0(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r3):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_mul_3_1(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r3):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_mul_3_2(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r3):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_mul_3_3(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r3):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_mul_3_4(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r3):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_mul_3_5(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r3):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_mul_3_6(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r3):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_mul_3_7(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r3):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_mul_4_0(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r4):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_mul_4_1(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r4):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_mul_4_2(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r4):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_mul_4_3(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r4):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_mul_4_4(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r4):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_mul_4_5(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r4):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_mul_4_6(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r4):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_mul_4_7(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r4):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_mul_5_0(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r5):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_mul_5_1(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r5):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_mul_5_2(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r5):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_mul_5_3(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r5):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_mul_5_4(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r5):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_mul_5_5(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r5):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_mul_5_6(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r5):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_mul_5_7(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r5):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_mul_6_0(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r6):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_mul_6_1(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r6):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_mul_6_2(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r6):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_mul_6_3(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r6):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_mul_6_4(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r6):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_mul_6_5(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r6):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_mul_6_6(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r6):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_mul_6_7(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r6):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_mul_7_0(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r7):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_mul_7_1(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r7):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_mul_7_2(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r7):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_mul_7_3(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r7):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_mul_7_4(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r7):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_mul_7_5(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r7):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_mul_7_6(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r7):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_mul_7_7(ABC_JIT_ARGS) { __asm__("imull %k1,%k0":"+r"(r7):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_and_0_0(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r0):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_and_0_1(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r0):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_and_0_2(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r0):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_and_0_3(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r0):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_and_0_4(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r0):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_and_0_5(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r0):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_and_0_6(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r0):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_and_0_7(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r0):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_and_1_0(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r1):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_and_1_1(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r1):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_and_1_2(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r1):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_and_1_3(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r1):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_and_1_4(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r1):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_and_1_5(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r1):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_and_1_6(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r1):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_and_1_7(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r1):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_and_2_0(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r2):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_and_2_1(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r2):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_and_2_2(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r2):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_and_2_3(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r2):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_and_2_4(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r2):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_and_2_5(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r2):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_and_2_6(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r2):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_and_2_7(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r2):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_and_3_0(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r3):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_and_3_1(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r3):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_and_3_2(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r3):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_and_3_3(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r3):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_and_3_4(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r3):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_and_3_5(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r3):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_and_3_6(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r3):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_and_3_7(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r3):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_and_4_0(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r4):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_and_4_1(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r4):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_and_4_2(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r4):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_and_4_3(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r4):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_and_4_4(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r4):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_and_4_5(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r4):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_and_4_6(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r4):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_and_4_7(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r4):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_and_5_0(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r5):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_and_5_1(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r5):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_and_5_2(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r5):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_and_5_3(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r5):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_and_5_4(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r5):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_and_5_5(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r5):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_and_5_6(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r5):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_and_5_7(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r5):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_and_6_0(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r6):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_and_6_1(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r6):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_and_6_2(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r6):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_and_6_3(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r6):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_and_6_4(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r6):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_and_6_5(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r6):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_and_6_6(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r6):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_and_6_7(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r6):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_and_7_0(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r7):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_and_7_1(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r7):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_and_7_2(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r7):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_and_7_3(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r7):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_and_7_4(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r7):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_and_7_5(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r7):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_and_7_6(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r7):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_and_7_7(ABC_JIT_ARGS) { __asm__("andl %k1,%k0":"+r"(r7):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_or_0_0(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r0):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_or_0_1(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r0):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_or_0_2(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r0):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_or_0_3(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r0):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_or_0_4(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r0):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_or_0_5(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r0):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_or_0_6(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r0):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_or_0_7(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r0):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_or_1_0(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r1):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_or_1_1(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r1):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_or_1_2(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r1):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_or_1_3(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r1):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_or_1_4(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r1):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_or_1_5(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r1):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_or_1_6(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r1):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_or_1_7(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r1):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_or_2_0(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r2):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_or_2_1(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r2):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_or_2_2(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r2):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_or_2_3(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r2):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_or_2_4(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r2):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_or_2_5(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r2):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_or_2_6(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r2):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_or_2_7(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r2):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_or_3_0(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r3):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_or_3_1(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r3):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_or_3_2(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r3):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_or_3_3(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r3):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_or_3_4(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r3):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_or_3_5(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r3):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_or_3_6(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r3):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_or_3_7(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r3):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_or_4_0(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r4):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_or_4_1(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r4):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_or_4_2(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r4):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_or_4_3(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r4):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_or_4_4(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r4):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_or_4_5(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r4):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_or_4_6(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r4):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_or_4_7(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r4):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_or_5_0(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r5):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_or_5_1(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r5):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_or_5_2(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r5):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_or_5_3(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r5):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_or_5_4(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r5):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_or_5_5(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r5):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_or_5_6(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r5):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_or_5_7(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r5):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_or_6_0(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r6):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_or_6_1(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r6):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_or_6_2(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r6):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_or_6_3(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r6):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_or_6_4(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r6):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_or_6_5(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r6):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_or_6_6(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r6):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_or_6_7(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r6):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_or_7_0(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r7):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_or_7_1(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r7):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_or_7_2(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r7):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_or_7_3(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r7):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_or_7_4(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r7):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_or_7_5(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r7):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_or_7_6(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r7):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_or_7_7(ABC_JIT_ARGS) { __asm__("orl %k1,%k0":"+r"(r7):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_xor_0_0(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r0):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_xor_0_1(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r0):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_xor_0_2(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r0):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_xor_0_3(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r0):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_xor_0_4(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r0):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_xor_0_5(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r0):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_xor_0_6(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r0):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_xor_0_7(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r0):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_xor_1_0(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r1):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_xor_1_1(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r1):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_xor_1_2(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r1):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_xor_1_3(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r1):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_xor_1_4(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r1):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_xor_1_5(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r1):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_xor_1_6(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r1):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_xor_1_7(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r1):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_xor_2_0(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r2):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_xor_2_1(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r2):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_xor_2_2(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r2):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_xor_2_3(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r2):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_xor_2_4(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r2):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_xor_2_5(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r2):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_xor_2_6(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r2):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_xor_2_7(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r2):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_xor_3_0(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r3):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_xor_3_1(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r3):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_xor_3_2(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r3):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_xor_3_3(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r3):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_xor_3_4(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r3):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_xor_3_5(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r3):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_xor_3_6(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r3):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_xor_3_7(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r3):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_xor_4_0(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r4):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_xor_4_1(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r4):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_xor_4_2(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r4):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_xor_4_3(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r4):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_xor_4_4(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r4):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_xor_4_5(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r4):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_xor_4_6(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r4):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_xor_4_7(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r4):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_xor_5_0(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r5):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_xor_5_1(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r5):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_xor_5_2(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r5):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_xor_5_3(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r5):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_xor_5_4(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r5):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_xor_5_5(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r5):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_xor_5_6(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r5):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_xor_5_7(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r5):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_xor_6_0(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r6):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_xor_6_1(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r6):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_xor_6_2(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r6):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_xor_6_3(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r6):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_xor_6_4(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r6):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_xor_6_5(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r6):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_xor_6_6(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r6):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_xor_6_7(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r6):"r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_xor_7_0(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r7):"r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_xor_7_1(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r7):"r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_xor_7_2(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r7):"r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_xor_7_3(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r7):"r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_xor_7_4(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r7):"r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_xor_7_5(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r7):"r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_xor_7_6(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r7):"r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_xor_7_7(ABC_JIT_ARGS) { __asm__("xorl %k1,%k0":"+r"(r7):"r"(r7)); NEXT }
ABC_JIT_CC abc_value neg_0(ABC_JIT_ARGS) { r0=0-r0; NEXT }
ABC_JIT_CC abc_value neg_1(ABC_JIT_ARGS) { r1=0-r1; NEXT }
ABC_JIT_CC abc_value neg_2(ABC_JIT_ARGS) { r2=0-r2; NEXT }
ABC_JIT_CC abc_value neg_3(ABC_JIT_ARGS) { r3=0-r3; NEXT }
ABC_JIT_CC abc_value neg_4(ABC_JIT_ARGS) { r4=0-r4; NEXT }
ABC_JIT_CC abc_value neg_5(ABC_JIT_ARGS) { r5=0-r5; NEXT }
ABC_JIT_CC abc_value neg_6(ABC_JIT_ARGS) { r6=0-r6; NEXT }
ABC_JIT_CC abc_value neg_7(ABC_JIT_ARGS) { r7=0-r7; NEXT }
ABC_JIT_CC abc_value not_0(ABC_JIT_ARGS) { r0=~r0; NEXT }
ABC_JIT_CC abc_value not_1(ABC_JIT_ARGS) { r1=~r1; NEXT }
ABC_JIT_CC abc_value not_2(ABC_JIT_ARGS) { r2=~r2; NEXT }
ABC_JIT_CC abc_value not_3(ABC_JIT_ARGS) { r3=~r3; NEXT }
ABC_JIT_CC abc_value not_4(ABC_JIT_ARGS) { r4=~r4; NEXT }
ABC_JIT_CC abc_value not_5(ABC_JIT_ARGS) { r5=~r5; NEXT }
ABC_JIT_CC abc_value not_6(ABC_JIT_ARGS) { r6=~r6; NEXT }
ABC_JIT_CC abc_value not_7(ABC_JIT_ARGS) { r7=~r7; NEXT }
ABC_JIT_CC abc_value lnot_0(ABC_JIT_ARGS) { r0=r0^1; NEXT }
ABC_JIT_CC abc_value lnot_1(ABC_JIT_ARGS) { r1=r1^1; NEXT }
ABC_JIT_CC abc_value lnot_2(ABC_JIT_ARGS) { r2=r2^1; NEXT }
ABC_JIT_CC abc_value lnot_3(ABC_JIT_ARGS) { r3=r3^1; NEXT }
ABC_JIT_CC abc_value lnot_4(ABC_JIT_ARGS) { r4=r4^1; NEXT }
ABC_JIT_CC abc_value lnot_5(ABC_JIT_ARGS) { r5=r5^1; NEXT }
ABC_JIT_CC abc_value lnot_6(ABC_JIT_ARGS) { r6=r6^1; NEXT }
ABC_JIT_CC abc_value lnot_7(ABC_JIT_ARGS) { r7=r7^1; NEXT }
ABC_JIT_CC abc_value zx32_0(ABC_JIT_ARGS) { r0=r0&UINT32_MAX; NEXT }
ABC_JIT_CC abc_value zx32_1(ABC_JIT_ARGS) { r1=r1&UINT32_MAX; NEXT }
ABC_JIT_CC abc_value zx32_2(ABC_JIT_ARGS) { r2=r2&UINT32_MAX; NEXT }
ABC_JIT_CC abc_value zx32_3(ABC_JIT_ARGS) { r3=r3&UINT32_MAX; NEXT }
ABC_JIT_CC abc_value zx32_4(ABC_JIT_ARGS) { r4=r4&UINT32_MAX; NEXT }
ABC_JIT_CC abc_value zx32_5(ABC_JIT_ARGS) { r5=r5&UINT32_MAX; NEXT }
ABC_JIT_CC abc_value zx32_6(ABC_JIT_ARGS) { r6=r6&UINT32_MAX; NEXT }
ABC_JIT_CC abc_value zx32_7(ABC_JIT_ARGS) { r7=r7&UINT32_MAX; NEXT }
ABC_JIT_CC abc_value sx32_0(ABC_JIT_ARGS) { r0=(uint64_t)(int64_t)abc_i32_from_u64(r0); NEXT }
ABC_JIT_CC abc_value sx32_1(ABC_JIT_ARGS) { r1=(uint64_t)(int64_t)abc_i32_from_u64(r1); NEXT }
ABC_JIT_CC abc_value sx32_2(ABC_JIT_ARGS) { r2=(uint64_t)(int64_t)abc_i32_from_u64(r2); NEXT }
ABC_JIT_CC abc_value sx32_3(ABC_JIT_ARGS) { r3=(uint64_t)(int64_t)abc_i32_from_u64(r3); NEXT }
ABC_JIT_CC abc_value sx32_4(ABC_JIT_ARGS) { r4=(uint64_t)(int64_t)abc_i32_from_u64(r4); NEXT }
ABC_JIT_CC abc_value sx32_5(ABC_JIT_ARGS) { r5=(uint64_t)(int64_t)abc_i32_from_u64(r5); NEXT }
ABC_JIT_CC abc_value sx32_6(ABC_JIT_ARGS) { r6=(uint64_t)(int64_t)abc_i32_from_u64(r6); NEXT }
ABC_JIT_CC abc_value sx32_7(ABC_JIT_ARGS) { r7=(uint64_t)(int64_t)abc_i32_from_u64(r7); NEXT }
ABC_JIT_CC abc_value zx8_0(ABC_JIT_ARGS) { r0=r0&255; NEXT }
ABC_JIT_CC abc_value zx8_1(ABC_JIT_ARGS) { r1=r1&255; NEXT }
ABC_JIT_CC abc_value zx8_2(ABC_JIT_ARGS) { r2=r2&255; NEXT }
ABC_JIT_CC abc_value zx8_3(ABC_JIT_ARGS) { r3=r3&255; NEXT }
ABC_JIT_CC abc_value zx8_4(ABC_JIT_ARGS) { r4=r4&255; NEXT }
ABC_JIT_CC abc_value zx8_5(ABC_JIT_ARGS) { r5=r5&255; NEXT }
ABC_JIT_CC abc_value zx8_6(ABC_JIT_ARGS) { r6=r6&255; NEXT }
ABC_JIT_CC abc_value zx8_7(ABC_JIT_ARGS) { r7=r7&255; NEXT }
ABC_JIT_CC abc_value zx16_0(ABC_JIT_ARGS) { r0=r0&65535; NEXT }
ABC_JIT_CC abc_value zx16_1(ABC_JIT_ARGS) { r1=r1&65535; NEXT }
ABC_JIT_CC abc_value zx16_2(ABC_JIT_ARGS) { r2=r2&65535; NEXT }
ABC_JIT_CC abc_value zx16_3(ABC_JIT_ARGS) { r3=r3&65535; NEXT }
ABC_JIT_CC abc_value zx16_4(ABC_JIT_ARGS) { r4=r4&65535; NEXT }
ABC_JIT_CC abc_value zx16_5(ABC_JIT_ARGS) { r5=r5&65535; NEXT }
ABC_JIT_CC abc_value zx16_6(ABC_JIT_ARGS) { r6=r6&65535; NEXT }
ABC_JIT_CC abc_value zx16_7(ABC_JIT_ARGS) { r7=r7&65535; NEXT }
ABC_JIT_CC abc_value addi_0(ABC_JIT_ARGS) { __asm__("addq $HOLE_IMM,%0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value addi_1(ABC_JIT_ARGS) { __asm__("addq $HOLE_IMM,%0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value addi_2(ABC_JIT_ARGS) { __asm__("addq $HOLE_IMM,%0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value addi_3(ABC_JIT_ARGS) { __asm__("addq $HOLE_IMM,%0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value addi_4(ABC_JIT_ARGS) { __asm__("addq $HOLE_IMM,%0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value addi_5(ABC_JIT_ARGS) { __asm__("addq $HOLE_IMM,%0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value addi_6(ABC_JIT_ARGS) { __asm__("addq $HOLE_IMM,%0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value addi_7(ABC_JIT_ARGS) { __asm__("addq $HOLE_IMM,%0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value subi_0(ABC_JIT_ARGS) { __asm__("subq $HOLE_IMM,%0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value subi_1(ABC_JIT_ARGS) { __asm__("subq $HOLE_IMM,%0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value subi_2(ABC_JIT_ARGS) { __asm__("subq $HOLE_IMM,%0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value subi_3(ABC_JIT_ARGS) { __asm__("subq $HOLE_IMM,%0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value subi_4(ABC_JIT_ARGS) { __asm__("subq $HOLE_IMM,%0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value subi_5(ABC_JIT_ARGS) { __asm__("subq $HOLE_IMM,%0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value subi_6(ABC_JIT_ARGS) { __asm__("subq $HOLE_IMM,%0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value subi_7(ABC_JIT_ARGS) { __asm__("subq $HOLE_IMM,%0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value muli_0(ABC_JIT_ARGS) { __asm__("imulq $HOLE_IMM,%0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value muli_1(ABC_JIT_ARGS) { __asm__("imulq $HOLE_IMM,%0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value muli_2(ABC_JIT_ARGS) { __asm__("imulq $HOLE_IMM,%0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value muli_3(ABC_JIT_ARGS) { __asm__("imulq $HOLE_IMM,%0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value muli_4(ABC_JIT_ARGS) { __asm__("imulq $HOLE_IMM,%0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value muli_5(ABC_JIT_ARGS) { __asm__("imulq $HOLE_IMM,%0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value muli_6(ABC_JIT_ARGS) { __asm__("imulq $HOLE_IMM,%0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value muli_7(ABC_JIT_ARGS) { __asm__("imulq $HOLE_IMM,%0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value andi_0(ABC_JIT_ARGS) { __asm__("andq $HOLE_IMM,%0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value andi_1(ABC_JIT_ARGS) { __asm__("andq $HOLE_IMM,%0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value andi_2(ABC_JIT_ARGS) { __asm__("andq $HOLE_IMM,%0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value andi_3(ABC_JIT_ARGS) { __asm__("andq $HOLE_IMM,%0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value andi_4(ABC_JIT_ARGS) { __asm__("andq $HOLE_IMM,%0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value andi_5(ABC_JIT_ARGS) { __asm__("andq $HOLE_IMM,%0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value andi_6(ABC_JIT_ARGS) { __asm__("andq $HOLE_IMM,%0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value andi_7(ABC_JIT_ARGS) { __asm__("andq $HOLE_IMM,%0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value ori_0(ABC_JIT_ARGS) { __asm__("orq $HOLE_IMM,%0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value ori_1(ABC_JIT_ARGS) { __asm__("orq $HOLE_IMM,%0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value ori_2(ABC_JIT_ARGS) { __asm__("orq $HOLE_IMM,%0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value ori_3(ABC_JIT_ARGS) { __asm__("orq $HOLE_IMM,%0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value ori_4(ABC_JIT_ARGS) { __asm__("orq $HOLE_IMM,%0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value ori_5(ABC_JIT_ARGS) { __asm__("orq $HOLE_IMM,%0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value ori_6(ABC_JIT_ARGS) { __asm__("orq $HOLE_IMM,%0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value ori_7(ABC_JIT_ARGS) { __asm__("orq $HOLE_IMM,%0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value xori_0(ABC_JIT_ARGS) { __asm__("xorq $HOLE_IMM,%0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value xori_1(ABC_JIT_ARGS) { __asm__("xorq $HOLE_IMM,%0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value xori_2(ABC_JIT_ARGS) { __asm__("xorq $HOLE_IMM,%0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value xori_3(ABC_JIT_ARGS) { __asm__("xorq $HOLE_IMM,%0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value xori_4(ABC_JIT_ARGS) { __asm__("xorq $HOLE_IMM,%0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value xori_5(ABC_JIT_ARGS) { __asm__("xorq $HOLE_IMM,%0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value xori_6(ABC_JIT_ARGS) { __asm__("xorq $HOLE_IMM,%0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value xori_7(ABC_JIT_ARGS) { __asm__("xorq $HOLE_IMM,%0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value shli_0(ABC_JIT_ARGS) { __asm__("shlq $HOLE_IMM,%0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value shli_1(ABC_JIT_ARGS) { __asm__("shlq $HOLE_IMM,%0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value shli_2(ABC_JIT_ARGS) { __asm__("shlq $HOLE_IMM,%0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value shli_3(ABC_JIT_ARGS) { __asm__("shlq $HOLE_IMM,%0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value shli_4(ABC_JIT_ARGS) { __asm__("shlq $HOLE_IMM,%0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value shli_5(ABC_JIT_ARGS) { __asm__("shlq $HOLE_IMM,%0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value shli_6(ABC_JIT_ARGS) { __asm__("shlq $HOLE_IMM,%0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value shli_7(ABC_JIT_ARGS) { __asm__("shlq $HOLE_IMM,%0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value shri_0(ABC_JIT_ARGS) { __asm__("shrq $HOLE_IMM,%0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value shri_1(ABC_JIT_ARGS) { __asm__("shrq $HOLE_IMM,%0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value shri_2(ABC_JIT_ARGS) { __asm__("shrq $HOLE_IMM,%0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value shri_3(ABC_JIT_ARGS) { __asm__("shrq $HOLE_IMM,%0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value shri_4(ABC_JIT_ARGS) { __asm__("shrq $HOLE_IMM,%0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value shri_5(ABC_JIT_ARGS) { __asm__("shrq $HOLE_IMM,%0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value shri_6(ABC_JIT_ARGS) { __asm__("shrq $HOLE_IMM,%0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value shri_7(ABC_JIT_ARGS) { __asm__("shrq $HOLE_IMM,%0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value sari_0(ABC_JIT_ARGS) { __asm__("sarq $HOLE_IMM,%0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value sari_1(ABC_JIT_ARGS) { __asm__("sarq $HOLE_IMM,%0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value sari_2(ABC_JIT_ARGS) { __asm__("sarq $HOLE_IMM,%0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value sari_3(ABC_JIT_ARGS) { __asm__("sarq $HOLE_IMM,%0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value sari_4(ABC_JIT_ARGS) { __asm__("sarq $HOLE_IMM,%0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value sari_5(ABC_JIT_ARGS) { __asm__("sarq $HOLE_IMM,%0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value sari_6(ABC_JIT_ARGS) { __asm__("sarq $HOLE_IMM,%0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value sari_7(ABC_JIT_ARGS) { __asm__("sarq $HOLE_IMM,%0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_addi_0(ABC_JIT_ARGS) { __asm__("addl $HOLE_IMM,%k0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_addi_1(ABC_JIT_ARGS) { __asm__("addl $HOLE_IMM,%k0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_addi_2(ABC_JIT_ARGS) { __asm__("addl $HOLE_IMM,%k0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_addi_3(ABC_JIT_ARGS) { __asm__("addl $HOLE_IMM,%k0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_addi_4(ABC_JIT_ARGS) { __asm__("addl $HOLE_IMM,%k0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_addi_5(ABC_JIT_ARGS) { __asm__("addl $HOLE_IMM,%k0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_addi_6(ABC_JIT_ARGS) { __asm__("addl $HOLE_IMM,%k0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_addi_7(ABC_JIT_ARGS) { __asm__("addl $HOLE_IMM,%k0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_subi_0(ABC_JIT_ARGS) { __asm__("subl $HOLE_IMM,%k0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_subi_1(ABC_JIT_ARGS) { __asm__("subl $HOLE_IMM,%k0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_subi_2(ABC_JIT_ARGS) { __asm__("subl $HOLE_IMM,%k0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_subi_3(ABC_JIT_ARGS) { __asm__("subl $HOLE_IMM,%k0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_subi_4(ABC_JIT_ARGS) { __asm__("subl $HOLE_IMM,%k0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_subi_5(ABC_JIT_ARGS) { __asm__("subl $HOLE_IMM,%k0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_subi_6(ABC_JIT_ARGS) { __asm__("subl $HOLE_IMM,%k0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_subi_7(ABC_JIT_ARGS) { __asm__("subl $HOLE_IMM,%k0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_muli_0(ABC_JIT_ARGS) { __asm__("imull $HOLE_IMM,%k0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_muli_1(ABC_JIT_ARGS) { __asm__("imull $HOLE_IMM,%k0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_muli_2(ABC_JIT_ARGS) { __asm__("imull $HOLE_IMM,%k0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_muli_3(ABC_JIT_ARGS) { __asm__("imull $HOLE_IMM,%k0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_muli_4(ABC_JIT_ARGS) { __asm__("imull $HOLE_IMM,%k0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_muli_5(ABC_JIT_ARGS) { __asm__("imull $HOLE_IMM,%k0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_muli_6(ABC_JIT_ARGS) { __asm__("imull $HOLE_IMM,%k0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_muli_7(ABC_JIT_ARGS) { __asm__("imull $HOLE_IMM,%k0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_andi_0(ABC_JIT_ARGS) { __asm__("andl $HOLE_IMM,%k0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_andi_1(ABC_JIT_ARGS) { __asm__("andl $HOLE_IMM,%k0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_andi_2(ABC_JIT_ARGS) { __asm__("andl $HOLE_IMM,%k0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_andi_3(ABC_JIT_ARGS) { __asm__("andl $HOLE_IMM,%k0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_andi_4(ABC_JIT_ARGS) { __asm__("andl $HOLE_IMM,%k0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_andi_5(ABC_JIT_ARGS) { __asm__("andl $HOLE_IMM,%k0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_andi_6(ABC_JIT_ARGS) { __asm__("andl $HOLE_IMM,%k0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_andi_7(ABC_JIT_ARGS) { __asm__("andl $HOLE_IMM,%k0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_ori_0(ABC_JIT_ARGS) { __asm__("orl $HOLE_IMM,%k0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_ori_1(ABC_JIT_ARGS) { __asm__("orl $HOLE_IMM,%k0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_ori_2(ABC_JIT_ARGS) { __asm__("orl $HOLE_IMM,%k0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_ori_3(ABC_JIT_ARGS) { __asm__("orl $HOLE_IMM,%k0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_ori_4(ABC_JIT_ARGS) { __asm__("orl $HOLE_IMM,%k0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_ori_5(ABC_JIT_ARGS) { __asm__("orl $HOLE_IMM,%k0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_ori_6(ABC_JIT_ARGS) { __asm__("orl $HOLE_IMM,%k0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_ori_7(ABC_JIT_ARGS) { __asm__("orl $HOLE_IMM,%k0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_xori_0(ABC_JIT_ARGS) { __asm__("xorl $HOLE_IMM,%k0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_xori_1(ABC_JIT_ARGS) { __asm__("xorl $HOLE_IMM,%k0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_xori_2(ABC_JIT_ARGS) { __asm__("xorl $HOLE_IMM,%k0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_xori_3(ABC_JIT_ARGS) { __asm__("xorl $HOLE_IMM,%k0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_xori_4(ABC_JIT_ARGS) { __asm__("xorl $HOLE_IMM,%k0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_xori_5(ABC_JIT_ARGS) { __asm__("xorl $HOLE_IMM,%k0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_xori_6(ABC_JIT_ARGS) { __asm__("xorl $HOLE_IMM,%k0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_xori_7(ABC_JIT_ARGS) { __asm__("xorl $HOLE_IMM,%k0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_shli_0(ABC_JIT_ARGS) { __asm__("shll $HOLE_IMM,%k0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_shli_1(ABC_JIT_ARGS) { __asm__("shll $HOLE_IMM,%k0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_shli_2(ABC_JIT_ARGS) { __asm__("shll $HOLE_IMM,%k0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_shli_3(ABC_JIT_ARGS) { __asm__("shll $HOLE_IMM,%k0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_shli_4(ABC_JIT_ARGS) { __asm__("shll $HOLE_IMM,%k0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_shli_5(ABC_JIT_ARGS) { __asm__("shll $HOLE_IMM,%k0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_shli_6(ABC_JIT_ARGS) { __asm__("shll $HOLE_IMM,%k0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_shli_7(ABC_JIT_ARGS) { __asm__("shll $HOLE_IMM,%k0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_shri_0(ABC_JIT_ARGS) { __asm__("shrl $HOLE_IMM,%k0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_shri_1(ABC_JIT_ARGS) { __asm__("shrl $HOLE_IMM,%k0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_shri_2(ABC_JIT_ARGS) { __asm__("shrl $HOLE_IMM,%k0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_shri_3(ABC_JIT_ARGS) { __asm__("shrl $HOLE_IMM,%k0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_shri_4(ABC_JIT_ARGS) { __asm__("shrl $HOLE_IMM,%k0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_shri_5(ABC_JIT_ARGS) { __asm__("shrl $HOLE_IMM,%k0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_shri_6(ABC_JIT_ARGS) { __asm__("shrl $HOLE_IMM,%k0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_shri_7(ABC_JIT_ARGS) { __asm__("shrl $HOLE_IMM,%k0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value u32_sari_0(ABC_JIT_ARGS) { __asm__("sarl $HOLE_IMM,%k0":"+r"(r0)); NEXT }
ABC_JIT_CC abc_value u32_sari_1(ABC_JIT_ARGS) { __asm__("sarl $HOLE_IMM,%k0":"+r"(r1)); NEXT }
ABC_JIT_CC abc_value u32_sari_2(ABC_JIT_ARGS) { __asm__("sarl $HOLE_IMM,%k0":"+r"(r2)); NEXT }
ABC_JIT_CC abc_value u32_sari_3(ABC_JIT_ARGS) { __asm__("sarl $HOLE_IMM,%k0":"+r"(r3)); NEXT }
ABC_JIT_CC abc_value u32_sari_4(ABC_JIT_ARGS) { __asm__("sarl $HOLE_IMM,%k0":"+r"(r4)); NEXT }
ABC_JIT_CC abc_value u32_sari_5(ABC_JIT_ARGS) { __asm__("sarl $HOLE_IMM,%k0":"+r"(r5)); NEXT }
ABC_JIT_CC abc_value u32_sari_6(ABC_JIT_ARGS) { __asm__("sarl $HOLE_IMM,%k0":"+r"(r6)); NEXT }
ABC_JIT_CC abc_value u32_sari_7(ABC_JIT_ARGS) { __asm__("sarl $HOLE_IMM,%k0":"+r"(r7)); NEXT }
ABC_JIT_CC abc_value jz_0(ABC_JIT_ARGS) { __asm__("testq %0,%0; jz HOLE_TAKEN"::"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value jnz_0(ABC_JIT_ARGS) { __asm__("testq %0,%0; jnz HOLE_TAKEN"::"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value load_a_0(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r0):"r"(asp)); NEXT }
ABC_JIT_CC abc_value store_a_0(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(asp),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value load_b_0(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r0):"r"(bsp)); NEXT }
ABC_JIT_CC abc_value store_b_0(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(bsp),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value load_c_0(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r0):"r"(csp)); NEXT }
ABC_JIT_CC abc_value store_c_0(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value jz_1(ABC_JIT_ARGS) { __asm__("testq %0,%0; jz HOLE_TAKEN"::"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value jnz_1(ABC_JIT_ARGS) { __asm__("testq %0,%0; jnz HOLE_TAKEN"::"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value load_a_1(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r1):"r"(asp)); NEXT }
ABC_JIT_CC abc_value store_a_1(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(asp),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value load_b_1(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r1):"r"(bsp)); NEXT }
ABC_JIT_CC abc_value store_b_1(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(bsp),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value load_c_1(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r1):"r"(csp)); NEXT }
ABC_JIT_CC abc_value store_c_1(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value jz_2(ABC_JIT_ARGS) { __asm__("testq %0,%0; jz HOLE_TAKEN"::"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value jnz_2(ABC_JIT_ARGS) { __asm__("testq %0,%0; jnz HOLE_TAKEN"::"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value load_a_2(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r2):"r"(asp)); NEXT }
ABC_JIT_CC abc_value store_a_2(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(asp),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value load_b_2(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r2):"r"(bsp)); NEXT }
ABC_JIT_CC abc_value store_b_2(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(bsp),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value load_c_2(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r2):"r"(csp)); NEXT }
ABC_JIT_CC abc_value store_c_2(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value jz_3(ABC_JIT_ARGS) { __asm__("testq %0,%0; jz HOLE_TAKEN"::"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value jnz_3(ABC_JIT_ARGS) { __asm__("testq %0,%0; jnz HOLE_TAKEN"::"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value load_a_3(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r3):"r"(asp)); NEXT }
ABC_JIT_CC abc_value store_a_3(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(asp),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value load_b_3(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r3):"r"(bsp)); NEXT }
ABC_JIT_CC abc_value store_b_3(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(bsp),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value load_c_3(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r3):"r"(csp)); NEXT }
ABC_JIT_CC abc_value store_c_3(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value jz_4(ABC_JIT_ARGS) { __asm__("testq %0,%0; jz HOLE_TAKEN"::"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value jnz_4(ABC_JIT_ARGS) { __asm__("testq %0,%0; jnz HOLE_TAKEN"::"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value load_a_4(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r4):"r"(asp)); NEXT }
ABC_JIT_CC abc_value store_a_4(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(asp),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value load_b_4(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r4):"r"(bsp)); NEXT }
ABC_JIT_CC abc_value store_b_4(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(bsp),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value load_c_4(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r4):"r"(csp)); NEXT }
ABC_JIT_CC abc_value store_c_4(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value jz_5(ABC_JIT_ARGS) { __asm__("testq %0,%0; jz HOLE_TAKEN"::"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value jnz_5(ABC_JIT_ARGS) { __asm__("testq %0,%0; jnz HOLE_TAKEN"::"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value load_a_5(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r5):"r"(asp)); NEXT }
ABC_JIT_CC abc_value store_a_5(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(asp),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value load_b_5(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r5):"r"(bsp)); NEXT }
ABC_JIT_CC abc_value store_b_5(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(bsp),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value load_c_5(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r5):"r"(csp)); NEXT }
ABC_JIT_CC abc_value store_c_5(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value jz_6(ABC_JIT_ARGS) { __asm__("testq %0,%0; jz HOLE_TAKEN"::"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value jnz_6(ABC_JIT_ARGS) { __asm__("testq %0,%0; jnz HOLE_TAKEN"::"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value load_a_6(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r6):"r"(asp)); NEXT }
ABC_JIT_CC abc_value store_a_6(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(asp),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value load_b_6(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r6):"r"(bsp)); NEXT }
ABC_JIT_CC abc_value store_b_6(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(bsp),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value load_c_6(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r6):"r"(csp)); NEXT }
ABC_JIT_CC abc_value store_c_6(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value jz_7(ABC_JIT_ARGS) { __asm__("testq %0,%0; jz HOLE_TAKEN"::"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value jnz_7(ABC_JIT_ARGS) { __asm__("testq %0,%0; jnz HOLE_TAKEN"::"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value load_a_7(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r7):"r"(asp)); NEXT }
ABC_JIT_CC abc_value store_a_7(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(asp),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value load_b_7(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r7):"r"(bsp)); NEXT }
ABC_JIT_CC abc_value store_b_7(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(bsp),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value load_c_7(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r7):"r"(csp)); NEXT }
ABC_JIT_CC abc_value store_c_7(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value beq_0_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r0),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_0_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r0),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_0_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r0),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_0_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r0),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_0_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r0),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_0_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r0),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_0_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r0),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_0_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r0),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_1_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r1),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_1_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r1),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_1_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r1),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_1_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r1),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_1_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r1),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_1_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r1),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_1_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r1),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_1_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r1),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_2_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r2),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_2_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r2),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_2_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r2),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_2_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r2),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_2_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r2),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_2_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r2),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_2_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r2),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_2_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r2),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_3_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r3),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_3_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r3),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_3_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r3),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_3_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r3),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_3_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r3),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_3_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r3),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_3_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r3),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_3_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r3),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_4_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r4),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_4_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r4),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_4_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r4),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_4_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r4),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_4_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r4),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_4_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r4),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_4_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r4),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_4_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r4),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_5_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r5),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_5_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r5),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_5_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r5),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_5_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r5),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_5_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r5),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_5_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r5),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_5_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r5),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_5_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r5),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_6_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r6),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_6_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r6),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_6_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r6),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_6_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r6),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_6_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r6),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_6_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r6),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_6_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r6),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_6_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r6),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_7_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r7),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_7_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r7),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_7_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r7),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_7_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r7),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_7_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r7),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_7_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r7),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_7_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r7),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value beq_7_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; je HOLE_TAKEN"::"r"(r7),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_0_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r0),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_0_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r0),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_0_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r0),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_0_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r0),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_0_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r0),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_0_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r0),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_0_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r0),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_0_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r0),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_1_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r1),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_1_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r1),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_1_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r1),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_1_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r1),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_1_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r1),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_1_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r1),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_1_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r1),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_1_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r1),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_2_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r2),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_2_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r2),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_2_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r2),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_2_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r2),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_2_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r2),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_2_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r2),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_2_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r2),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_2_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r2),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_3_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r3),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_3_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r3),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_3_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r3),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_3_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r3),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_3_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r3),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_3_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r3),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_3_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r3),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_3_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r3),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_4_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r4),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_4_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r4),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_4_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r4),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_4_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r4),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_4_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r4),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_4_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r4),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_4_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r4),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_4_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r4),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_5_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r5),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_5_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r5),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_5_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r5),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_5_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r5),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_5_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r5),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_5_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r5),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_5_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r5),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_5_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r5),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_6_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r6),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_6_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r6),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_6_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r6),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_6_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r6),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_6_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r6),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_6_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r6),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_6_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r6),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_6_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r6),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_7_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r7),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_7_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r7),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_7_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r7),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_7_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r7),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_7_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r7),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_7_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r7),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_7_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r7),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bne_7_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jne HOLE_TAKEN"::"r"(r7),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_0_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r0),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_0_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r0),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_0_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r0),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_0_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r0),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_0_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r0),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_0_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r0),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_0_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r0),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_0_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r0),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_1_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r1),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_1_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r1),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_1_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r1),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_1_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r1),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_1_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r1),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_1_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r1),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_1_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r1),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_1_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r1),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_2_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r2),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_2_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r2),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_2_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r2),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_2_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r2),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_2_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r2),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_2_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r2),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_2_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r2),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_2_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r2),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_3_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r3),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_3_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r3),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_3_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r3),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_3_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r3),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_3_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r3),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_3_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r3),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_3_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r3),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_3_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r3),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_4_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r4),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_4_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r4),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_4_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r4),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_4_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r4),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_4_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r4),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_4_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r4),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_4_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r4),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_4_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r4),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_5_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r5),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_5_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r5),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_5_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r5),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_5_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r5),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_5_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r5),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_5_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r5),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_5_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r5),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_5_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r5),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_6_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r6),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_6_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r6),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_6_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r6),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_6_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r6),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_6_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r6),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_6_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r6),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_6_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r6),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_6_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r6),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_7_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r7),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_7_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r7),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_7_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r7),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_7_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r7),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_7_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r7),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_7_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r7),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_7_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r7),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value blt_7_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jl HOLE_TAKEN"::"r"(r7),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_0_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r0),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_0_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r0),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_0_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r0),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_0_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r0),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_0_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r0),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_0_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r0),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_0_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r0),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_0_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r0),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_1_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r1),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_1_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r1),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_1_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r1),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_1_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r1),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_1_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r1),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_1_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r1),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_1_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r1),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_1_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r1),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_2_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r2),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_2_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r2),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_2_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r2),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_2_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r2),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_2_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r2),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_2_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r2),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_2_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r2),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_2_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r2),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_3_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r3),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_3_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r3),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_3_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r3),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_3_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r3),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_3_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r3),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_3_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r3),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_3_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r3),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_3_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r3),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_4_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r4),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_4_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r4),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_4_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r4),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_4_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r4),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_4_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r4),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_4_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r4),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_4_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r4),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_4_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r4),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_5_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r5),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_5_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r5),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_5_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r5),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_5_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r5),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_5_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r5),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_5_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r5),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_5_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r5),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_5_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r5),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_6_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r6),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_6_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r6),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_6_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r6),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_6_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r6),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_6_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r6),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_6_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r6),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_6_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r6),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_6_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r6),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_7_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r7),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_7_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r7),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_7_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r7),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_7_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r7),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_7_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r7),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_7_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r7),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_7_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r7),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value ble_7_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jle HOLE_TAKEN"::"r"(r7),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_0_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r0),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_0_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r0),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_0_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r0),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_0_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r0),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_0_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r0),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_0_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r0),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_0_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r0),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_0_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r0),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_1_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r1),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_1_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r1),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_1_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r1),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_1_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r1),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_1_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r1),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_1_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r1),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_1_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r1),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_1_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r1),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_2_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r2),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_2_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r2),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_2_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r2),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_2_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r2),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_2_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r2),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_2_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r2),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_2_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r2),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_2_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r2),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_3_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r3),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_3_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r3),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_3_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r3),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_3_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r3),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_3_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r3),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_3_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r3),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_3_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r3),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_3_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r3),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_4_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r4),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_4_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r4),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_4_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r4),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_4_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r4),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_4_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r4),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_4_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r4),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_4_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r4),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_4_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r4),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_5_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r5),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_5_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r5),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_5_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r5),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_5_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r5),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_5_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r5),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_5_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r5),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_5_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r5),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_5_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r5),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_6_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r6),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_6_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r6),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_6_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r6),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_6_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r6),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_6_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r6),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_6_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r6),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_6_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r6),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_6_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r6),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_7_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r7),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_7_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r7),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_7_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r7),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_7_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r7),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_7_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r7),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_7_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r7),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_7_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r7),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bltu_7_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jb HOLE_TAKEN"::"r"(r7),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_0_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r0),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_0_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r0),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_0_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r0),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_0_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r0),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_0_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r0),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_0_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r0),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_0_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r0),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_0_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r0),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_1_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r1),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_1_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r1),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_1_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r1),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_1_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r1),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_1_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r1),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_1_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r1),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_1_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r1),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_1_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r1),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_2_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r2),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_2_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r2),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_2_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r2),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_2_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r2),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_2_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r2),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_2_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r2),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_2_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r2),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_2_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r2),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_3_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r3),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_3_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r3),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_3_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r3),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_3_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r3),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_3_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r3),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_3_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r3),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_3_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r3),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_3_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r3),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_4_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r4),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_4_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r4),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_4_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r4),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_4_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r4),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_4_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r4),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_4_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r4),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_4_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r4),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_4_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r4),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_5_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r5),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_5_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r5),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_5_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r5),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_5_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r5),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_5_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r5),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_5_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r5),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_5_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r5),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_5_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r5),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_6_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r6),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_6_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r6),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_6_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r6),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_6_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r6),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_6_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r6),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_6_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r6),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_6_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r6),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_6_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r6),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_7_0(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r7),"r"(r0):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_7_1(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r7),"r"(r1):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_7_2(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r7),"r"(r2):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_7_3(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r7),"r"(r3):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_7_4(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r7),"r"(r4):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_7_5(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r7),"r"(r5):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_7_6(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r7),"r"(r6):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value bleu_7_7(ABC_JIT_ARGS) { __asm__("cmpq %1,%0; jbe HOLE_TAKEN"::"r"(r7),"r"(r7):"cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_fadd_0_0(ABC_JIT_ARGS) { r0=vm_fadd(r0,r0); NEXT }
ABC_JIT_CC abc_value float_fadd_0_1(ABC_JIT_ARGS) { r0=vm_fadd(r0,r1); NEXT }
ABC_JIT_CC abc_value float_fadd_0_2(ABC_JIT_ARGS) { r0=vm_fadd(r0,r2); NEXT }
ABC_JIT_CC abc_value float_fadd_0_3(ABC_JIT_ARGS) { r0=vm_fadd(r0,r3); NEXT }
ABC_JIT_CC abc_value float_fadd_0_4(ABC_JIT_ARGS) { r0=vm_fadd(r0,r4); NEXT }
ABC_JIT_CC abc_value float_fadd_0_5(ABC_JIT_ARGS) { r0=vm_fadd(r0,r5); NEXT }
ABC_JIT_CC abc_value float_fadd_0_6(ABC_JIT_ARGS) { r0=vm_fadd(r0,r6); NEXT }
ABC_JIT_CC abc_value float_fadd_0_7(ABC_JIT_ARGS) { r0=vm_fadd(r0,r7); NEXT }
ABC_JIT_CC abc_value float_fadd_1_0(ABC_JIT_ARGS) { r1=vm_fadd(r1,r0); NEXT }
ABC_JIT_CC abc_value float_fadd_1_1(ABC_JIT_ARGS) { r1=vm_fadd(r1,r1); NEXT }
ABC_JIT_CC abc_value float_fadd_1_2(ABC_JIT_ARGS) { r1=vm_fadd(r1,r2); NEXT }
ABC_JIT_CC abc_value float_fadd_1_3(ABC_JIT_ARGS) { r1=vm_fadd(r1,r3); NEXT }
ABC_JIT_CC abc_value float_fadd_1_4(ABC_JIT_ARGS) { r1=vm_fadd(r1,r4); NEXT }
ABC_JIT_CC abc_value float_fadd_1_5(ABC_JIT_ARGS) { r1=vm_fadd(r1,r5); NEXT }
ABC_JIT_CC abc_value float_fadd_1_6(ABC_JIT_ARGS) { r1=vm_fadd(r1,r6); NEXT }
ABC_JIT_CC abc_value float_fadd_1_7(ABC_JIT_ARGS) { r1=vm_fadd(r1,r7); NEXT }
ABC_JIT_CC abc_value float_fadd_2_0(ABC_JIT_ARGS) { r2=vm_fadd(r2,r0); NEXT }
ABC_JIT_CC abc_value float_fadd_2_1(ABC_JIT_ARGS) { r2=vm_fadd(r2,r1); NEXT }
ABC_JIT_CC abc_value float_fadd_2_2(ABC_JIT_ARGS) { r2=vm_fadd(r2,r2); NEXT }
ABC_JIT_CC abc_value float_fadd_2_3(ABC_JIT_ARGS) { r2=vm_fadd(r2,r3); NEXT }
ABC_JIT_CC abc_value float_fadd_2_4(ABC_JIT_ARGS) { r2=vm_fadd(r2,r4); NEXT }
ABC_JIT_CC abc_value float_fadd_2_5(ABC_JIT_ARGS) { r2=vm_fadd(r2,r5); NEXT }
ABC_JIT_CC abc_value float_fadd_2_6(ABC_JIT_ARGS) { r2=vm_fadd(r2,r6); NEXT }
ABC_JIT_CC abc_value float_fadd_2_7(ABC_JIT_ARGS) { r2=vm_fadd(r2,r7); NEXT }
ABC_JIT_CC abc_value float_fadd_3_0(ABC_JIT_ARGS) { r3=vm_fadd(r3,r0); NEXT }
ABC_JIT_CC abc_value float_fadd_3_1(ABC_JIT_ARGS) { r3=vm_fadd(r3,r1); NEXT }
ABC_JIT_CC abc_value float_fadd_3_2(ABC_JIT_ARGS) { r3=vm_fadd(r3,r2); NEXT }
ABC_JIT_CC abc_value float_fadd_3_3(ABC_JIT_ARGS) { r3=vm_fadd(r3,r3); NEXT }
ABC_JIT_CC abc_value float_fadd_3_4(ABC_JIT_ARGS) { r3=vm_fadd(r3,r4); NEXT }
ABC_JIT_CC abc_value float_fadd_3_5(ABC_JIT_ARGS) { r3=vm_fadd(r3,r5); NEXT }
ABC_JIT_CC abc_value float_fadd_3_6(ABC_JIT_ARGS) { r3=vm_fadd(r3,r6); NEXT }
ABC_JIT_CC abc_value float_fadd_3_7(ABC_JIT_ARGS) { r3=vm_fadd(r3,r7); NEXT }
ABC_JIT_CC abc_value float_fadd_4_0(ABC_JIT_ARGS) { r4=vm_fadd(r4,r0); NEXT }
ABC_JIT_CC abc_value float_fadd_4_1(ABC_JIT_ARGS) { r4=vm_fadd(r4,r1); NEXT }
ABC_JIT_CC abc_value float_fadd_4_2(ABC_JIT_ARGS) { r4=vm_fadd(r4,r2); NEXT }
ABC_JIT_CC abc_value float_fadd_4_3(ABC_JIT_ARGS) { r4=vm_fadd(r4,r3); NEXT }
ABC_JIT_CC abc_value float_fadd_4_4(ABC_JIT_ARGS) { r4=vm_fadd(r4,r4); NEXT }
ABC_JIT_CC abc_value float_fadd_4_5(ABC_JIT_ARGS) { r4=vm_fadd(r4,r5); NEXT }
ABC_JIT_CC abc_value float_fadd_4_6(ABC_JIT_ARGS) { r4=vm_fadd(r4,r6); NEXT }
ABC_JIT_CC abc_value float_fadd_4_7(ABC_JIT_ARGS) { r4=vm_fadd(r4,r7); NEXT }
ABC_JIT_CC abc_value float_fadd_5_0(ABC_JIT_ARGS) { r5=vm_fadd(r5,r0); NEXT }
ABC_JIT_CC abc_value float_fadd_5_1(ABC_JIT_ARGS) { r5=vm_fadd(r5,r1); NEXT }
ABC_JIT_CC abc_value float_fadd_5_2(ABC_JIT_ARGS) { r5=vm_fadd(r5,r2); NEXT }
ABC_JIT_CC abc_value float_fadd_5_3(ABC_JIT_ARGS) { r5=vm_fadd(r5,r3); NEXT }
ABC_JIT_CC abc_value float_fadd_5_4(ABC_JIT_ARGS) { r5=vm_fadd(r5,r4); NEXT }
ABC_JIT_CC abc_value float_fadd_5_5(ABC_JIT_ARGS) { r5=vm_fadd(r5,r5); NEXT }
ABC_JIT_CC abc_value float_fadd_5_6(ABC_JIT_ARGS) { r5=vm_fadd(r5,r6); NEXT }
ABC_JIT_CC abc_value float_fadd_5_7(ABC_JIT_ARGS) { r5=vm_fadd(r5,r7); NEXT }
ABC_JIT_CC abc_value float_fadd_6_0(ABC_JIT_ARGS) { r6=vm_fadd(r6,r0); NEXT }
ABC_JIT_CC abc_value float_fadd_6_1(ABC_JIT_ARGS) { r6=vm_fadd(r6,r1); NEXT }
ABC_JIT_CC abc_value float_fadd_6_2(ABC_JIT_ARGS) { r6=vm_fadd(r6,r2); NEXT }
ABC_JIT_CC abc_value float_fadd_6_3(ABC_JIT_ARGS) { r6=vm_fadd(r6,r3); NEXT }
ABC_JIT_CC abc_value float_fadd_6_4(ABC_JIT_ARGS) { r6=vm_fadd(r6,r4); NEXT }
ABC_JIT_CC abc_value float_fadd_6_5(ABC_JIT_ARGS) { r6=vm_fadd(r6,r5); NEXT }
ABC_JIT_CC abc_value float_fadd_6_6(ABC_JIT_ARGS) { r6=vm_fadd(r6,r6); NEXT }
ABC_JIT_CC abc_value float_fadd_6_7(ABC_JIT_ARGS) { r6=vm_fadd(r6,r7); NEXT }
ABC_JIT_CC abc_value float_fadd_7_0(ABC_JIT_ARGS) { r7=vm_fadd(r7,r0); NEXT }
ABC_JIT_CC abc_value float_fadd_7_1(ABC_JIT_ARGS) { r7=vm_fadd(r7,r1); NEXT }
ABC_JIT_CC abc_value float_fadd_7_2(ABC_JIT_ARGS) { r7=vm_fadd(r7,r2); NEXT }
ABC_JIT_CC abc_value float_fadd_7_3(ABC_JIT_ARGS) { r7=vm_fadd(r7,r3); NEXT }
ABC_JIT_CC abc_value float_fadd_7_4(ABC_JIT_ARGS) { r7=vm_fadd(r7,r4); NEXT }
ABC_JIT_CC abc_value float_fadd_7_5(ABC_JIT_ARGS) { r7=vm_fadd(r7,r5); NEXT }
ABC_JIT_CC abc_value float_fadd_7_6(ABC_JIT_ARGS) { r7=vm_fadd(r7,r6); NEXT }
ABC_JIT_CC abc_value float_fadd_7_7(ABC_JIT_ARGS) { r7=vm_fadd(r7,r7); NEXT }
ABC_JIT_CC abc_value float_fsub_0_0(ABC_JIT_ARGS) { r0=vm_fsub(r0,r0); NEXT }
ABC_JIT_CC abc_value float_fsub_0_1(ABC_JIT_ARGS) { r0=vm_fsub(r0,r1); NEXT }
ABC_JIT_CC abc_value float_fsub_0_2(ABC_JIT_ARGS) { r0=vm_fsub(r0,r2); NEXT }
ABC_JIT_CC abc_value float_fsub_0_3(ABC_JIT_ARGS) { r0=vm_fsub(r0,r3); NEXT }
ABC_JIT_CC abc_value float_fsub_0_4(ABC_JIT_ARGS) { r0=vm_fsub(r0,r4); NEXT }
ABC_JIT_CC abc_value float_fsub_0_5(ABC_JIT_ARGS) { r0=vm_fsub(r0,r5); NEXT }
ABC_JIT_CC abc_value float_fsub_0_6(ABC_JIT_ARGS) { r0=vm_fsub(r0,r6); NEXT }
ABC_JIT_CC abc_value float_fsub_0_7(ABC_JIT_ARGS) { r0=vm_fsub(r0,r7); NEXT }
ABC_JIT_CC abc_value float_fsub_1_0(ABC_JIT_ARGS) { r1=vm_fsub(r1,r0); NEXT }
ABC_JIT_CC abc_value float_fsub_1_1(ABC_JIT_ARGS) { r1=vm_fsub(r1,r1); NEXT }
ABC_JIT_CC abc_value float_fsub_1_2(ABC_JIT_ARGS) { r1=vm_fsub(r1,r2); NEXT }
ABC_JIT_CC abc_value float_fsub_1_3(ABC_JIT_ARGS) { r1=vm_fsub(r1,r3); NEXT }
ABC_JIT_CC abc_value float_fsub_1_4(ABC_JIT_ARGS) { r1=vm_fsub(r1,r4); NEXT }
ABC_JIT_CC abc_value float_fsub_1_5(ABC_JIT_ARGS) { r1=vm_fsub(r1,r5); NEXT }
ABC_JIT_CC abc_value float_fsub_1_6(ABC_JIT_ARGS) { r1=vm_fsub(r1,r6); NEXT }
ABC_JIT_CC abc_value float_fsub_1_7(ABC_JIT_ARGS) { r1=vm_fsub(r1,r7); NEXT }
ABC_JIT_CC abc_value float_fsub_2_0(ABC_JIT_ARGS) { r2=vm_fsub(r2,r0); NEXT }
ABC_JIT_CC abc_value float_fsub_2_1(ABC_JIT_ARGS) { r2=vm_fsub(r2,r1); NEXT }
ABC_JIT_CC abc_value float_fsub_2_2(ABC_JIT_ARGS) { r2=vm_fsub(r2,r2); NEXT }
ABC_JIT_CC abc_value float_fsub_2_3(ABC_JIT_ARGS) { r2=vm_fsub(r2,r3); NEXT }
ABC_JIT_CC abc_value float_fsub_2_4(ABC_JIT_ARGS) { r2=vm_fsub(r2,r4); NEXT }
ABC_JIT_CC abc_value float_fsub_2_5(ABC_JIT_ARGS) { r2=vm_fsub(r2,r5); NEXT }
ABC_JIT_CC abc_value float_fsub_2_6(ABC_JIT_ARGS) { r2=vm_fsub(r2,r6); NEXT }
ABC_JIT_CC abc_value float_fsub_2_7(ABC_JIT_ARGS) { r2=vm_fsub(r2,r7); NEXT }
ABC_JIT_CC abc_value float_fsub_3_0(ABC_JIT_ARGS) { r3=vm_fsub(r3,r0); NEXT }
ABC_JIT_CC abc_value float_fsub_3_1(ABC_JIT_ARGS) { r3=vm_fsub(r3,r1); NEXT }
ABC_JIT_CC abc_value float_fsub_3_2(ABC_JIT_ARGS) { r3=vm_fsub(r3,r2); NEXT }
ABC_JIT_CC abc_value float_fsub_3_3(ABC_JIT_ARGS) { r3=vm_fsub(r3,r3); NEXT }
ABC_JIT_CC abc_value float_fsub_3_4(ABC_JIT_ARGS) { r3=vm_fsub(r3,r4); NEXT }
ABC_JIT_CC abc_value float_fsub_3_5(ABC_JIT_ARGS) { r3=vm_fsub(r3,r5); NEXT }
ABC_JIT_CC abc_value float_fsub_3_6(ABC_JIT_ARGS) { r3=vm_fsub(r3,r6); NEXT }
ABC_JIT_CC abc_value float_fsub_3_7(ABC_JIT_ARGS) { r3=vm_fsub(r3,r7); NEXT }
ABC_JIT_CC abc_value float_fsub_4_0(ABC_JIT_ARGS) { r4=vm_fsub(r4,r0); NEXT }
ABC_JIT_CC abc_value float_fsub_4_1(ABC_JIT_ARGS) { r4=vm_fsub(r4,r1); NEXT }
ABC_JIT_CC abc_value float_fsub_4_2(ABC_JIT_ARGS) { r4=vm_fsub(r4,r2); NEXT }
ABC_JIT_CC abc_value float_fsub_4_3(ABC_JIT_ARGS) { r4=vm_fsub(r4,r3); NEXT }
ABC_JIT_CC abc_value float_fsub_4_4(ABC_JIT_ARGS) { r4=vm_fsub(r4,r4); NEXT }
ABC_JIT_CC abc_value float_fsub_4_5(ABC_JIT_ARGS) { r4=vm_fsub(r4,r5); NEXT }
ABC_JIT_CC abc_value float_fsub_4_6(ABC_JIT_ARGS) { r4=vm_fsub(r4,r6); NEXT }
ABC_JIT_CC abc_value float_fsub_4_7(ABC_JIT_ARGS) { r4=vm_fsub(r4,r7); NEXT }
ABC_JIT_CC abc_value float_fsub_5_0(ABC_JIT_ARGS) { r5=vm_fsub(r5,r0); NEXT }
ABC_JIT_CC abc_value float_fsub_5_1(ABC_JIT_ARGS) { r5=vm_fsub(r5,r1); NEXT }
ABC_JIT_CC abc_value float_fsub_5_2(ABC_JIT_ARGS) { r5=vm_fsub(r5,r2); NEXT }
ABC_JIT_CC abc_value float_fsub_5_3(ABC_JIT_ARGS) { r5=vm_fsub(r5,r3); NEXT }
ABC_JIT_CC abc_value float_fsub_5_4(ABC_JIT_ARGS) { r5=vm_fsub(r5,r4); NEXT }
ABC_JIT_CC abc_value float_fsub_5_5(ABC_JIT_ARGS) { r5=vm_fsub(r5,r5); NEXT }
ABC_JIT_CC abc_value float_fsub_5_6(ABC_JIT_ARGS) { r5=vm_fsub(r5,r6); NEXT }
ABC_JIT_CC abc_value float_fsub_5_7(ABC_JIT_ARGS) { r5=vm_fsub(r5,r7); NEXT }
ABC_JIT_CC abc_value float_fsub_6_0(ABC_JIT_ARGS) { r6=vm_fsub(r6,r0); NEXT }
ABC_JIT_CC abc_value float_fsub_6_1(ABC_JIT_ARGS) { r6=vm_fsub(r6,r1); NEXT }
ABC_JIT_CC abc_value float_fsub_6_2(ABC_JIT_ARGS) { r6=vm_fsub(r6,r2); NEXT }
ABC_JIT_CC abc_value float_fsub_6_3(ABC_JIT_ARGS) { r6=vm_fsub(r6,r3); NEXT }
ABC_JIT_CC abc_value float_fsub_6_4(ABC_JIT_ARGS) { r6=vm_fsub(r6,r4); NEXT }
ABC_JIT_CC abc_value float_fsub_6_5(ABC_JIT_ARGS) { r6=vm_fsub(r6,r5); NEXT }
ABC_JIT_CC abc_value float_fsub_6_6(ABC_JIT_ARGS) { r6=vm_fsub(r6,r6); NEXT }
ABC_JIT_CC abc_value float_fsub_6_7(ABC_JIT_ARGS) { r6=vm_fsub(r6,r7); NEXT }
ABC_JIT_CC abc_value float_fsub_7_0(ABC_JIT_ARGS) { r7=vm_fsub(r7,r0); NEXT }
ABC_JIT_CC abc_value float_fsub_7_1(ABC_JIT_ARGS) { r7=vm_fsub(r7,r1); NEXT }
ABC_JIT_CC abc_value float_fsub_7_2(ABC_JIT_ARGS) { r7=vm_fsub(r7,r2); NEXT }
ABC_JIT_CC abc_value float_fsub_7_3(ABC_JIT_ARGS) { r7=vm_fsub(r7,r3); NEXT }
ABC_JIT_CC abc_value float_fsub_7_4(ABC_JIT_ARGS) { r7=vm_fsub(r7,r4); NEXT }
ABC_JIT_CC abc_value float_fsub_7_5(ABC_JIT_ARGS) { r7=vm_fsub(r7,r5); NEXT }
ABC_JIT_CC abc_value float_fsub_7_6(ABC_JIT_ARGS) { r7=vm_fsub(r7,r6); NEXT }
ABC_JIT_CC abc_value float_fsub_7_7(ABC_JIT_ARGS) { r7=vm_fsub(r7,r7); NEXT }
ABC_JIT_CC abc_value float_fmul_0_0(ABC_JIT_ARGS) { r0=vm_fmul(r0,r0); NEXT }
ABC_JIT_CC abc_value float_fmul_0_1(ABC_JIT_ARGS) { r0=vm_fmul(r0,r1); NEXT }
ABC_JIT_CC abc_value float_fmul_0_2(ABC_JIT_ARGS) { r0=vm_fmul(r0,r2); NEXT }
ABC_JIT_CC abc_value float_fmul_0_3(ABC_JIT_ARGS) { r0=vm_fmul(r0,r3); NEXT }
ABC_JIT_CC abc_value float_fmul_0_4(ABC_JIT_ARGS) { r0=vm_fmul(r0,r4); NEXT }
ABC_JIT_CC abc_value float_fmul_0_5(ABC_JIT_ARGS) { r0=vm_fmul(r0,r5); NEXT }
ABC_JIT_CC abc_value float_fmul_0_6(ABC_JIT_ARGS) { r0=vm_fmul(r0,r6); NEXT }
ABC_JIT_CC abc_value float_fmul_0_7(ABC_JIT_ARGS) { r0=vm_fmul(r0,r7); NEXT }
ABC_JIT_CC abc_value float_fmul_1_0(ABC_JIT_ARGS) { r1=vm_fmul(r1,r0); NEXT }
ABC_JIT_CC abc_value float_fmul_1_1(ABC_JIT_ARGS) { r1=vm_fmul(r1,r1); NEXT }
ABC_JIT_CC abc_value float_fmul_1_2(ABC_JIT_ARGS) { r1=vm_fmul(r1,r2); NEXT }
ABC_JIT_CC abc_value float_fmul_1_3(ABC_JIT_ARGS) { r1=vm_fmul(r1,r3); NEXT }
ABC_JIT_CC abc_value float_fmul_1_4(ABC_JIT_ARGS) { r1=vm_fmul(r1,r4); NEXT }
ABC_JIT_CC abc_value float_fmul_1_5(ABC_JIT_ARGS) { r1=vm_fmul(r1,r5); NEXT }
ABC_JIT_CC abc_value float_fmul_1_6(ABC_JIT_ARGS) { r1=vm_fmul(r1,r6); NEXT }
ABC_JIT_CC abc_value float_fmul_1_7(ABC_JIT_ARGS) { r1=vm_fmul(r1,r7); NEXT }
ABC_JIT_CC abc_value float_fmul_2_0(ABC_JIT_ARGS) { r2=vm_fmul(r2,r0); NEXT }
ABC_JIT_CC abc_value float_fmul_2_1(ABC_JIT_ARGS) { r2=vm_fmul(r2,r1); NEXT }
ABC_JIT_CC abc_value float_fmul_2_2(ABC_JIT_ARGS) { r2=vm_fmul(r2,r2); NEXT }
ABC_JIT_CC abc_value float_fmul_2_3(ABC_JIT_ARGS) { r2=vm_fmul(r2,r3); NEXT }
ABC_JIT_CC abc_value float_fmul_2_4(ABC_JIT_ARGS) { r2=vm_fmul(r2,r4); NEXT }
ABC_JIT_CC abc_value float_fmul_2_5(ABC_JIT_ARGS) { r2=vm_fmul(r2,r5); NEXT }
ABC_JIT_CC abc_value float_fmul_2_6(ABC_JIT_ARGS) { r2=vm_fmul(r2,r6); NEXT }
ABC_JIT_CC abc_value float_fmul_2_7(ABC_JIT_ARGS) { r2=vm_fmul(r2,r7); NEXT }
ABC_JIT_CC abc_value float_fmul_3_0(ABC_JIT_ARGS) { r3=vm_fmul(r3,r0); NEXT }
ABC_JIT_CC abc_value float_fmul_3_1(ABC_JIT_ARGS) { r3=vm_fmul(r3,r1); NEXT }
ABC_JIT_CC abc_value float_fmul_3_2(ABC_JIT_ARGS) { r3=vm_fmul(r3,r2); NEXT }
ABC_JIT_CC abc_value float_fmul_3_3(ABC_JIT_ARGS) { r3=vm_fmul(r3,r3); NEXT }
ABC_JIT_CC abc_value float_fmul_3_4(ABC_JIT_ARGS) { r3=vm_fmul(r3,r4); NEXT }
ABC_JIT_CC abc_value float_fmul_3_5(ABC_JIT_ARGS) { r3=vm_fmul(r3,r5); NEXT }
ABC_JIT_CC abc_value float_fmul_3_6(ABC_JIT_ARGS) { r3=vm_fmul(r3,r6); NEXT }
ABC_JIT_CC abc_value float_fmul_3_7(ABC_JIT_ARGS) { r3=vm_fmul(r3,r7); NEXT }
ABC_JIT_CC abc_value float_fmul_4_0(ABC_JIT_ARGS) { r4=vm_fmul(r4,r0); NEXT }
ABC_JIT_CC abc_value float_fmul_4_1(ABC_JIT_ARGS) { r4=vm_fmul(r4,r1); NEXT }
ABC_JIT_CC abc_value float_fmul_4_2(ABC_JIT_ARGS) { r4=vm_fmul(r4,r2); NEXT }
ABC_JIT_CC abc_value float_fmul_4_3(ABC_JIT_ARGS) { r4=vm_fmul(r4,r3); NEXT }
ABC_JIT_CC abc_value float_fmul_4_4(ABC_JIT_ARGS) { r4=vm_fmul(r4,r4); NEXT }
ABC_JIT_CC abc_value float_fmul_4_5(ABC_JIT_ARGS) { r4=vm_fmul(r4,r5); NEXT }
ABC_JIT_CC abc_value float_fmul_4_6(ABC_JIT_ARGS) { r4=vm_fmul(r4,r6); NEXT }
ABC_JIT_CC abc_value float_fmul_4_7(ABC_JIT_ARGS) { r4=vm_fmul(r4,r7); NEXT }
ABC_JIT_CC abc_value float_fmul_5_0(ABC_JIT_ARGS) { r5=vm_fmul(r5,r0); NEXT }
ABC_JIT_CC abc_value float_fmul_5_1(ABC_JIT_ARGS) { r5=vm_fmul(r5,r1); NEXT }
ABC_JIT_CC abc_value float_fmul_5_2(ABC_JIT_ARGS) { r5=vm_fmul(r5,r2); NEXT }
ABC_JIT_CC abc_value float_fmul_5_3(ABC_JIT_ARGS) { r5=vm_fmul(r5,r3); NEXT }
ABC_JIT_CC abc_value float_fmul_5_4(ABC_JIT_ARGS) { r5=vm_fmul(r5,r4); NEXT }
ABC_JIT_CC abc_value float_fmul_5_5(ABC_JIT_ARGS) { r5=vm_fmul(r5,r5); NEXT }
ABC_JIT_CC abc_value float_fmul_5_6(ABC_JIT_ARGS) { r5=vm_fmul(r5,r6); NEXT }
ABC_JIT_CC abc_value float_fmul_5_7(ABC_JIT_ARGS) { r5=vm_fmul(r5,r7); NEXT }
ABC_JIT_CC abc_value float_fmul_6_0(ABC_JIT_ARGS) { r6=vm_fmul(r6,r0); NEXT }
ABC_JIT_CC abc_value float_fmul_6_1(ABC_JIT_ARGS) { r6=vm_fmul(r6,r1); NEXT }
ABC_JIT_CC abc_value float_fmul_6_2(ABC_JIT_ARGS) { r6=vm_fmul(r6,r2); NEXT }
ABC_JIT_CC abc_value float_fmul_6_3(ABC_JIT_ARGS) { r6=vm_fmul(r6,r3); NEXT }
ABC_JIT_CC abc_value float_fmul_6_4(ABC_JIT_ARGS) { r6=vm_fmul(r6,r4); NEXT }
ABC_JIT_CC abc_value float_fmul_6_5(ABC_JIT_ARGS) { r6=vm_fmul(r6,r5); NEXT }
ABC_JIT_CC abc_value float_fmul_6_6(ABC_JIT_ARGS) { r6=vm_fmul(r6,r6); NEXT }
ABC_JIT_CC abc_value float_fmul_6_7(ABC_JIT_ARGS) { r6=vm_fmul(r6,r7); NEXT }
ABC_JIT_CC abc_value float_fmul_7_0(ABC_JIT_ARGS) { r7=vm_fmul(r7,r0); NEXT }
ABC_JIT_CC abc_value float_fmul_7_1(ABC_JIT_ARGS) { r7=vm_fmul(r7,r1); NEXT }
ABC_JIT_CC abc_value float_fmul_7_2(ABC_JIT_ARGS) { r7=vm_fmul(r7,r2); NEXT }
ABC_JIT_CC abc_value float_fmul_7_3(ABC_JIT_ARGS) { r7=vm_fmul(r7,r3); NEXT }
ABC_JIT_CC abc_value float_fmul_7_4(ABC_JIT_ARGS) { r7=vm_fmul(r7,r4); NEXT }
ABC_JIT_CC abc_value float_fmul_7_5(ABC_JIT_ARGS) { r7=vm_fmul(r7,r5); NEXT }
ABC_JIT_CC abc_value float_fmul_7_6(ABC_JIT_ARGS) { r7=vm_fmul(r7,r6); NEXT }
ABC_JIT_CC abc_value float_fmul_7_7(ABC_JIT_ARGS) { r7=vm_fmul(r7,r7); NEXT }
ABC_JIT_CC abc_value float_fdiv_0_0(ABC_JIT_ARGS) { r0=vm_fdiv(r0,r0); NEXT }
ABC_JIT_CC abc_value float_fdiv_0_1(ABC_JIT_ARGS) { r0=vm_fdiv(r0,r1); NEXT }
ABC_JIT_CC abc_value float_fdiv_0_2(ABC_JIT_ARGS) { r0=vm_fdiv(r0,r2); NEXT }
ABC_JIT_CC abc_value float_fdiv_0_3(ABC_JIT_ARGS) { r0=vm_fdiv(r0,r3); NEXT }
ABC_JIT_CC abc_value float_fdiv_0_4(ABC_JIT_ARGS) { r0=vm_fdiv(r0,r4); NEXT }
ABC_JIT_CC abc_value float_fdiv_0_5(ABC_JIT_ARGS) { r0=vm_fdiv(r0,r5); NEXT }
ABC_JIT_CC abc_value float_fdiv_0_6(ABC_JIT_ARGS) { r0=vm_fdiv(r0,r6); NEXT }
ABC_JIT_CC abc_value float_fdiv_0_7(ABC_JIT_ARGS) { r0=vm_fdiv(r0,r7); NEXT }
ABC_JIT_CC abc_value float_fdiv_1_0(ABC_JIT_ARGS) { r1=vm_fdiv(r1,r0); NEXT }
ABC_JIT_CC abc_value float_fdiv_1_1(ABC_JIT_ARGS) { r1=vm_fdiv(r1,r1); NEXT }
ABC_JIT_CC abc_value float_fdiv_1_2(ABC_JIT_ARGS) { r1=vm_fdiv(r1,r2); NEXT }
ABC_JIT_CC abc_value float_fdiv_1_3(ABC_JIT_ARGS) { r1=vm_fdiv(r1,r3); NEXT }
ABC_JIT_CC abc_value float_fdiv_1_4(ABC_JIT_ARGS) { r1=vm_fdiv(r1,r4); NEXT }
ABC_JIT_CC abc_value float_fdiv_1_5(ABC_JIT_ARGS) { r1=vm_fdiv(r1,r5); NEXT }
ABC_JIT_CC abc_value float_fdiv_1_6(ABC_JIT_ARGS) { r1=vm_fdiv(r1,r6); NEXT }
ABC_JIT_CC abc_value float_fdiv_1_7(ABC_JIT_ARGS) { r1=vm_fdiv(r1,r7); NEXT }
ABC_JIT_CC abc_value float_fdiv_2_0(ABC_JIT_ARGS) { r2=vm_fdiv(r2,r0); NEXT }
ABC_JIT_CC abc_value float_fdiv_2_1(ABC_JIT_ARGS) { r2=vm_fdiv(r2,r1); NEXT }
ABC_JIT_CC abc_value float_fdiv_2_2(ABC_JIT_ARGS) { r2=vm_fdiv(r2,r2); NEXT }
ABC_JIT_CC abc_value float_fdiv_2_3(ABC_JIT_ARGS) { r2=vm_fdiv(r2,r3); NEXT }
ABC_JIT_CC abc_value float_fdiv_2_4(ABC_JIT_ARGS) { r2=vm_fdiv(r2,r4); NEXT }
ABC_JIT_CC abc_value float_fdiv_2_5(ABC_JIT_ARGS) { r2=vm_fdiv(r2,r5); NEXT }
ABC_JIT_CC abc_value float_fdiv_2_6(ABC_JIT_ARGS) { r2=vm_fdiv(r2,r6); NEXT }
ABC_JIT_CC abc_value float_fdiv_2_7(ABC_JIT_ARGS) { r2=vm_fdiv(r2,r7); NEXT }
ABC_JIT_CC abc_value float_fdiv_3_0(ABC_JIT_ARGS) { r3=vm_fdiv(r3,r0); NEXT }
ABC_JIT_CC abc_value float_fdiv_3_1(ABC_JIT_ARGS) { r3=vm_fdiv(r3,r1); NEXT }
ABC_JIT_CC abc_value float_fdiv_3_2(ABC_JIT_ARGS) { r3=vm_fdiv(r3,r2); NEXT }
ABC_JIT_CC abc_value float_fdiv_3_3(ABC_JIT_ARGS) { r3=vm_fdiv(r3,r3); NEXT }
ABC_JIT_CC abc_value float_fdiv_3_4(ABC_JIT_ARGS) { r3=vm_fdiv(r3,r4); NEXT }
ABC_JIT_CC abc_value float_fdiv_3_5(ABC_JIT_ARGS) { r3=vm_fdiv(r3,r5); NEXT }
ABC_JIT_CC abc_value float_fdiv_3_6(ABC_JIT_ARGS) { r3=vm_fdiv(r3,r6); NEXT }
ABC_JIT_CC abc_value float_fdiv_3_7(ABC_JIT_ARGS) { r3=vm_fdiv(r3,r7); NEXT }
ABC_JIT_CC abc_value float_fdiv_4_0(ABC_JIT_ARGS) { r4=vm_fdiv(r4,r0); NEXT }
ABC_JIT_CC abc_value float_fdiv_4_1(ABC_JIT_ARGS) { r4=vm_fdiv(r4,r1); NEXT }
ABC_JIT_CC abc_value float_fdiv_4_2(ABC_JIT_ARGS) { r4=vm_fdiv(r4,r2); NEXT }
ABC_JIT_CC abc_value float_fdiv_4_3(ABC_JIT_ARGS) { r4=vm_fdiv(r4,r3); NEXT }
ABC_JIT_CC abc_value float_fdiv_4_4(ABC_JIT_ARGS) { r4=vm_fdiv(r4,r4); NEXT }
ABC_JIT_CC abc_value float_fdiv_4_5(ABC_JIT_ARGS) { r4=vm_fdiv(r4,r5); NEXT }
ABC_JIT_CC abc_value float_fdiv_4_6(ABC_JIT_ARGS) { r4=vm_fdiv(r4,r6); NEXT }
ABC_JIT_CC abc_value float_fdiv_4_7(ABC_JIT_ARGS) { r4=vm_fdiv(r4,r7); NEXT }
ABC_JIT_CC abc_value float_fdiv_5_0(ABC_JIT_ARGS) { r5=vm_fdiv(r5,r0); NEXT }
ABC_JIT_CC abc_value float_fdiv_5_1(ABC_JIT_ARGS) { r5=vm_fdiv(r5,r1); NEXT }
ABC_JIT_CC abc_value float_fdiv_5_2(ABC_JIT_ARGS) { r5=vm_fdiv(r5,r2); NEXT }
ABC_JIT_CC abc_value float_fdiv_5_3(ABC_JIT_ARGS) { r5=vm_fdiv(r5,r3); NEXT }
ABC_JIT_CC abc_value float_fdiv_5_4(ABC_JIT_ARGS) { r5=vm_fdiv(r5,r4); NEXT }
ABC_JIT_CC abc_value float_fdiv_5_5(ABC_JIT_ARGS) { r5=vm_fdiv(r5,r5); NEXT }
ABC_JIT_CC abc_value float_fdiv_5_6(ABC_JIT_ARGS) { r5=vm_fdiv(r5,r6); NEXT }
ABC_JIT_CC abc_value float_fdiv_5_7(ABC_JIT_ARGS) { r5=vm_fdiv(r5,r7); NEXT }
ABC_JIT_CC abc_value float_fdiv_6_0(ABC_JIT_ARGS) { r6=vm_fdiv(r6,r0); NEXT }
ABC_JIT_CC abc_value float_fdiv_6_1(ABC_JIT_ARGS) { r6=vm_fdiv(r6,r1); NEXT }
ABC_JIT_CC abc_value float_fdiv_6_2(ABC_JIT_ARGS) { r6=vm_fdiv(r6,r2); NEXT }
ABC_JIT_CC abc_value float_fdiv_6_3(ABC_JIT_ARGS) { r6=vm_fdiv(r6,r3); NEXT }
ABC_JIT_CC abc_value float_fdiv_6_4(ABC_JIT_ARGS) { r6=vm_fdiv(r6,r4); NEXT }
ABC_JIT_CC abc_value float_fdiv_6_5(ABC_JIT_ARGS) { r6=vm_fdiv(r6,r5); NEXT }
ABC_JIT_CC abc_value float_fdiv_6_6(ABC_JIT_ARGS) { r6=vm_fdiv(r6,r6); NEXT }
ABC_JIT_CC abc_value float_fdiv_6_7(ABC_JIT_ARGS) { r6=vm_fdiv(r6,r7); NEXT }
ABC_JIT_CC abc_value float_fdiv_7_0(ABC_JIT_ARGS) { r7=vm_fdiv(r7,r0); NEXT }
ABC_JIT_CC abc_value float_fdiv_7_1(ABC_JIT_ARGS) { r7=vm_fdiv(r7,r1); NEXT }
ABC_JIT_CC abc_value float_fdiv_7_2(ABC_JIT_ARGS) { r7=vm_fdiv(r7,r2); NEXT }
ABC_JIT_CC abc_value float_fdiv_7_3(ABC_JIT_ARGS) { r7=vm_fdiv(r7,r3); NEXT }
ABC_JIT_CC abc_value float_fdiv_7_4(ABC_JIT_ARGS) { r7=vm_fdiv(r7,r4); NEXT }
ABC_JIT_CC abc_value float_fdiv_7_5(ABC_JIT_ARGS) { r7=vm_fdiv(r7,r5); NEXT }
ABC_JIT_CC abc_value float_fdiv_7_6(ABC_JIT_ARGS) { r7=vm_fdiv(r7,r6); NEXT }
ABC_JIT_CC abc_value float_fdiv_7_7(ABC_JIT_ARGS) { r7=vm_fdiv(r7,r7); NEXT }
ABC_JIT_CC abc_value float_flt_0_0(ABC_JIT_ARGS) { r0=vm_flt(r0,r0); NEXT }
ABC_JIT_CC abc_value float_flt_0_1(ABC_JIT_ARGS) { r0=vm_flt(r0,r1); NEXT }
ABC_JIT_CC abc_value float_flt_0_2(ABC_JIT_ARGS) { r0=vm_flt(r0,r2); NEXT }
ABC_JIT_CC abc_value float_flt_0_3(ABC_JIT_ARGS) { r0=vm_flt(r0,r3); NEXT }
ABC_JIT_CC abc_value float_flt_0_4(ABC_JIT_ARGS) { r0=vm_flt(r0,r4); NEXT }
ABC_JIT_CC abc_value float_flt_0_5(ABC_JIT_ARGS) { r0=vm_flt(r0,r5); NEXT }
ABC_JIT_CC abc_value float_flt_0_6(ABC_JIT_ARGS) { r0=vm_flt(r0,r6); NEXT }
ABC_JIT_CC abc_value float_flt_0_7(ABC_JIT_ARGS) { r0=vm_flt(r0,r7); NEXT }
ABC_JIT_CC abc_value float_flt_1_0(ABC_JIT_ARGS) { r1=vm_flt(r1,r0); NEXT }
ABC_JIT_CC abc_value float_flt_1_1(ABC_JIT_ARGS) { r1=vm_flt(r1,r1); NEXT }
ABC_JIT_CC abc_value float_flt_1_2(ABC_JIT_ARGS) { r1=vm_flt(r1,r2); NEXT }
ABC_JIT_CC abc_value float_flt_1_3(ABC_JIT_ARGS) { r1=vm_flt(r1,r3); NEXT }
ABC_JIT_CC abc_value float_flt_1_4(ABC_JIT_ARGS) { r1=vm_flt(r1,r4); NEXT }
ABC_JIT_CC abc_value float_flt_1_5(ABC_JIT_ARGS) { r1=vm_flt(r1,r5); NEXT }
ABC_JIT_CC abc_value float_flt_1_6(ABC_JIT_ARGS) { r1=vm_flt(r1,r6); NEXT }
ABC_JIT_CC abc_value float_flt_1_7(ABC_JIT_ARGS) { r1=vm_flt(r1,r7); NEXT }
ABC_JIT_CC abc_value float_flt_2_0(ABC_JIT_ARGS) { r2=vm_flt(r2,r0); NEXT }
ABC_JIT_CC abc_value float_flt_2_1(ABC_JIT_ARGS) { r2=vm_flt(r2,r1); NEXT }
ABC_JIT_CC abc_value float_flt_2_2(ABC_JIT_ARGS) { r2=vm_flt(r2,r2); NEXT }
ABC_JIT_CC abc_value float_flt_2_3(ABC_JIT_ARGS) { r2=vm_flt(r2,r3); NEXT }
ABC_JIT_CC abc_value float_flt_2_4(ABC_JIT_ARGS) { r2=vm_flt(r2,r4); NEXT }
ABC_JIT_CC abc_value float_flt_2_5(ABC_JIT_ARGS) { r2=vm_flt(r2,r5); NEXT }
ABC_JIT_CC abc_value float_flt_2_6(ABC_JIT_ARGS) { r2=vm_flt(r2,r6); NEXT }
ABC_JIT_CC abc_value float_flt_2_7(ABC_JIT_ARGS) { r2=vm_flt(r2,r7); NEXT }
ABC_JIT_CC abc_value float_flt_3_0(ABC_JIT_ARGS) { r3=vm_flt(r3,r0); NEXT }
ABC_JIT_CC abc_value float_flt_3_1(ABC_JIT_ARGS) { r3=vm_flt(r3,r1); NEXT }
ABC_JIT_CC abc_value float_flt_3_2(ABC_JIT_ARGS) { r3=vm_flt(r3,r2); NEXT }
ABC_JIT_CC abc_value float_flt_3_3(ABC_JIT_ARGS) { r3=vm_flt(r3,r3); NEXT }
ABC_JIT_CC abc_value float_flt_3_4(ABC_JIT_ARGS) { r3=vm_flt(r3,r4); NEXT }
ABC_JIT_CC abc_value float_flt_3_5(ABC_JIT_ARGS) { r3=vm_flt(r3,r5); NEXT }
ABC_JIT_CC abc_value float_flt_3_6(ABC_JIT_ARGS) { r3=vm_flt(r3,r6); NEXT }
ABC_JIT_CC abc_value float_flt_3_7(ABC_JIT_ARGS) { r3=vm_flt(r3,r7); NEXT }
ABC_JIT_CC abc_value float_flt_4_0(ABC_JIT_ARGS) { r4=vm_flt(r4,r0); NEXT }
ABC_JIT_CC abc_value float_flt_4_1(ABC_JIT_ARGS) { r4=vm_flt(r4,r1); NEXT }
ABC_JIT_CC abc_value float_flt_4_2(ABC_JIT_ARGS) { r4=vm_flt(r4,r2); NEXT }
ABC_JIT_CC abc_value float_flt_4_3(ABC_JIT_ARGS) { r4=vm_flt(r4,r3); NEXT }
ABC_JIT_CC abc_value float_flt_4_4(ABC_JIT_ARGS) { r4=vm_flt(r4,r4); NEXT }
ABC_JIT_CC abc_value float_flt_4_5(ABC_JIT_ARGS) { r4=vm_flt(r4,r5); NEXT }
ABC_JIT_CC abc_value float_flt_4_6(ABC_JIT_ARGS) { r4=vm_flt(r4,r6); NEXT }
ABC_JIT_CC abc_value float_flt_4_7(ABC_JIT_ARGS) { r4=vm_flt(r4,r7); NEXT }
ABC_JIT_CC abc_value float_flt_5_0(ABC_JIT_ARGS) { r5=vm_flt(r5,r0); NEXT }
ABC_JIT_CC abc_value float_flt_5_1(ABC_JIT_ARGS) { r5=vm_flt(r5,r1); NEXT }
ABC_JIT_CC abc_value float_flt_5_2(ABC_JIT_ARGS) { r5=vm_flt(r5,r2); NEXT }
ABC_JIT_CC abc_value float_flt_5_3(ABC_JIT_ARGS) { r5=vm_flt(r5,r3); NEXT }
ABC_JIT_CC abc_value float_flt_5_4(ABC_JIT_ARGS) { r5=vm_flt(r5,r4); NEXT }
ABC_JIT_CC abc_value float_flt_5_5(ABC_JIT_ARGS) { r5=vm_flt(r5,r5); NEXT }
ABC_JIT_CC abc_value float_flt_5_6(ABC_JIT_ARGS) { r5=vm_flt(r5,r6); NEXT }
ABC_JIT_CC abc_value float_flt_5_7(ABC_JIT_ARGS) { r5=vm_flt(r5,r7); NEXT }
ABC_JIT_CC abc_value float_flt_6_0(ABC_JIT_ARGS) { r6=vm_flt(r6,r0); NEXT }
ABC_JIT_CC abc_value float_flt_6_1(ABC_JIT_ARGS) { r6=vm_flt(r6,r1); NEXT }
ABC_JIT_CC abc_value float_flt_6_2(ABC_JIT_ARGS) { r6=vm_flt(r6,r2); NEXT }
ABC_JIT_CC abc_value float_flt_6_3(ABC_JIT_ARGS) { r6=vm_flt(r6,r3); NEXT }
ABC_JIT_CC abc_value float_flt_6_4(ABC_JIT_ARGS) { r6=vm_flt(r6,r4); NEXT }
ABC_JIT_CC abc_value float_flt_6_5(ABC_JIT_ARGS) { r6=vm_flt(r6,r5); NEXT }
ABC_JIT_CC abc_value float_flt_6_6(ABC_JIT_ARGS) { r6=vm_flt(r6,r6); NEXT }
ABC_JIT_CC abc_value float_flt_6_7(ABC_JIT_ARGS) { r6=vm_flt(r6,r7); NEXT }
ABC_JIT_CC abc_value float_flt_7_0(ABC_JIT_ARGS) { r7=vm_flt(r7,r0); NEXT }
ABC_JIT_CC abc_value float_flt_7_1(ABC_JIT_ARGS) { r7=vm_flt(r7,r1); NEXT }
ABC_JIT_CC abc_value float_flt_7_2(ABC_JIT_ARGS) { r7=vm_flt(r7,r2); NEXT }
ABC_JIT_CC abc_value float_flt_7_3(ABC_JIT_ARGS) { r7=vm_flt(r7,r3); NEXT }
ABC_JIT_CC abc_value float_flt_7_4(ABC_JIT_ARGS) { r7=vm_flt(r7,r4); NEXT }
ABC_JIT_CC abc_value float_flt_7_5(ABC_JIT_ARGS) { r7=vm_flt(r7,r5); NEXT }
ABC_JIT_CC abc_value float_flt_7_6(ABC_JIT_ARGS) { r7=vm_flt(r7,r6); NEXT }
ABC_JIT_CC abc_value float_flt_7_7(ABC_JIT_ARGS) { r7=vm_flt(r7,r7); NEXT }
ABC_JIT_CC abc_value float_fle_0_0(ABC_JIT_ARGS) { r0=vm_fle(r0,r0); NEXT }
ABC_JIT_CC abc_value float_fle_0_1(ABC_JIT_ARGS) { r0=vm_fle(r0,r1); NEXT }
ABC_JIT_CC abc_value float_fle_0_2(ABC_JIT_ARGS) { r0=vm_fle(r0,r2); NEXT }
ABC_JIT_CC abc_value float_fle_0_3(ABC_JIT_ARGS) { r0=vm_fle(r0,r3); NEXT }
ABC_JIT_CC abc_value float_fle_0_4(ABC_JIT_ARGS) { r0=vm_fle(r0,r4); NEXT }
ABC_JIT_CC abc_value float_fle_0_5(ABC_JIT_ARGS) { r0=vm_fle(r0,r5); NEXT }
ABC_JIT_CC abc_value float_fle_0_6(ABC_JIT_ARGS) { r0=vm_fle(r0,r6); NEXT }
ABC_JIT_CC abc_value float_fle_0_7(ABC_JIT_ARGS) { r0=vm_fle(r0,r7); NEXT }
ABC_JIT_CC abc_value float_fle_1_0(ABC_JIT_ARGS) { r1=vm_fle(r1,r0); NEXT }
ABC_JIT_CC abc_value float_fle_1_1(ABC_JIT_ARGS) { r1=vm_fle(r1,r1); NEXT }
ABC_JIT_CC abc_value float_fle_1_2(ABC_JIT_ARGS) { r1=vm_fle(r1,r2); NEXT }
ABC_JIT_CC abc_value float_fle_1_3(ABC_JIT_ARGS) { r1=vm_fle(r1,r3); NEXT }
ABC_JIT_CC abc_value float_fle_1_4(ABC_JIT_ARGS) { r1=vm_fle(r1,r4); NEXT }
ABC_JIT_CC abc_value float_fle_1_5(ABC_JIT_ARGS) { r1=vm_fle(r1,r5); NEXT }
ABC_JIT_CC abc_value float_fle_1_6(ABC_JIT_ARGS) { r1=vm_fle(r1,r6); NEXT }
ABC_JIT_CC abc_value float_fle_1_7(ABC_JIT_ARGS) { r1=vm_fle(r1,r7); NEXT }
ABC_JIT_CC abc_value float_fle_2_0(ABC_JIT_ARGS) { r2=vm_fle(r2,r0); NEXT }
ABC_JIT_CC abc_value float_fle_2_1(ABC_JIT_ARGS) { r2=vm_fle(r2,r1); NEXT }
ABC_JIT_CC abc_value float_fle_2_2(ABC_JIT_ARGS) { r2=vm_fle(r2,r2); NEXT }
ABC_JIT_CC abc_value float_fle_2_3(ABC_JIT_ARGS) { r2=vm_fle(r2,r3); NEXT }
ABC_JIT_CC abc_value float_fle_2_4(ABC_JIT_ARGS) { r2=vm_fle(r2,r4); NEXT }
ABC_JIT_CC abc_value float_fle_2_5(ABC_JIT_ARGS) { r2=vm_fle(r2,r5); NEXT }
ABC_JIT_CC abc_value float_fle_2_6(ABC_JIT_ARGS) { r2=vm_fle(r2,r6); NEXT }
ABC_JIT_CC abc_value float_fle_2_7(ABC_JIT_ARGS) { r2=vm_fle(r2,r7); NEXT }
ABC_JIT_CC abc_value float_fle_3_0(ABC_JIT_ARGS) { r3=vm_fle(r3,r0); NEXT }
ABC_JIT_CC abc_value float_fle_3_1(ABC_JIT_ARGS) { r3=vm_fle(r3,r1); NEXT }
ABC_JIT_CC abc_value float_fle_3_2(ABC_JIT_ARGS) { r3=vm_fle(r3,r2); NEXT }
ABC_JIT_CC abc_value float_fle_3_3(ABC_JIT_ARGS) { r3=vm_fle(r3,r3); NEXT }
ABC_JIT_CC abc_value float_fle_3_4(ABC_JIT_ARGS) { r3=vm_fle(r3,r4); NEXT }
ABC_JIT_CC abc_value float_fle_3_5(ABC_JIT_ARGS) { r3=vm_fle(r3,r5); NEXT }
ABC_JIT_CC abc_value float_fle_3_6(ABC_JIT_ARGS) { r3=vm_fle(r3,r6); NEXT }
ABC_JIT_CC abc_value float_fle_3_7(ABC_JIT_ARGS) { r3=vm_fle(r3,r7); NEXT }
ABC_JIT_CC abc_value float_fle_4_0(ABC_JIT_ARGS) { r4=vm_fle(r4,r0); NEXT }
ABC_JIT_CC abc_value float_fle_4_1(ABC_JIT_ARGS) { r4=vm_fle(r4,r1); NEXT }
ABC_JIT_CC abc_value float_fle_4_2(ABC_JIT_ARGS) { r4=vm_fle(r4,r2); NEXT }
ABC_JIT_CC abc_value float_fle_4_3(ABC_JIT_ARGS) { r4=vm_fle(r4,r3); NEXT }
ABC_JIT_CC abc_value float_fle_4_4(ABC_JIT_ARGS) { r4=vm_fle(r4,r4); NEXT }
ABC_JIT_CC abc_value float_fle_4_5(ABC_JIT_ARGS) { r4=vm_fle(r4,r5); NEXT }
ABC_JIT_CC abc_value float_fle_4_6(ABC_JIT_ARGS) { r4=vm_fle(r4,r6); NEXT }
ABC_JIT_CC abc_value float_fle_4_7(ABC_JIT_ARGS) { r4=vm_fle(r4,r7); NEXT }
ABC_JIT_CC abc_value float_fle_5_0(ABC_JIT_ARGS) { r5=vm_fle(r5,r0); NEXT }
ABC_JIT_CC abc_value float_fle_5_1(ABC_JIT_ARGS) { r5=vm_fle(r5,r1); NEXT }
ABC_JIT_CC abc_value float_fle_5_2(ABC_JIT_ARGS) { r5=vm_fle(r5,r2); NEXT }
ABC_JIT_CC abc_value float_fle_5_3(ABC_JIT_ARGS) { r5=vm_fle(r5,r3); NEXT }
ABC_JIT_CC abc_value float_fle_5_4(ABC_JIT_ARGS) { r5=vm_fle(r5,r4); NEXT }
ABC_JIT_CC abc_value float_fle_5_5(ABC_JIT_ARGS) { r5=vm_fle(r5,r5); NEXT }
ABC_JIT_CC abc_value float_fle_5_6(ABC_JIT_ARGS) { r5=vm_fle(r5,r6); NEXT }
ABC_JIT_CC abc_value float_fle_5_7(ABC_JIT_ARGS) { r5=vm_fle(r5,r7); NEXT }
ABC_JIT_CC abc_value float_fle_6_0(ABC_JIT_ARGS) { r6=vm_fle(r6,r0); NEXT }
ABC_JIT_CC abc_value float_fle_6_1(ABC_JIT_ARGS) { r6=vm_fle(r6,r1); NEXT }
ABC_JIT_CC abc_value float_fle_6_2(ABC_JIT_ARGS) { r6=vm_fle(r6,r2); NEXT }
ABC_JIT_CC abc_value float_fle_6_3(ABC_JIT_ARGS) { r6=vm_fle(r6,r3); NEXT }
ABC_JIT_CC abc_value float_fle_6_4(ABC_JIT_ARGS) { r6=vm_fle(r6,r4); NEXT }
ABC_JIT_CC abc_value float_fle_6_5(ABC_JIT_ARGS) { r6=vm_fle(r6,r5); NEXT }
ABC_JIT_CC abc_value float_fle_6_6(ABC_JIT_ARGS) { r6=vm_fle(r6,r6); NEXT }
ABC_JIT_CC abc_value float_fle_6_7(ABC_JIT_ARGS) { r6=vm_fle(r6,r7); NEXT }
ABC_JIT_CC abc_value float_fle_7_0(ABC_JIT_ARGS) { r7=vm_fle(r7,r0); NEXT }
ABC_JIT_CC abc_value float_fle_7_1(ABC_JIT_ARGS) { r7=vm_fle(r7,r1); NEXT }
ABC_JIT_CC abc_value float_fle_7_2(ABC_JIT_ARGS) { r7=vm_fle(r7,r2); NEXT }
ABC_JIT_CC abc_value float_fle_7_3(ABC_JIT_ARGS) { r7=vm_fle(r7,r3); NEXT }
ABC_JIT_CC abc_value float_fle_7_4(ABC_JIT_ARGS) { r7=vm_fle(r7,r4); NEXT }
ABC_JIT_CC abc_value float_fle_7_5(ABC_JIT_ARGS) { r7=vm_fle(r7,r5); NEXT }
ABC_JIT_CC abc_value float_fle_7_6(ABC_JIT_ARGS) { r7=vm_fle(r7,r6); NEXT }
ABC_JIT_CC abc_value float_fle_7_7(ABC_JIT_ARGS) { r7=vm_fle(r7,r7); NEXT }
ABC_JIT_CC abc_value float_feq_0_0(ABC_JIT_ARGS) { r0=vm_feq(r0,r0); NEXT }
ABC_JIT_CC abc_value float_feq_0_1(ABC_JIT_ARGS) { r0=vm_feq(r0,r1); NEXT }
ABC_JIT_CC abc_value float_feq_0_2(ABC_JIT_ARGS) { r0=vm_feq(r0,r2); NEXT }
ABC_JIT_CC abc_value float_feq_0_3(ABC_JIT_ARGS) { r0=vm_feq(r0,r3); NEXT }
ABC_JIT_CC abc_value float_feq_0_4(ABC_JIT_ARGS) { r0=vm_feq(r0,r4); NEXT }
ABC_JIT_CC abc_value float_feq_0_5(ABC_JIT_ARGS) { r0=vm_feq(r0,r5); NEXT }
ABC_JIT_CC abc_value float_feq_0_6(ABC_JIT_ARGS) { r0=vm_feq(r0,r6); NEXT }
ABC_JIT_CC abc_value float_feq_0_7(ABC_JIT_ARGS) { r0=vm_feq(r0,r7); NEXT }
ABC_JIT_CC abc_value float_feq_1_0(ABC_JIT_ARGS) { r1=vm_feq(r1,r0); NEXT }
ABC_JIT_CC abc_value float_feq_1_1(ABC_JIT_ARGS) { r1=vm_feq(r1,r1); NEXT }
ABC_JIT_CC abc_value float_feq_1_2(ABC_JIT_ARGS) { r1=vm_feq(r1,r2); NEXT }
ABC_JIT_CC abc_value float_feq_1_3(ABC_JIT_ARGS) { r1=vm_feq(r1,r3); NEXT }
ABC_JIT_CC abc_value float_feq_1_4(ABC_JIT_ARGS) { r1=vm_feq(r1,r4); NEXT }
ABC_JIT_CC abc_value float_feq_1_5(ABC_JIT_ARGS) { r1=vm_feq(r1,r5); NEXT }
ABC_JIT_CC abc_value float_feq_1_6(ABC_JIT_ARGS) { r1=vm_feq(r1,r6); NEXT }
ABC_JIT_CC abc_value float_feq_1_7(ABC_JIT_ARGS) { r1=vm_feq(r1,r7); NEXT }
ABC_JIT_CC abc_value float_feq_2_0(ABC_JIT_ARGS) { r2=vm_feq(r2,r0); NEXT }
ABC_JIT_CC abc_value float_feq_2_1(ABC_JIT_ARGS) { r2=vm_feq(r2,r1); NEXT }
ABC_JIT_CC abc_value float_feq_2_2(ABC_JIT_ARGS) { r2=vm_feq(r2,r2); NEXT }
ABC_JIT_CC abc_value float_feq_2_3(ABC_JIT_ARGS) { r2=vm_feq(r2,r3); NEXT }
ABC_JIT_CC abc_value float_feq_2_4(ABC_JIT_ARGS) { r2=vm_feq(r2,r4); NEXT }
ABC_JIT_CC abc_value float_feq_2_5(ABC_JIT_ARGS) { r2=vm_feq(r2,r5); NEXT }
ABC_JIT_CC abc_value float_feq_2_6(ABC_JIT_ARGS) { r2=vm_feq(r2,r6); NEXT }
ABC_JIT_CC abc_value float_feq_2_7(ABC_JIT_ARGS) { r2=vm_feq(r2,r7); NEXT }
ABC_JIT_CC abc_value float_feq_3_0(ABC_JIT_ARGS) { r3=vm_feq(r3,r0); NEXT }
ABC_JIT_CC abc_value float_feq_3_1(ABC_JIT_ARGS) { r3=vm_feq(r3,r1); NEXT }
ABC_JIT_CC abc_value float_feq_3_2(ABC_JIT_ARGS) { r3=vm_feq(r3,r2); NEXT }
ABC_JIT_CC abc_value float_feq_3_3(ABC_JIT_ARGS) { r3=vm_feq(r3,r3); NEXT }
ABC_JIT_CC abc_value float_feq_3_4(ABC_JIT_ARGS) { r3=vm_feq(r3,r4); NEXT }
ABC_JIT_CC abc_value float_feq_3_5(ABC_JIT_ARGS) { r3=vm_feq(r3,r5); NEXT }
ABC_JIT_CC abc_value float_feq_3_6(ABC_JIT_ARGS) { r3=vm_feq(r3,r6); NEXT }
ABC_JIT_CC abc_value float_feq_3_7(ABC_JIT_ARGS) { r3=vm_feq(r3,r7); NEXT }
ABC_JIT_CC abc_value float_feq_4_0(ABC_JIT_ARGS) { r4=vm_feq(r4,r0); NEXT }
ABC_JIT_CC abc_value float_feq_4_1(ABC_JIT_ARGS) { r4=vm_feq(r4,r1); NEXT }
ABC_JIT_CC abc_value float_feq_4_2(ABC_JIT_ARGS) { r4=vm_feq(r4,r2); NEXT }
ABC_JIT_CC abc_value float_feq_4_3(ABC_JIT_ARGS) { r4=vm_feq(r4,r3); NEXT }
ABC_JIT_CC abc_value float_feq_4_4(ABC_JIT_ARGS) { r4=vm_feq(r4,r4); NEXT }
ABC_JIT_CC abc_value float_feq_4_5(ABC_JIT_ARGS) { r4=vm_feq(r4,r5); NEXT }
ABC_JIT_CC abc_value float_feq_4_6(ABC_JIT_ARGS) { r4=vm_feq(r4,r6); NEXT }
ABC_JIT_CC abc_value float_feq_4_7(ABC_JIT_ARGS) { r4=vm_feq(r4,r7); NEXT }
ABC_JIT_CC abc_value float_feq_5_0(ABC_JIT_ARGS) { r5=vm_feq(r5,r0); NEXT }
ABC_JIT_CC abc_value float_feq_5_1(ABC_JIT_ARGS) { r5=vm_feq(r5,r1); NEXT }
ABC_JIT_CC abc_value float_feq_5_2(ABC_JIT_ARGS) { r5=vm_feq(r5,r2); NEXT }
ABC_JIT_CC abc_value float_feq_5_3(ABC_JIT_ARGS) { r5=vm_feq(r5,r3); NEXT }
ABC_JIT_CC abc_value float_feq_5_4(ABC_JIT_ARGS) { r5=vm_feq(r5,r4); NEXT }
ABC_JIT_CC abc_value float_feq_5_5(ABC_JIT_ARGS) { r5=vm_feq(r5,r5); NEXT }
ABC_JIT_CC abc_value float_feq_5_6(ABC_JIT_ARGS) { r5=vm_feq(r5,r6); NEXT }
ABC_JIT_CC abc_value float_feq_5_7(ABC_JIT_ARGS) { r5=vm_feq(r5,r7); NEXT }
ABC_JIT_CC abc_value float_feq_6_0(ABC_JIT_ARGS) { r6=vm_feq(r6,r0); NEXT }
ABC_JIT_CC abc_value float_feq_6_1(ABC_JIT_ARGS) { r6=vm_feq(r6,r1); NEXT }
ABC_JIT_CC abc_value float_feq_6_2(ABC_JIT_ARGS) { r6=vm_feq(r6,r2); NEXT }
ABC_JIT_CC abc_value float_feq_6_3(ABC_JIT_ARGS) { r6=vm_feq(r6,r3); NEXT }
ABC_JIT_CC abc_value float_feq_6_4(ABC_JIT_ARGS) { r6=vm_feq(r6,r4); NEXT }
ABC_JIT_CC abc_value float_feq_6_5(ABC_JIT_ARGS) { r6=vm_feq(r6,r5); NEXT }
ABC_JIT_CC abc_value float_feq_6_6(ABC_JIT_ARGS) { r6=vm_feq(r6,r6); NEXT }
ABC_JIT_CC abc_value float_feq_6_7(ABC_JIT_ARGS) { r6=vm_feq(r6,r7); NEXT }
ABC_JIT_CC abc_value float_feq_7_0(ABC_JIT_ARGS) { r7=vm_feq(r7,r0); NEXT }
ABC_JIT_CC abc_value float_feq_7_1(ABC_JIT_ARGS) { r7=vm_feq(r7,r1); NEXT }
ABC_JIT_CC abc_value float_feq_7_2(ABC_JIT_ARGS) { r7=vm_feq(r7,r2); NEXT }
ABC_JIT_CC abc_value float_feq_7_3(ABC_JIT_ARGS) { r7=vm_feq(r7,r3); NEXT }
ABC_JIT_CC abc_value float_feq_7_4(ABC_JIT_ARGS) { r7=vm_feq(r7,r4); NEXT }
ABC_JIT_CC abc_value float_feq_7_5(ABC_JIT_ARGS) { r7=vm_feq(r7,r5); NEXT }
ABC_JIT_CC abc_value float_feq_7_6(ABC_JIT_ARGS) { r7=vm_feq(r7,r6); NEXT }
ABC_JIT_CC abc_value float_feq_7_7(ABC_JIT_ARGS) { r7=vm_feq(r7,r7); NEXT }
ABC_JIT_CC abc_value float_fneg_0(ABC_JIT_ARGS) { r0^=UINT64_C(0x8000000000000000); NEXT }
ABC_JIT_CC abc_value float_fneg_1(ABC_JIT_ARGS) { r1^=UINT64_C(0x8000000000000000); NEXT }
ABC_JIT_CC abc_value float_fneg_2(ABC_JIT_ARGS) { r2^=UINT64_C(0x8000000000000000); NEXT }
ABC_JIT_CC abc_value float_fneg_3(ABC_JIT_ARGS) { r3^=UINT64_C(0x8000000000000000); NEXT }
ABC_JIT_CC abc_value float_fneg_4(ABC_JIT_ARGS) { r4^=UINT64_C(0x8000000000000000); NEXT }
ABC_JIT_CC abc_value float_fneg_5(ABC_JIT_ARGS) { r5^=UINT64_C(0x8000000000000000); NEXT }
ABC_JIT_CC abc_value float_fneg_6(ABC_JIT_ARGS) { r6^=UINT64_C(0x8000000000000000); NEXT }
ABC_JIT_CC abc_value float_fneg_7(ABC_JIT_ARGS) { r7^=UINT64_C(0x8000000000000000); NEXT }
ABC_JIT_CC abc_value float_i2fs_0(ABC_JIT_ARGS) { r0=vm_i2fs(r0); NEXT }
ABC_JIT_CC abc_value float_i2fs_1(ABC_JIT_ARGS) { r1=vm_i2fs(r1); NEXT }
ABC_JIT_CC abc_value float_i2fs_2(ABC_JIT_ARGS) { r2=vm_i2fs(r2); NEXT }
ABC_JIT_CC abc_value float_i2fs_3(ABC_JIT_ARGS) { r3=vm_i2fs(r3); NEXT }
ABC_JIT_CC abc_value float_i2fs_4(ABC_JIT_ARGS) { r4=vm_i2fs(r4); NEXT }
ABC_JIT_CC abc_value float_i2fs_5(ABC_JIT_ARGS) { r5=vm_i2fs(r5); NEXT }
ABC_JIT_CC abc_value float_i2fs_6(ABC_JIT_ARGS) { r6=vm_i2fs(r6); NEXT }
ABC_JIT_CC abc_value float_i2fs_7(ABC_JIT_ARGS) { r7=vm_i2fs(r7); NEXT }
ABC_JIT_CC abc_value float_i2fu_0(ABC_JIT_ARGS) { r0=vm_i2fu(r0); NEXT }
ABC_JIT_CC abc_value float_i2fu_1(ABC_JIT_ARGS) { r1=vm_i2fu(r1); NEXT }
ABC_JIT_CC abc_value float_i2fu_2(ABC_JIT_ARGS) { r2=vm_i2fu(r2); NEXT }
ABC_JIT_CC abc_value float_i2fu_3(ABC_JIT_ARGS) { r3=vm_i2fu(r3); NEXT }
ABC_JIT_CC abc_value float_i2fu_4(ABC_JIT_ARGS) { r4=vm_i2fu(r4); NEXT }
ABC_JIT_CC abc_value float_i2fu_5(ABC_JIT_ARGS) { r5=vm_i2fu(r5); NEXT }
ABC_JIT_CC abc_value float_i2fu_6(ABC_JIT_ARGS) { r6=vm_i2fu(r6); NEXT }
ABC_JIT_CC abc_value float_i2fu_7(ABC_JIT_ARGS) { r7=vm_i2fu(r7); NEXT }
ABC_JIT_CC abc_value float_f2is_0(ABC_JIT_ARGS) { {abc_value u=r0,e=(u>>52)&2047,s=u>>63;if(e>1086||(e==1086&&(!s||(u&UINT64_C(0x000fffffffffffff)))))return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000),v=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);r0=s?0-v:v;} NEXT }
ABC_JIT_CC abc_value float_f2is_1(ABC_JIT_ARGS) { {abc_value u=r1,e=(u>>52)&2047,s=u>>63;if(e>1086||(e==1086&&(!s||(u&UINT64_C(0x000fffffffffffff)))))return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000),v=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);r1=s?0-v:v;} NEXT }
ABC_JIT_CC abc_value float_f2is_2(ABC_JIT_ARGS) { {abc_value u=r2,e=(u>>52)&2047,s=u>>63;if(e>1086||(e==1086&&(!s||(u&UINT64_C(0x000fffffffffffff)))))return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000),v=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);r2=s?0-v:v;} NEXT }
ABC_JIT_CC abc_value float_f2is_3(ABC_JIT_ARGS) { {abc_value u=r3,e=(u>>52)&2047,s=u>>63;if(e>1086||(e==1086&&(!s||(u&UINT64_C(0x000fffffffffffff)))))return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000),v=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);r3=s?0-v:v;} NEXT }
ABC_JIT_CC abc_value float_f2is_4(ABC_JIT_ARGS) { {abc_value u=r4,e=(u>>52)&2047,s=u>>63;if(e>1086||(e==1086&&(!s||(u&UINT64_C(0x000fffffffffffff)))))return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000),v=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);r4=s?0-v:v;} NEXT }
ABC_JIT_CC abc_value float_f2is_5(ABC_JIT_ARGS) { {abc_value u=r5,e=(u>>52)&2047,s=u>>63;if(e>1086||(e==1086&&(!s||(u&UINT64_C(0x000fffffffffffff)))))return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000),v=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);r5=s?0-v:v;} NEXT }
ABC_JIT_CC abc_value float_f2is_6(ABC_JIT_ARGS) { {abc_value u=r6,e=(u>>52)&2047,s=u>>63;if(e>1086||(e==1086&&(!s||(u&UINT64_C(0x000fffffffffffff)))))return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000),v=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);r6=s?0-v:v;} NEXT }
ABC_JIT_CC abc_value float_f2is_7(ABC_JIT_ARGS) { {abc_value u=r7,e=(u>>52)&2047,s=u>>63;if(e>1086||(e==1086&&(!s||(u&UINT64_C(0x000fffffffffffff)))))return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000),v=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);r7=s?0-v:v;} NEXT }
ABC_JIT_CC abc_value float_f2iu_0(ABC_JIT_ARGS) { {abc_value u=r0,e=(u>>52)&2047;if(((u>>63)&&(u<<1))||e>=1087)return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000);r0=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);} NEXT }
ABC_JIT_CC abc_value float_f2iu_1(ABC_JIT_ARGS) { {abc_value u=r1,e=(u>>52)&2047;if(((u>>63)&&(u<<1))||e>=1087)return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000);r1=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);} NEXT }
ABC_JIT_CC abc_value float_f2iu_2(ABC_JIT_ARGS) { {abc_value u=r2,e=(u>>52)&2047;if(((u>>63)&&(u<<1))||e>=1087)return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000);r2=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);} NEXT }
ABC_JIT_CC abc_value float_f2iu_3(ABC_JIT_ARGS) { {abc_value u=r3,e=(u>>52)&2047;if(((u>>63)&&(u<<1))||e>=1087)return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000);r3=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);} NEXT }
ABC_JIT_CC abc_value float_f2iu_4(ABC_JIT_ARGS) { {abc_value u=r4,e=(u>>52)&2047;if(((u>>63)&&(u<<1))||e>=1087)return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000);r4=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);} NEXT }
ABC_JIT_CC abc_value float_f2iu_5(ABC_JIT_ARGS) { {abc_value u=r5,e=(u>>52)&2047;if(((u>>63)&&(u<<1))||e>=1087)return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000);r5=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);} NEXT }
ABC_JIT_CC abc_value float_f2iu_6(ABC_JIT_ARGS) { {abc_value u=r6,e=(u>>52)&2047;if(((u>>63)&&(u<<1))||e>=1087)return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000);r6=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);} NEXT }
ABC_JIT_CC abc_value float_f2iu_7(ABC_JIT_ARGS) { {abc_value u=r7,e=(u>>52)&2047;if(((u>>63)&&(u<<1))||e>=1087)return jit_error();int sh=(int)e-1023;abc_value m=(u&UINT64_C(0x000fffffffffffff))|UINT64_C(0x0010000000000000);r7=sh<0?0:sh<=52?m>>(52-sh):m<<(sh-52);} NEXT }
ABC_JIT_CC abc_value float_blt_0_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r0),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_0_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r0),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_0_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r0),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_0_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r0),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_0_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r0),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_0_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r0),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_0_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r0),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_0_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r0),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_1_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r1),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_1_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r1),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_1_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r1),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_1_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r1),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_1_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r1),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_1_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r1),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_1_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r1),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_1_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r1),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_2_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r2),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_2_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r2),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_2_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r2),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_2_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r2),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_2_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r2),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_2_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r2),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_2_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r2),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_2_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r2),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_3_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r3),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_3_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r3),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_3_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r3),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_3_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r3),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_3_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r3),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_3_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r3),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_3_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r3),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_3_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r3),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_4_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r4),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_4_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r4),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_4_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r4),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_4_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r4),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_4_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r4),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_4_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r4),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_4_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r4),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_4_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r4),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_5_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r5),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_5_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r5),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_5_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r5),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_5_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r5),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_5_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r5),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_5_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r5),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_5_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r5),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_5_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r5),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_6_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r6),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_6_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r6),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_6_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r6),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_6_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r6),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_6_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r6),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_6_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r6),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_6_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r6),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_6_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r6),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_7_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r7),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_7_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r7),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_7_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r7),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_7_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r7),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_7_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r7),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_7_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r7),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_7_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r7),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_blt_7_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jb HOLE_TAKEN; 1:"::"r"(r7),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_0_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r0),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_0_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r0),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_0_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r0),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_0_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r0),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_0_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r0),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_0_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r0),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_0_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r0),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_0_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r0),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_1_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r1),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_1_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r1),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_1_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r1),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_1_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r1),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_1_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r1),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_1_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r1),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_1_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r1),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_1_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r1),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_2_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r2),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_2_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r2),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_2_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r2),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_2_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r2),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_2_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r2),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_2_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r2),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_2_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r2),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_2_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r2),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_3_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r3),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_3_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r3),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_3_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r3),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_3_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r3),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_3_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r3),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_3_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r3),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_3_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r3),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_3_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r3),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_4_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r4),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_4_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r4),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_4_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r4),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_4_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r4),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_4_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r4),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_4_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r4),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_4_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r4),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_4_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r4),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_5_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r5),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_5_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r5),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_5_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r5),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_5_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r5),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_5_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r5),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_5_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r5),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_5_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r5),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_5_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r5),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_6_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r6),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_6_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r6),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_6_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r6),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_6_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r6),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_6_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r6),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_6_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r6),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_6_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r6),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_6_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r6),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_7_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r7),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_7_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r7),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_7_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r7),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_7_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r7),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_7_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r7),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_7_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r7),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_7_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r7),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_ble_7_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; jbe HOLE_TAKEN; 1:"::"r"(r7),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_0_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r0),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_0_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r0),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_0_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r0),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_0_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r0),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_0_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r0),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_0_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r0),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_0_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r0),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_0_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r0),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_1_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r1),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_1_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r1),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_1_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r1),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_1_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r1),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_1_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r1),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_1_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r1),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_1_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r1),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_1_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r1),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_2_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r2),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_2_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r2),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_2_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r2),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_2_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r2),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_2_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r2),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_2_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r2),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_2_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r2),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_2_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r2),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_3_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r3),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_3_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r3),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_3_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r3),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_3_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r3),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_3_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r3),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_3_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r3),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_3_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r3),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_3_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r3),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_4_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r4),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_4_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r4),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_4_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r4),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_4_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r4),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_4_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r4),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_4_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r4),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_4_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r4),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_4_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r4),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_5_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r5),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_5_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r5),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_5_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r5),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_5_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r5),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_5_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r5),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_5_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r5),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_5_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r5),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_5_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r5),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_6_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r6),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_6_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r6),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_6_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r6),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_6_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r6),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_6_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r6),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_6_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r6),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_6_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r6),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_6_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r6),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_7_0(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r7),"r"(r0):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_7_1(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r7),"r"(r1):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_7_2(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r7),"r"(r2):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_7_3(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r7),"r"(r3):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_7_4(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r7),"r"(r4):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_7_5(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r7),"r"(r5):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_7_6(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r7),"r"(r6):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value float_beq_7_7(ABC_JIT_ARGS) { __asm__("movq %0,%%xmm0; movq %1,%%xmm1; ucomisd %%xmm1,%%xmm0; jp 1f; je HOLE_TAKEN; 1:"::"r"(r7),"r"(r7):"xmm0","xmm1","cc"); __builtin_unreachable(); }
ABC_JIT_CC abc_value mem_load_u8_0(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%0),%0":"+r"(r0)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u8_1(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%0),%0":"+r"(r1)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u8_2(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%0),%0":"+r"(r2)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u8_3(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%0),%0":"+r"(r3)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u8_4(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%0),%0":"+r"(r4)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u8_5(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%0),%0":"+r"(r5)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u8_6(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%0),%0":"+r"(r6)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u8_7(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%0),%0":"+r"(r7)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u16_0(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%0),%0":"+r"(r0)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u16_1(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%0),%0":"+r"(r1)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u16_2(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%0),%0":"+r"(r2)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u16_3(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%0),%0":"+r"(r3)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u16_4(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%0),%0":"+r"(r4)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u16_5(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%0),%0":"+r"(r5)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u16_6(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%0),%0":"+r"(r6)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u16_7(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%0),%0":"+r"(r7)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u32_0(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%0),%k0":"+r"(r0)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u32_1(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%0),%k0":"+r"(r1)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u32_2(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%0),%k0":"+r"(r2)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u32_3(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%0),%k0":"+r"(r3)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u32_4(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%0),%k0":"+r"(r4)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u32_5(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%0),%k0":"+r"(r5)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u32_6(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%0),%k0":"+r"(r6)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u32_7(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%0),%k0":"+r"(r7)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_s32_0(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%0),%0":"+r"(r0)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_s32_1(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%0),%0":"+r"(r1)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_s32_2(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%0),%0":"+r"(r2)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_s32_3(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%0),%0":"+r"(r3)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_s32_4(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%0),%0":"+r"(r4)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_s32_5(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%0),%0":"+r"(r5)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_s32_6(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%0),%0":"+r"(r6)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_s32_7(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%0),%0":"+r"(r7)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u64_0(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%0),%0":"+r"(r0)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u64_1(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%0),%0":"+r"(r1)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u64_2(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%0),%0":"+r"(r2)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u64_3(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%0),%0":"+r"(r3)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u64_4(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%0),%0":"+r"(r4)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u64_5(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%0),%0":"+r"(r5)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u64_6(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%0),%0":"+r"(r6)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_load_u64_7(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%0),%0":"+r"(r7)::"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_0_0(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r0),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_0_1(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r0),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_0_2(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r0),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_0_3(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r0),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_0_4(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r0),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_0_5(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r0),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_0_6(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r0),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_0_7(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r0),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_1_0(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r1),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_1_1(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r1),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_1_2(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r1),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_1_3(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r1),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_1_4(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r1),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_1_5(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r1),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_1_6(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r1),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_1_7(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r1),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_2_0(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r2),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_2_1(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r2),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_2_2(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r2),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_2_3(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r2),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_2_4(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r2),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_2_5(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r2),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_2_6(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r2),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_2_7(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r2),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_3_0(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r3),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_3_1(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r3),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_3_2(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r3),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_3_3(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r3),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_3_4(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r3),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_3_5(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r3),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_3_6(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r3),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_3_7(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r3),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_4_0(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r4),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_4_1(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r4),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_4_2(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r4),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_4_3(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r4),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_4_4(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r4),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_4_5(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r4),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_4_6(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r4),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_4_7(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r4),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_5_0(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r5),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_5_1(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r5),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_5_2(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r5),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_5_3(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r5),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_5_4(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r5),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_5_5(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r5),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_5_6(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r5),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_5_7(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r5),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_6_0(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r6),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_6_1(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r6),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_6_2(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r6),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_6_3(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r6),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_6_4(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r6),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_6_5(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r6),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_6_6(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r6),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_6_7(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r6),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_7_0(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r7),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_7_1(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r7),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_7_2(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r7),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_7_3(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r7),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_7_4(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r7),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_7_5(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r7),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_7_6(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r7),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u8_7_7(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(r7),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_0_0(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r0),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_0_1(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r0),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_0_2(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r0),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_0_3(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r0),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_0_4(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r0),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_0_5(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r0),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_0_6(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r0),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_0_7(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r0),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_1_0(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r1),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_1_1(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r1),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_1_2(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r1),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_1_3(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r1),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_1_4(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r1),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_1_5(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r1),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_1_6(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r1),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_1_7(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r1),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_2_0(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r2),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_2_1(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r2),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_2_2(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r2),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_2_3(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r2),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_2_4(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r2),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_2_5(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r2),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_2_6(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r2),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_2_7(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r2),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_3_0(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r3),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_3_1(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r3),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_3_2(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r3),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_3_3(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r3),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_3_4(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r3),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_3_5(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r3),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_3_6(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r3),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_3_7(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r3),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_4_0(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r4),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_4_1(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r4),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_4_2(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r4),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_4_3(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r4),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_4_4(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r4),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_4_5(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r4),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_4_6(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r4),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_4_7(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r4),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_5_0(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r5),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_5_1(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r5),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_5_2(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r5),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_5_3(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r5),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_5_4(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r5),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_5_5(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r5),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_5_6(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r5),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_5_7(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r5),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_6_0(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r6),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_6_1(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r6),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_6_2(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r6),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_6_3(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r6),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_6_4(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r6),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_6_5(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r6),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_6_6(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r6),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_6_7(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r6),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_7_0(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r7),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_7_1(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r7),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_7_2(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r7),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_7_3(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r7),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_7_4(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r7),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_7_5(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r7),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_7_6(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r7),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u16_7_7(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(r7),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_0_0(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r0),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_0_1(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r0),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_0_2(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r0),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_0_3(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r0),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_0_4(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r0),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_0_5(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r0),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_0_6(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r0),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_0_7(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r0),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_1_0(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r1),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_1_1(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r1),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_1_2(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r1),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_1_3(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r1),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_1_4(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r1),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_1_5(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r1),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_1_6(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r1),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_1_7(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r1),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_2_0(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r2),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_2_1(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r2),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_2_2(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r2),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_2_3(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r2),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_2_4(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r2),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_2_5(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r2),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_2_6(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r2),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_2_7(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r2),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_3_0(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r3),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_3_1(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r3),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_3_2(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r3),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_3_3(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r3),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_3_4(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r3),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_3_5(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r3),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_3_6(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r3),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_3_7(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r3),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_4_0(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r4),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_4_1(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r4),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_4_2(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r4),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_4_3(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r4),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_4_4(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r4),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_4_5(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r4),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_4_6(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r4),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_4_7(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r4),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_5_0(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r5),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_5_1(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r5),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_5_2(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r5),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_5_3(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r5),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_5_4(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r5),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_5_5(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r5),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_5_6(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r5),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_5_7(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r5),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_6_0(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r6),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_6_1(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r6),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_6_2(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r6),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_6_3(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r6),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_6_4(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r6),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_6_5(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r6),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_6_6(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r6),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_6_7(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r6),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_7_0(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r7),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_7_1(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r7),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_7_2(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r7),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_7_3(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r7),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_7_4(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r7),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_7_5(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r7),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_7_6(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r7),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u32_7_7(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(r7),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_0_0(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r0),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_0_1(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r0),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_0_2(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r0),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_0_3(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r0),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_0_4(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r0),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_0_5(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r0),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_0_6(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r0),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_0_7(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r0),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_1_0(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r1),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_1_1(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r1),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_1_2(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r1),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_1_3(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r1),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_1_4(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r1),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_1_5(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r1),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_1_6(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r1),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_1_7(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r1),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_2_0(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r2),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_2_1(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r2),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_2_2(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r2),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_2_3(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r2),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_2_4(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r2),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_2_5(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r2),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_2_6(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r2),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_2_7(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r2),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_3_0(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r3),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_3_1(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r3),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_3_2(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r3),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_3_3(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r3),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_3_4(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r3),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_3_5(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r3),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_3_6(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r3),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_3_7(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r3),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_4_0(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r4),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_4_1(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r4),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_4_2(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r4),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_4_3(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r4),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_4_4(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r4),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_4_5(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r4),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_4_6(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r4),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_4_7(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r4),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_5_0(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r5),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_5_1(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r5),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_5_2(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r5),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_5_3(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r5),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_5_4(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r5),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_5_5(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r5),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_5_6(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r5),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_5_7(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r5),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_6_0(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r6),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_6_1(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r6),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_6_2(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r6),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_6_3(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r6),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_6_4(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r6),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_6_5(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r6),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_6_6(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r6),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_6_7(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r6),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_7_0(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r7),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_7_1(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r7),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_7_2(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r7),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_7_3(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r7),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_7_4(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r7),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_7_5(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r7),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_7_6(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r7),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value mem_store_u64_7_7(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(r7),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value index_0_0(ABC_JIT_ARGS) { r0+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r0; NEXT }
ABC_JIT_CC abc_value index_0_1(ABC_JIT_ARGS) { r0+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r1; NEXT }
ABC_JIT_CC abc_value index_0_2(ABC_JIT_ARGS) { r0+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r2; NEXT }
ABC_JIT_CC abc_value index_0_3(ABC_JIT_ARGS) { r0+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r3; NEXT }
ABC_JIT_CC abc_value index_0_4(ABC_JIT_ARGS) { r0+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r4; NEXT }
ABC_JIT_CC abc_value index_0_5(ABC_JIT_ARGS) { r0+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r5; NEXT }
ABC_JIT_CC abc_value index_0_6(ABC_JIT_ARGS) { r0+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r6; NEXT }
ABC_JIT_CC abc_value index_0_7(ABC_JIT_ARGS) { r0+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r7; NEXT }
ABC_JIT_CC abc_value index_1_0(ABC_JIT_ARGS) { r1+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r0; NEXT }
ABC_JIT_CC abc_value index_1_1(ABC_JIT_ARGS) { r1+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r1; NEXT }
ABC_JIT_CC abc_value index_1_2(ABC_JIT_ARGS) { r1+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r2; NEXT }
ABC_JIT_CC abc_value index_1_3(ABC_JIT_ARGS) { r1+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r3; NEXT }
ABC_JIT_CC abc_value index_1_4(ABC_JIT_ARGS) { r1+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r4; NEXT }
ABC_JIT_CC abc_value index_1_5(ABC_JIT_ARGS) { r1+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r5; NEXT }
ABC_JIT_CC abc_value index_1_6(ABC_JIT_ARGS) { r1+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r6; NEXT }
ABC_JIT_CC abc_value index_1_7(ABC_JIT_ARGS) { r1+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r7; NEXT }
ABC_JIT_CC abc_value index_2_0(ABC_JIT_ARGS) { r2+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r0; NEXT }
ABC_JIT_CC abc_value index_2_1(ABC_JIT_ARGS) { r2+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r1; NEXT }
ABC_JIT_CC abc_value index_2_2(ABC_JIT_ARGS) { r2+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r2; NEXT }
ABC_JIT_CC abc_value index_2_3(ABC_JIT_ARGS) { r2+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r3; NEXT }
ABC_JIT_CC abc_value index_2_4(ABC_JIT_ARGS) { r2+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r4; NEXT }
ABC_JIT_CC abc_value index_2_5(ABC_JIT_ARGS) { r2+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r5; NEXT }
ABC_JIT_CC abc_value index_2_6(ABC_JIT_ARGS) { r2+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r6; NEXT }
ABC_JIT_CC abc_value index_2_7(ABC_JIT_ARGS) { r2+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r7; NEXT }
ABC_JIT_CC abc_value index_3_0(ABC_JIT_ARGS) { r3+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r0; NEXT }
ABC_JIT_CC abc_value index_3_1(ABC_JIT_ARGS) { r3+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r1; NEXT }
ABC_JIT_CC abc_value index_3_2(ABC_JIT_ARGS) { r3+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r2; NEXT }
ABC_JIT_CC abc_value index_3_3(ABC_JIT_ARGS) { r3+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r3; NEXT }
ABC_JIT_CC abc_value index_3_4(ABC_JIT_ARGS) { r3+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r4; NEXT }
ABC_JIT_CC abc_value index_3_5(ABC_JIT_ARGS) { r3+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r5; NEXT }
ABC_JIT_CC abc_value index_3_6(ABC_JIT_ARGS) { r3+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r6; NEXT }
ABC_JIT_CC abc_value index_3_7(ABC_JIT_ARGS) { r3+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r7; NEXT }
ABC_JIT_CC abc_value index_4_0(ABC_JIT_ARGS) { r4+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r0; NEXT }
ABC_JIT_CC abc_value index_4_1(ABC_JIT_ARGS) { r4+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r1; NEXT }
ABC_JIT_CC abc_value index_4_2(ABC_JIT_ARGS) { r4+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r2; NEXT }
ABC_JIT_CC abc_value index_4_3(ABC_JIT_ARGS) { r4+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r3; NEXT }
ABC_JIT_CC abc_value index_4_4(ABC_JIT_ARGS) { r4+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r4; NEXT }
ABC_JIT_CC abc_value index_4_5(ABC_JIT_ARGS) { r4+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r5; NEXT }
ABC_JIT_CC abc_value index_4_6(ABC_JIT_ARGS) { r4+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r6; NEXT }
ABC_JIT_CC abc_value index_4_7(ABC_JIT_ARGS) { r4+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r7; NEXT }
ABC_JIT_CC abc_value index_5_0(ABC_JIT_ARGS) { r5+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r0; NEXT }
ABC_JIT_CC abc_value index_5_1(ABC_JIT_ARGS) { r5+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r1; NEXT }
ABC_JIT_CC abc_value index_5_2(ABC_JIT_ARGS) { r5+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r2; NEXT }
ABC_JIT_CC abc_value index_5_3(ABC_JIT_ARGS) { r5+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r3; NEXT }
ABC_JIT_CC abc_value index_5_4(ABC_JIT_ARGS) { r5+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r4; NEXT }
ABC_JIT_CC abc_value index_5_5(ABC_JIT_ARGS) { r5+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r5; NEXT }
ABC_JIT_CC abc_value index_5_6(ABC_JIT_ARGS) { r5+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r6; NEXT }
ABC_JIT_CC abc_value index_5_7(ABC_JIT_ARGS) { r5+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r7; NEXT }
ABC_JIT_CC abc_value index_6_0(ABC_JIT_ARGS) { r6+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r0; NEXT }
ABC_JIT_CC abc_value index_6_1(ABC_JIT_ARGS) { r6+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r1; NEXT }
ABC_JIT_CC abc_value index_6_2(ABC_JIT_ARGS) { r6+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r2; NEXT }
ABC_JIT_CC abc_value index_6_3(ABC_JIT_ARGS) { r6+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r3; NEXT }
ABC_JIT_CC abc_value index_6_4(ABC_JIT_ARGS) { r6+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r4; NEXT }
ABC_JIT_CC abc_value index_6_5(ABC_JIT_ARGS) { r6+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r5; NEXT }
ABC_JIT_CC abc_value index_6_6(ABC_JIT_ARGS) { r6+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r6; NEXT }
ABC_JIT_CC abc_value index_6_7(ABC_JIT_ARGS) { r6+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r7; NEXT }
ABC_JIT_CC abc_value index_7_0(ABC_JIT_ARGS) { r7+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r0; NEXT }
ABC_JIT_CC abc_value index_7_1(ABC_JIT_ARGS) { r7+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r1; NEXT }
ABC_JIT_CC abc_value index_7_2(ABC_JIT_ARGS) { r7+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r2; NEXT }
ABC_JIT_CC abc_value index_7_3(ABC_JIT_ARGS) { r7+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r3; NEXT }
ABC_JIT_CC abc_value index_7_4(ABC_JIT_ARGS) { r7+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r4; NEXT }
ABC_JIT_CC abc_value index_7_5(ABC_JIT_ARGS) { r7+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r5; NEXT }
ABC_JIT_CC abc_value index_7_6(ABC_JIT_ARGS) { r7+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r6; NEXT }
ABC_JIT_CC abc_value index_7_7(ABC_JIT_ARGS) { r7+=(abc_value)((int32_t)(intptr_t)HOLE_IMM)*r7; NEXT }
ABC_JIT_CC abc_value memcpy_0_0(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r0,(const void *)(uintptr_t)r0,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_0_1(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r0,(const void *)(uintptr_t)r1,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_0_2(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r0,(const void *)(uintptr_t)r2,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_0_3(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r0,(const void *)(uintptr_t)r3,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_0_4(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r0,(const void *)(uintptr_t)r4,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_0_5(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r0,(const void *)(uintptr_t)r5,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_0_6(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r0,(const void *)(uintptr_t)r6,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_0_7(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r0,(const void *)(uintptr_t)r7,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_1_0(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r1,(const void *)(uintptr_t)r0,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_1_1(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r1,(const void *)(uintptr_t)r1,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_1_2(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r1,(const void *)(uintptr_t)r2,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_1_3(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r1,(const void *)(uintptr_t)r3,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_1_4(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r1,(const void *)(uintptr_t)r4,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_1_5(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r1,(const void *)(uintptr_t)r5,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_1_6(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r1,(const void *)(uintptr_t)r6,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_1_7(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r1,(const void *)(uintptr_t)r7,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_2_0(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r2,(const void *)(uintptr_t)r0,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_2_1(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r2,(const void *)(uintptr_t)r1,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_2_2(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r2,(const void *)(uintptr_t)r2,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_2_3(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r2,(const void *)(uintptr_t)r3,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_2_4(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r2,(const void *)(uintptr_t)r4,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_2_5(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r2,(const void *)(uintptr_t)r5,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_2_6(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r2,(const void *)(uintptr_t)r6,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_2_7(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r2,(const void *)(uintptr_t)r7,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_3_0(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r3,(const void *)(uintptr_t)r0,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_3_1(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r3,(const void *)(uintptr_t)r1,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_3_2(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r3,(const void *)(uintptr_t)r2,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_3_3(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r3,(const void *)(uintptr_t)r3,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_3_4(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r3,(const void *)(uintptr_t)r4,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_3_5(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r3,(const void *)(uintptr_t)r5,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_3_6(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r3,(const void *)(uintptr_t)r6,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_3_7(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r3,(const void *)(uintptr_t)r7,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_4_0(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r4,(const void *)(uintptr_t)r0,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_4_1(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r4,(const void *)(uintptr_t)r1,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_4_2(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r4,(const void *)(uintptr_t)r2,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_4_3(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r4,(const void *)(uintptr_t)r3,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_4_4(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r4,(const void *)(uintptr_t)r4,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_4_5(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r4,(const void *)(uintptr_t)r5,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_4_6(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r4,(const void *)(uintptr_t)r6,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_4_7(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r4,(const void *)(uintptr_t)r7,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_5_0(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r5,(const void *)(uintptr_t)r0,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_5_1(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r5,(const void *)(uintptr_t)r1,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_5_2(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r5,(const void *)(uintptr_t)r2,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_5_3(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r5,(const void *)(uintptr_t)r3,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_5_4(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r5,(const void *)(uintptr_t)r4,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_5_5(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r5,(const void *)(uintptr_t)r5,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_5_6(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r5,(const void *)(uintptr_t)r6,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_5_7(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r5,(const void *)(uintptr_t)r7,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_6_0(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r6,(const void *)(uintptr_t)r0,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_6_1(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r6,(const void *)(uintptr_t)r1,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_6_2(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r6,(const void *)(uintptr_t)r2,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_6_3(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r6,(const void *)(uintptr_t)r3,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_6_4(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r6,(const void *)(uintptr_t)r4,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_6_5(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r6,(const void *)(uintptr_t)r5,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_6_6(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r6,(const void *)(uintptr_t)r6,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_6_7(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r6,(const void *)(uintptr_t)r7,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_7_0(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r7,(const void *)(uintptr_t)r0,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_7_1(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r7,(const void *)(uintptr_t)r1,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_7_2(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r7,(const void *)(uintptr_t)r2,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_7_3(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r7,(const void *)(uintptr_t)r3,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_7_4(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r7,(const void *)(uintptr_t)r4,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_7_5(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r7,(const void *)(uintptr_t)r5,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_7_6(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r7,(const void *)(uintptr_t)r6,n);}} NEXT }
ABC_JIT_CC abc_value memcpy_7_7(ABC_JIT_ARGS) { {size_t n=(uint32_t)(uintptr_t)HOLE_IMM;if(n){abc_value copy;__asm__("movabsq $HOLE_FINAL,%0":"=r"(copy));((abc_memory_copy_fn)(uintptr_t)copy)((void *)(uintptr_t)r7,(const void *)(uintptr_t)r7,n);}} NEXT }
ABC_JIT_CC abc_value calloc(ABC_JIT_ARGS) { {uint64_t*d=csp+(int32_t)(intptr_t)HOLE_IMM2;size_t n=(uint32_t)(uintptr_t)HOLE_IMM;while(n--)*d++=0;} NEXT }
ABC_JIT_CC abc_value frame_load_u8_0(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%1),%0":"=r"(r0):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u8_1(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%1),%0":"=r"(r1):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u8_2(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%1),%0":"=r"(r2):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u8_3(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%1),%0":"=r"(r3):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u8_4(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%1),%0":"=r"(r4):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u8_5(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%1),%0":"=r"(r5):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u8_6(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%1),%0":"=r"(r6):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u8_7(ABC_JIT_ARGS) { __asm__("movzbq HOLE_IMM(%1),%0":"=r"(r7):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u16_0(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%1),%0":"=r"(r0):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u16_1(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%1),%0":"=r"(r1):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u16_2(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%1),%0":"=r"(r2):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u16_3(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%1),%0":"=r"(r3):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u16_4(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%1),%0":"=r"(r4):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u16_5(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%1),%0":"=r"(r5):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u16_6(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%1),%0":"=r"(r6):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u16_7(ABC_JIT_ARGS) { __asm__("movzwq HOLE_IMM(%1),%0":"=r"(r7):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u32_0(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%1),%k0":"=r"(r0):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u32_1(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%1),%k0":"=r"(r1):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u32_2(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%1),%k0":"=r"(r2):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u32_3(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%1),%k0":"=r"(r3):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u32_4(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%1),%k0":"=r"(r4):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u32_5(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%1),%k0":"=r"(r5):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u32_6(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%1),%k0":"=r"(r6):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u32_7(ABC_JIT_ARGS) { __asm__("movl HOLE_IMM(%1),%k0":"=r"(r7):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_s32_0(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%1),%0":"=r"(r0):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_s32_1(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%1),%0":"=r"(r1):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_s32_2(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%1),%0":"=r"(r2):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_s32_3(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%1),%0":"=r"(r3):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_s32_4(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%1),%0":"=r"(r4):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_s32_5(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%1),%0":"=r"(r5):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_s32_6(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%1),%0":"=r"(r6):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_s32_7(ABC_JIT_ARGS) { __asm__("movslq HOLE_IMM(%1),%0":"=r"(r7):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u64_0(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r0):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u64_1(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r1):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u64_2(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r2):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u64_3(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r3):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u64_4(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r4):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u64_5(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r5):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u64_6(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r6):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_load_u64_7(ABC_JIT_ARGS) { __asm__("movq HOLE_IMM(%1),%0":"=r"(r7):"r"(csp):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u8_0(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(csp),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u8_1(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(csp),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u8_2(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(csp),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u8_3(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(csp),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u8_4(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(csp),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u8_5(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(csp),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u8_6(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(csp),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u8_7(ABC_JIT_ARGS) { __asm__("movb %b1,HOLE_IMM(%0)"::"r"(csp),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u16_0(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(csp),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u16_1(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(csp),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u16_2(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(csp),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u16_3(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(csp),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u16_4(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(csp),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u16_5(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(csp),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u16_6(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(csp),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u16_7(ABC_JIT_ARGS) { __asm__("movw %w1,HOLE_IMM(%0)"::"r"(csp),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u32_0(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(csp),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u32_1(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(csp),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u32_2(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(csp),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u32_3(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(csp),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u32_4(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(csp),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u32_5(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(csp),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u32_6(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(csp),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u32_7(ABC_JIT_ARGS) { __asm__("movl %k1,HOLE_IMM(%0)"::"r"(csp),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u64_0(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r0):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u64_1(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r1):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u64_2(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r2):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u64_3(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r3):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u64_4(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r4):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u64_5(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r5):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u64_6(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r6):"memory"); NEXT }
ABC_JIT_CC abc_value frame_store_u64_7(ABC_JIT_ARGS) { __asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(r7):"memory"); NEXT }
ABC_JIT_CC abc_value frame_addr_0(ABC_JIT_ARGS) { __asm__("leaq HOLE_IMM(%1),%0":"=r"(r0):"r"(csp)); NEXT }
ABC_JIT_CC abc_value frame_addr_1(ABC_JIT_ARGS) { __asm__("leaq HOLE_IMM(%1),%0":"=r"(r1):"r"(csp)); NEXT }
ABC_JIT_CC abc_value frame_addr_2(ABC_JIT_ARGS) { __asm__("leaq HOLE_IMM(%1),%0":"=r"(r2):"r"(csp)); NEXT }
ABC_JIT_CC abc_value frame_addr_3(ABC_JIT_ARGS) { __asm__("leaq HOLE_IMM(%1),%0":"=r"(r3):"r"(csp)); NEXT }
ABC_JIT_CC abc_value frame_addr_4(ABC_JIT_ARGS) { __asm__("leaq HOLE_IMM(%1),%0":"=r"(r4):"r"(csp)); NEXT }
ABC_JIT_CC abc_value frame_addr_5(ABC_JIT_ARGS) { __asm__("leaq HOLE_IMM(%1),%0":"=r"(r5):"r"(csp)); NEXT }
ABC_JIT_CC abc_value frame_addr_6(ABC_JIT_ARGS) { __asm__("leaq HOLE_IMM(%1),%0":"=r"(r6):"r"(csp)); NEXT }
ABC_JIT_CC abc_value frame_addr_7(ABC_JIT_ARGS) { __asm__("leaq HOLE_IMM(%1),%0":"=r"(r7):"r"(csp)); NEXT }
ABC_JIT_CC abc_value global_load_u8_0(ABC_JIT_ARGS) { r0=(abc_value)*(uint8_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u8_1(ABC_JIT_ARGS) { r1=(abc_value)*(uint8_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u8_2(ABC_JIT_ARGS) { r2=(abc_value)*(uint8_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u8_3(ABC_JIT_ARGS) { r3=(abc_value)*(uint8_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u8_4(ABC_JIT_ARGS) { r4=(abc_value)*(uint8_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u8_5(ABC_JIT_ARGS) { r5=(abc_value)*(uint8_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u8_6(ABC_JIT_ARGS) { r6=(abc_value)*(uint8_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u8_7(ABC_JIT_ARGS) { r7=(abc_value)*(uint8_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u16_0(ABC_JIT_ARGS) { r0=(abc_value)*(uint16_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u16_1(ABC_JIT_ARGS) { r1=(abc_value)*(uint16_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u16_2(ABC_JIT_ARGS) { r2=(abc_value)*(uint16_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u16_3(ABC_JIT_ARGS) { r3=(abc_value)*(uint16_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u16_4(ABC_JIT_ARGS) { r4=(abc_value)*(uint16_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u16_5(ABC_JIT_ARGS) { r5=(abc_value)*(uint16_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u16_6(ABC_JIT_ARGS) { r6=(abc_value)*(uint16_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u16_7(ABC_JIT_ARGS) { r7=(abc_value)*(uint16_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u32_0(ABC_JIT_ARGS) { r0=(abc_value)*(uint32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u32_1(ABC_JIT_ARGS) { r1=(abc_value)*(uint32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u32_2(ABC_JIT_ARGS) { r2=(abc_value)*(uint32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u32_3(ABC_JIT_ARGS) { r3=(abc_value)*(uint32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u32_4(ABC_JIT_ARGS) { r4=(abc_value)*(uint32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u32_5(ABC_JIT_ARGS) { r5=(abc_value)*(uint32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u32_6(ABC_JIT_ARGS) { r6=(abc_value)*(uint32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u32_7(ABC_JIT_ARGS) { r7=(abc_value)*(uint32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_s32_0(ABC_JIT_ARGS) { r0=(abc_value)*(int32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_s32_1(ABC_JIT_ARGS) { r1=(abc_value)*(int32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_s32_2(ABC_JIT_ARGS) { r2=(abc_value)*(int32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_s32_3(ABC_JIT_ARGS) { r3=(abc_value)*(int32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_s32_4(ABC_JIT_ARGS) { r4=(abc_value)*(int32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_s32_5(ABC_JIT_ARGS) { r5=(abc_value)*(int32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_s32_6(ABC_JIT_ARGS) { r6=(abc_value)*(int32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_s32_7(ABC_JIT_ARGS) { r7=(abc_value)*(int32_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u64_0(ABC_JIT_ARGS) { r0=(abc_value)*(uint64_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u64_1(ABC_JIT_ARGS) { r1=(abc_value)*(uint64_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u64_2(ABC_JIT_ARGS) { r2=(abc_value)*(uint64_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u64_3(ABC_JIT_ARGS) { r3=(abc_value)*(uint64_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u64_4(ABC_JIT_ARGS) { r4=(abc_value)*(uint64_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u64_5(ABC_JIT_ARGS) { r5=(abc_value)*(uint64_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u64_6(ABC_JIT_ARGS) { r6=(abc_value)*(uint64_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_load_u64_7(ABC_JIT_ARGS) { r7=(abc_value)*(uint64_t *)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_store_u8_0(ABC_JIT_ARGS) { *(uint8_t *)(uintptr_t)HOLE_FINAL=(uint8_t)r0; NEXT }
ABC_JIT_CC abc_value global_store_u8_1(ABC_JIT_ARGS) { *(uint8_t *)(uintptr_t)HOLE_FINAL=(uint8_t)r1; NEXT }
ABC_JIT_CC abc_value global_store_u8_2(ABC_JIT_ARGS) { *(uint8_t *)(uintptr_t)HOLE_FINAL=(uint8_t)r2; NEXT }
ABC_JIT_CC abc_value global_store_u8_3(ABC_JIT_ARGS) { *(uint8_t *)(uintptr_t)HOLE_FINAL=(uint8_t)r3; NEXT }
ABC_JIT_CC abc_value global_store_u8_4(ABC_JIT_ARGS) { *(uint8_t *)(uintptr_t)HOLE_FINAL=(uint8_t)r4; NEXT }
ABC_JIT_CC abc_value global_store_u8_5(ABC_JIT_ARGS) { *(uint8_t *)(uintptr_t)HOLE_FINAL=(uint8_t)r5; NEXT }
ABC_JIT_CC abc_value global_store_u8_6(ABC_JIT_ARGS) { *(uint8_t *)(uintptr_t)HOLE_FINAL=(uint8_t)r6; NEXT }
ABC_JIT_CC abc_value global_store_u8_7(ABC_JIT_ARGS) { *(uint8_t *)(uintptr_t)HOLE_FINAL=(uint8_t)r7; NEXT }
ABC_JIT_CC abc_value global_store_u16_0(ABC_JIT_ARGS) { *(uint16_t *)(uintptr_t)HOLE_FINAL=(uint16_t)r0; NEXT }
ABC_JIT_CC abc_value global_store_u16_1(ABC_JIT_ARGS) { *(uint16_t *)(uintptr_t)HOLE_FINAL=(uint16_t)r1; NEXT }
ABC_JIT_CC abc_value global_store_u16_2(ABC_JIT_ARGS) { *(uint16_t *)(uintptr_t)HOLE_FINAL=(uint16_t)r2; NEXT }
ABC_JIT_CC abc_value global_store_u16_3(ABC_JIT_ARGS) { *(uint16_t *)(uintptr_t)HOLE_FINAL=(uint16_t)r3; NEXT }
ABC_JIT_CC abc_value global_store_u16_4(ABC_JIT_ARGS) { *(uint16_t *)(uintptr_t)HOLE_FINAL=(uint16_t)r4; NEXT }
ABC_JIT_CC abc_value global_store_u16_5(ABC_JIT_ARGS) { *(uint16_t *)(uintptr_t)HOLE_FINAL=(uint16_t)r5; NEXT }
ABC_JIT_CC abc_value global_store_u16_6(ABC_JIT_ARGS) { *(uint16_t *)(uintptr_t)HOLE_FINAL=(uint16_t)r6; NEXT }
ABC_JIT_CC abc_value global_store_u16_7(ABC_JIT_ARGS) { *(uint16_t *)(uintptr_t)HOLE_FINAL=(uint16_t)r7; NEXT }
ABC_JIT_CC abc_value global_store_u32_0(ABC_JIT_ARGS) { *(uint32_t *)(uintptr_t)HOLE_FINAL=(uint32_t)r0; NEXT }
ABC_JIT_CC abc_value global_store_u32_1(ABC_JIT_ARGS) { *(uint32_t *)(uintptr_t)HOLE_FINAL=(uint32_t)r1; NEXT }
ABC_JIT_CC abc_value global_store_u32_2(ABC_JIT_ARGS) { *(uint32_t *)(uintptr_t)HOLE_FINAL=(uint32_t)r2; NEXT }
ABC_JIT_CC abc_value global_store_u32_3(ABC_JIT_ARGS) { *(uint32_t *)(uintptr_t)HOLE_FINAL=(uint32_t)r3; NEXT }
ABC_JIT_CC abc_value global_store_u32_4(ABC_JIT_ARGS) { *(uint32_t *)(uintptr_t)HOLE_FINAL=(uint32_t)r4; NEXT }
ABC_JIT_CC abc_value global_store_u32_5(ABC_JIT_ARGS) { *(uint32_t *)(uintptr_t)HOLE_FINAL=(uint32_t)r5; NEXT }
ABC_JIT_CC abc_value global_store_u32_6(ABC_JIT_ARGS) { *(uint32_t *)(uintptr_t)HOLE_FINAL=(uint32_t)r6; NEXT }
ABC_JIT_CC abc_value global_store_u32_7(ABC_JIT_ARGS) { *(uint32_t *)(uintptr_t)HOLE_FINAL=(uint32_t)r7; NEXT }
ABC_JIT_CC abc_value global_store_u64_0(ABC_JIT_ARGS) { *(uint64_t *)(uintptr_t)HOLE_FINAL=(uint64_t)r0; NEXT }
ABC_JIT_CC abc_value global_store_u64_1(ABC_JIT_ARGS) { *(uint64_t *)(uintptr_t)HOLE_FINAL=(uint64_t)r1; NEXT }
ABC_JIT_CC abc_value global_store_u64_2(ABC_JIT_ARGS) { *(uint64_t *)(uintptr_t)HOLE_FINAL=(uint64_t)r2; NEXT }
ABC_JIT_CC abc_value global_store_u64_3(ABC_JIT_ARGS) { *(uint64_t *)(uintptr_t)HOLE_FINAL=(uint64_t)r3; NEXT }
ABC_JIT_CC abc_value global_store_u64_4(ABC_JIT_ARGS) { *(uint64_t *)(uintptr_t)HOLE_FINAL=(uint64_t)r4; NEXT }
ABC_JIT_CC abc_value global_store_u64_5(ABC_JIT_ARGS) { *(uint64_t *)(uintptr_t)HOLE_FINAL=(uint64_t)r5; NEXT }
ABC_JIT_CC abc_value global_store_u64_6(ABC_JIT_ARGS) { *(uint64_t *)(uintptr_t)HOLE_FINAL=(uint64_t)r6; NEXT }
ABC_JIT_CC abc_value global_store_u64_7(ABC_JIT_ARGS) { *(uint64_t *)(uintptr_t)HOLE_FINAL=(uint64_t)r7; NEXT }
ABC_JIT_CC abc_value global_addr_0(ABC_JIT_ARGS) { r0=(abc_value)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_addr_1(ABC_JIT_ARGS) { r1=(abc_value)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_addr_2(ABC_JIT_ARGS) { r2=(abc_value)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_addr_3(ABC_JIT_ARGS) { r3=(abc_value)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_addr_4(ABC_JIT_ARGS) { r4=(abc_value)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_addr_5(ABC_JIT_ARGS) { r5=(abc_value)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_addr_6(ABC_JIT_ARGS) { r6=(abc_value)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value global_addr_7(ABC_JIT_ARGS) { r7=(abc_value)(uintptr_t)HOLE_FINAL; NEXT }
ABC_JIT_CC abc_value pow_0_0(ABC_JIT_ARGS) { r0=jit_pow(r0,r0); NEXT }
ABC_JIT_CC abc_value pow_0_1(ABC_JIT_ARGS) { r0=jit_pow(r0,r1); NEXT }
ABC_JIT_CC abc_value pow_0_2(ABC_JIT_ARGS) { r0=jit_pow(r0,r2); NEXT }
ABC_JIT_CC abc_value pow_0_3(ABC_JIT_ARGS) { r0=jit_pow(r0,r3); NEXT }
ABC_JIT_CC abc_value pow_0_4(ABC_JIT_ARGS) { r0=jit_pow(r0,r4); NEXT }
ABC_JIT_CC abc_value pow_0_5(ABC_JIT_ARGS) { r0=jit_pow(r0,r5); NEXT }
ABC_JIT_CC abc_value pow_0_6(ABC_JIT_ARGS) { r0=jit_pow(r0,r6); NEXT }
ABC_JIT_CC abc_value pow_0_7(ABC_JIT_ARGS) { r0=jit_pow(r0,r7); NEXT }
ABC_JIT_CC abc_value pow_1_0(ABC_JIT_ARGS) { r1=jit_pow(r1,r0); NEXT }
ABC_JIT_CC abc_value pow_1_1(ABC_JIT_ARGS) { r1=jit_pow(r1,r1); NEXT }
ABC_JIT_CC abc_value pow_1_2(ABC_JIT_ARGS) { r1=jit_pow(r1,r2); NEXT }
ABC_JIT_CC abc_value pow_1_3(ABC_JIT_ARGS) { r1=jit_pow(r1,r3); NEXT }
ABC_JIT_CC abc_value pow_1_4(ABC_JIT_ARGS) { r1=jit_pow(r1,r4); NEXT }
ABC_JIT_CC abc_value pow_1_5(ABC_JIT_ARGS) { r1=jit_pow(r1,r5); NEXT }
ABC_JIT_CC abc_value pow_1_6(ABC_JIT_ARGS) { r1=jit_pow(r1,r6); NEXT }
ABC_JIT_CC abc_value pow_1_7(ABC_JIT_ARGS) { r1=jit_pow(r1,r7); NEXT }
ABC_JIT_CC abc_value pow_2_0(ABC_JIT_ARGS) { r2=jit_pow(r2,r0); NEXT }
ABC_JIT_CC abc_value pow_2_1(ABC_JIT_ARGS) { r2=jit_pow(r2,r1); NEXT }
ABC_JIT_CC abc_value pow_2_2(ABC_JIT_ARGS) { r2=jit_pow(r2,r2); NEXT }
ABC_JIT_CC abc_value pow_2_3(ABC_JIT_ARGS) { r2=jit_pow(r2,r3); NEXT }
ABC_JIT_CC abc_value pow_2_4(ABC_JIT_ARGS) { r2=jit_pow(r2,r4); NEXT }
ABC_JIT_CC abc_value pow_2_5(ABC_JIT_ARGS) { r2=jit_pow(r2,r5); NEXT }
ABC_JIT_CC abc_value pow_2_6(ABC_JIT_ARGS) { r2=jit_pow(r2,r6); NEXT }
ABC_JIT_CC abc_value pow_2_7(ABC_JIT_ARGS) { r2=jit_pow(r2,r7); NEXT }
ABC_JIT_CC abc_value pow_3_0(ABC_JIT_ARGS) { r3=jit_pow(r3,r0); NEXT }
ABC_JIT_CC abc_value pow_3_1(ABC_JIT_ARGS) { r3=jit_pow(r3,r1); NEXT }
ABC_JIT_CC abc_value pow_3_2(ABC_JIT_ARGS) { r3=jit_pow(r3,r2); NEXT }
ABC_JIT_CC abc_value pow_3_3(ABC_JIT_ARGS) { r3=jit_pow(r3,r3); NEXT }
ABC_JIT_CC abc_value pow_3_4(ABC_JIT_ARGS) { r3=jit_pow(r3,r4); NEXT }
ABC_JIT_CC abc_value pow_3_5(ABC_JIT_ARGS) { r3=jit_pow(r3,r5); NEXT }
ABC_JIT_CC abc_value pow_3_6(ABC_JIT_ARGS) { r3=jit_pow(r3,r6); NEXT }
ABC_JIT_CC abc_value pow_3_7(ABC_JIT_ARGS) { r3=jit_pow(r3,r7); NEXT }
ABC_JIT_CC abc_value pow_4_0(ABC_JIT_ARGS) { r4=jit_pow(r4,r0); NEXT }
ABC_JIT_CC abc_value pow_4_1(ABC_JIT_ARGS) { r4=jit_pow(r4,r1); NEXT }
ABC_JIT_CC abc_value pow_4_2(ABC_JIT_ARGS) { r4=jit_pow(r4,r2); NEXT }
ABC_JIT_CC abc_value pow_4_3(ABC_JIT_ARGS) { r4=jit_pow(r4,r3); NEXT }
ABC_JIT_CC abc_value pow_4_4(ABC_JIT_ARGS) { r4=jit_pow(r4,r4); NEXT }
ABC_JIT_CC abc_value pow_4_5(ABC_JIT_ARGS) { r4=jit_pow(r4,r5); NEXT }
ABC_JIT_CC abc_value pow_4_6(ABC_JIT_ARGS) { r4=jit_pow(r4,r6); NEXT }
ABC_JIT_CC abc_value pow_4_7(ABC_JIT_ARGS) { r4=jit_pow(r4,r7); NEXT }
ABC_JIT_CC abc_value pow_5_0(ABC_JIT_ARGS) { r5=jit_pow(r5,r0); NEXT }
ABC_JIT_CC abc_value pow_5_1(ABC_JIT_ARGS) { r5=jit_pow(r5,r1); NEXT }
ABC_JIT_CC abc_value pow_5_2(ABC_JIT_ARGS) { r5=jit_pow(r5,r2); NEXT }
ABC_JIT_CC abc_value pow_5_3(ABC_JIT_ARGS) { r5=jit_pow(r5,r3); NEXT }
ABC_JIT_CC abc_value pow_5_4(ABC_JIT_ARGS) { r5=jit_pow(r5,r4); NEXT }
ABC_JIT_CC abc_value pow_5_5(ABC_JIT_ARGS) { r5=jit_pow(r5,r5); NEXT }
ABC_JIT_CC abc_value pow_5_6(ABC_JIT_ARGS) { r5=jit_pow(r5,r6); NEXT }
ABC_JIT_CC abc_value pow_5_7(ABC_JIT_ARGS) { r5=jit_pow(r5,r7); NEXT }
ABC_JIT_CC abc_value pow_6_0(ABC_JIT_ARGS) { r6=jit_pow(r6,r0); NEXT }
ABC_JIT_CC abc_value pow_6_1(ABC_JIT_ARGS) { r6=jit_pow(r6,r1); NEXT }
ABC_JIT_CC abc_value pow_6_2(ABC_JIT_ARGS) { r6=jit_pow(r6,r2); NEXT }
ABC_JIT_CC abc_value pow_6_3(ABC_JIT_ARGS) { r6=jit_pow(r6,r3); NEXT }
ABC_JIT_CC abc_value pow_6_4(ABC_JIT_ARGS) { r6=jit_pow(r6,r4); NEXT }
ABC_JIT_CC abc_value pow_6_5(ABC_JIT_ARGS) { r6=jit_pow(r6,r5); NEXT }
ABC_JIT_CC abc_value pow_6_6(ABC_JIT_ARGS) { r6=jit_pow(r6,r6); NEXT }
ABC_JIT_CC abc_value pow_6_7(ABC_JIT_ARGS) { r6=jit_pow(r6,r7); NEXT }
ABC_JIT_CC abc_value pow_7_0(ABC_JIT_ARGS) { r7=jit_pow(r7,r0); NEXT }
ABC_JIT_CC abc_value pow_7_1(ABC_JIT_ARGS) { r7=jit_pow(r7,r1); NEXT }
ABC_JIT_CC abc_value pow_7_2(ABC_JIT_ARGS) { r7=jit_pow(r7,r2); NEXT }
ABC_JIT_CC abc_value pow_7_3(ABC_JIT_ARGS) { r7=jit_pow(r7,r3); NEXT }
ABC_JIT_CC abc_value pow_7_4(ABC_JIT_ARGS) { r7=jit_pow(r7,r4); NEXT }
ABC_JIT_CC abc_value pow_7_5(ABC_JIT_ARGS) { r7=jit_pow(r7,r5); NEXT }
ABC_JIT_CC abc_value pow_7_6(ABC_JIT_ARGS) { r7=jit_pow(r7,r6); NEXT }
ABC_JIT_CC abc_value pow_7_7(ABC_JIT_ARGS) { r7=jit_pow(r7,r7); NEXT }
ABC_JIT_CC abc_value pows_0_0(ABC_JIT_ARGS) { if(abc_signed(r0)<0)return jit_error(); r0=jit_pow(r0,r0); NEXT }
ABC_JIT_CC abc_value pows_0_1(ABC_JIT_ARGS) { if(abc_signed(r1)<0)return jit_error(); r0=jit_pow(r0,r1); NEXT }
ABC_JIT_CC abc_value pows_0_2(ABC_JIT_ARGS) { if(abc_signed(r2)<0)return jit_error(); r0=jit_pow(r0,r2); NEXT }
ABC_JIT_CC abc_value pows_0_3(ABC_JIT_ARGS) { if(abc_signed(r3)<0)return jit_error(); r0=jit_pow(r0,r3); NEXT }
ABC_JIT_CC abc_value pows_0_4(ABC_JIT_ARGS) { if(abc_signed(r4)<0)return jit_error(); r0=jit_pow(r0,r4); NEXT }
ABC_JIT_CC abc_value pows_0_5(ABC_JIT_ARGS) { if(abc_signed(r5)<0)return jit_error(); r0=jit_pow(r0,r5); NEXT }
ABC_JIT_CC abc_value pows_0_6(ABC_JIT_ARGS) { if(abc_signed(r6)<0)return jit_error(); r0=jit_pow(r0,r6); NEXT }
ABC_JIT_CC abc_value pows_0_7(ABC_JIT_ARGS) { if(abc_signed(r7)<0)return jit_error(); r0=jit_pow(r0,r7); NEXT }
ABC_JIT_CC abc_value pows_1_0(ABC_JIT_ARGS) { if(abc_signed(r0)<0)return jit_error(); r1=jit_pow(r1,r0); NEXT }
ABC_JIT_CC abc_value pows_1_1(ABC_JIT_ARGS) { if(abc_signed(r1)<0)return jit_error(); r1=jit_pow(r1,r1); NEXT }
ABC_JIT_CC abc_value pows_1_2(ABC_JIT_ARGS) { if(abc_signed(r2)<0)return jit_error(); r1=jit_pow(r1,r2); NEXT }
ABC_JIT_CC abc_value pows_1_3(ABC_JIT_ARGS) { if(abc_signed(r3)<0)return jit_error(); r1=jit_pow(r1,r3); NEXT }
ABC_JIT_CC abc_value pows_1_4(ABC_JIT_ARGS) { if(abc_signed(r4)<0)return jit_error(); r1=jit_pow(r1,r4); NEXT }
ABC_JIT_CC abc_value pows_1_5(ABC_JIT_ARGS) { if(abc_signed(r5)<0)return jit_error(); r1=jit_pow(r1,r5); NEXT }
ABC_JIT_CC abc_value pows_1_6(ABC_JIT_ARGS) { if(abc_signed(r6)<0)return jit_error(); r1=jit_pow(r1,r6); NEXT }
ABC_JIT_CC abc_value pows_1_7(ABC_JIT_ARGS) { if(abc_signed(r7)<0)return jit_error(); r1=jit_pow(r1,r7); NEXT }
ABC_JIT_CC abc_value pows_2_0(ABC_JIT_ARGS) { if(abc_signed(r0)<0)return jit_error(); r2=jit_pow(r2,r0); NEXT }
ABC_JIT_CC abc_value pows_2_1(ABC_JIT_ARGS) { if(abc_signed(r1)<0)return jit_error(); r2=jit_pow(r2,r1); NEXT }
ABC_JIT_CC abc_value pows_2_2(ABC_JIT_ARGS) { if(abc_signed(r2)<0)return jit_error(); r2=jit_pow(r2,r2); NEXT }
ABC_JIT_CC abc_value pows_2_3(ABC_JIT_ARGS) { if(abc_signed(r3)<0)return jit_error(); r2=jit_pow(r2,r3); NEXT }
ABC_JIT_CC abc_value pows_2_4(ABC_JIT_ARGS) { if(abc_signed(r4)<0)return jit_error(); r2=jit_pow(r2,r4); NEXT }
ABC_JIT_CC abc_value pows_2_5(ABC_JIT_ARGS) { if(abc_signed(r5)<0)return jit_error(); r2=jit_pow(r2,r5); NEXT }
ABC_JIT_CC abc_value pows_2_6(ABC_JIT_ARGS) { if(abc_signed(r6)<0)return jit_error(); r2=jit_pow(r2,r6); NEXT }
ABC_JIT_CC abc_value pows_2_7(ABC_JIT_ARGS) { if(abc_signed(r7)<0)return jit_error(); r2=jit_pow(r2,r7); NEXT }
ABC_JIT_CC abc_value pows_3_0(ABC_JIT_ARGS) { if(abc_signed(r0)<0)return jit_error(); r3=jit_pow(r3,r0); NEXT }
ABC_JIT_CC abc_value pows_3_1(ABC_JIT_ARGS) { if(abc_signed(r1)<0)return jit_error(); r3=jit_pow(r3,r1); NEXT }
ABC_JIT_CC abc_value pows_3_2(ABC_JIT_ARGS) { if(abc_signed(r2)<0)return jit_error(); r3=jit_pow(r3,r2); NEXT }
ABC_JIT_CC abc_value pows_3_3(ABC_JIT_ARGS) { if(abc_signed(r3)<0)return jit_error(); r3=jit_pow(r3,r3); NEXT }
ABC_JIT_CC abc_value pows_3_4(ABC_JIT_ARGS) { if(abc_signed(r4)<0)return jit_error(); r3=jit_pow(r3,r4); NEXT }
ABC_JIT_CC abc_value pows_3_5(ABC_JIT_ARGS) { if(abc_signed(r5)<0)return jit_error(); r3=jit_pow(r3,r5); NEXT }
ABC_JIT_CC abc_value pows_3_6(ABC_JIT_ARGS) { if(abc_signed(r6)<0)return jit_error(); r3=jit_pow(r3,r6); NEXT }
ABC_JIT_CC abc_value pows_3_7(ABC_JIT_ARGS) { if(abc_signed(r7)<0)return jit_error(); r3=jit_pow(r3,r7); NEXT }
ABC_JIT_CC abc_value pows_4_0(ABC_JIT_ARGS) { if(abc_signed(r0)<0)return jit_error(); r4=jit_pow(r4,r0); NEXT }
ABC_JIT_CC abc_value pows_4_1(ABC_JIT_ARGS) { if(abc_signed(r1)<0)return jit_error(); r4=jit_pow(r4,r1); NEXT }
ABC_JIT_CC abc_value pows_4_2(ABC_JIT_ARGS) { if(abc_signed(r2)<0)return jit_error(); r4=jit_pow(r4,r2); NEXT }
ABC_JIT_CC abc_value pows_4_3(ABC_JIT_ARGS) { if(abc_signed(r3)<0)return jit_error(); r4=jit_pow(r4,r3); NEXT }
ABC_JIT_CC abc_value pows_4_4(ABC_JIT_ARGS) { if(abc_signed(r4)<0)return jit_error(); r4=jit_pow(r4,r4); NEXT }
ABC_JIT_CC abc_value pows_4_5(ABC_JIT_ARGS) { if(abc_signed(r5)<0)return jit_error(); r4=jit_pow(r4,r5); NEXT }
ABC_JIT_CC abc_value pows_4_6(ABC_JIT_ARGS) { if(abc_signed(r6)<0)return jit_error(); r4=jit_pow(r4,r6); NEXT }
ABC_JIT_CC abc_value pows_4_7(ABC_JIT_ARGS) { if(abc_signed(r7)<0)return jit_error(); r4=jit_pow(r4,r7); NEXT }
ABC_JIT_CC abc_value pows_5_0(ABC_JIT_ARGS) { if(abc_signed(r0)<0)return jit_error(); r5=jit_pow(r5,r0); NEXT }
ABC_JIT_CC abc_value pows_5_1(ABC_JIT_ARGS) { if(abc_signed(r1)<0)return jit_error(); r5=jit_pow(r5,r1); NEXT }
ABC_JIT_CC abc_value pows_5_2(ABC_JIT_ARGS) { if(abc_signed(r2)<0)return jit_error(); r5=jit_pow(r5,r2); NEXT }
ABC_JIT_CC abc_value pows_5_3(ABC_JIT_ARGS) { if(abc_signed(r3)<0)return jit_error(); r5=jit_pow(r5,r3); NEXT }
ABC_JIT_CC abc_value pows_5_4(ABC_JIT_ARGS) { if(abc_signed(r4)<0)return jit_error(); r5=jit_pow(r5,r4); NEXT }
ABC_JIT_CC abc_value pows_5_5(ABC_JIT_ARGS) { if(abc_signed(r5)<0)return jit_error(); r5=jit_pow(r5,r5); NEXT }
ABC_JIT_CC abc_value pows_5_6(ABC_JIT_ARGS) { if(abc_signed(r6)<0)return jit_error(); r5=jit_pow(r5,r6); NEXT }
ABC_JIT_CC abc_value pows_5_7(ABC_JIT_ARGS) { if(abc_signed(r7)<0)return jit_error(); r5=jit_pow(r5,r7); NEXT }
ABC_JIT_CC abc_value pows_6_0(ABC_JIT_ARGS) { if(abc_signed(r0)<0)return jit_error(); r6=jit_pow(r6,r0); NEXT }
ABC_JIT_CC abc_value pows_6_1(ABC_JIT_ARGS) { if(abc_signed(r1)<0)return jit_error(); r6=jit_pow(r6,r1); NEXT }
ABC_JIT_CC abc_value pows_6_2(ABC_JIT_ARGS) { if(abc_signed(r2)<0)return jit_error(); r6=jit_pow(r6,r2); NEXT }
ABC_JIT_CC abc_value pows_6_3(ABC_JIT_ARGS) { if(abc_signed(r3)<0)return jit_error(); r6=jit_pow(r6,r3); NEXT }
ABC_JIT_CC abc_value pows_6_4(ABC_JIT_ARGS) { if(abc_signed(r4)<0)return jit_error(); r6=jit_pow(r6,r4); NEXT }
ABC_JIT_CC abc_value pows_6_5(ABC_JIT_ARGS) { if(abc_signed(r5)<0)return jit_error(); r6=jit_pow(r6,r5); NEXT }
ABC_JIT_CC abc_value pows_6_6(ABC_JIT_ARGS) { if(abc_signed(r6)<0)return jit_error(); r6=jit_pow(r6,r6); NEXT }
ABC_JIT_CC abc_value pows_6_7(ABC_JIT_ARGS) { if(abc_signed(r7)<0)return jit_error(); r6=jit_pow(r6,r7); NEXT }
ABC_JIT_CC abc_value pows_7_0(ABC_JIT_ARGS) { if(abc_signed(r0)<0)return jit_error(); r7=jit_pow(r7,r0); NEXT }
ABC_JIT_CC abc_value pows_7_1(ABC_JIT_ARGS) { if(abc_signed(r1)<0)return jit_error(); r7=jit_pow(r7,r1); NEXT }
ABC_JIT_CC abc_value pows_7_2(ABC_JIT_ARGS) { if(abc_signed(r2)<0)return jit_error(); r7=jit_pow(r7,r2); NEXT }
ABC_JIT_CC abc_value pows_7_3(ABC_JIT_ARGS) { if(abc_signed(r3)<0)return jit_error(); r7=jit_pow(r7,r3); NEXT }
ABC_JIT_CC abc_value pows_7_4(ABC_JIT_ARGS) { if(abc_signed(r4)<0)return jit_error(); r7=jit_pow(r7,r4); NEXT }
ABC_JIT_CC abc_value pows_7_5(ABC_JIT_ARGS) { if(abc_signed(r5)<0)return jit_error(); r7=jit_pow(r7,r5); NEXT }
ABC_JIT_CC abc_value pows_7_6(ABC_JIT_ARGS) { if(abc_signed(r6)<0)return jit_error(); r7=jit_pow(r7,r6); NEXT }
ABC_JIT_CC abc_value pows_7_7(ABC_JIT_ARGS) { if(abc_signed(r7)<0)return jit_error(); r7=jit_pow(r7,r7); NEXT }
ABC_JIT_CC abc_value check_u8_0(ABC_JIT_ARGS) { if(r0>255)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u8_1(ABC_JIT_ARGS) { if(r1>255)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u8_2(ABC_JIT_ARGS) { if(r2>255)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u8_3(ABC_JIT_ARGS) { if(r3>255)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u8_4(ABC_JIT_ARGS) { if(r4>255)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u8_5(ABC_JIT_ARGS) { if(r5>255)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u8_6(ABC_JIT_ARGS) { if(r6>255)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u8_7(ABC_JIT_ARGS) { if(r7>255)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u16_0(ABC_JIT_ARGS) { if(r0>65535)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u16_1(ABC_JIT_ARGS) { if(r1>65535)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u16_2(ABC_JIT_ARGS) { if(r2>65535)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u16_3(ABC_JIT_ARGS) { if(r3>65535)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u16_4(ABC_JIT_ARGS) { if(r4>65535)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u16_5(ABC_JIT_ARGS) { if(r5>65535)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u16_6(ABC_JIT_ARGS) { if(r6>65535)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u16_7(ABC_JIT_ARGS) { if(r7>65535)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u32_0(ABC_JIT_ARGS) { if(r0>UINT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u32_1(ABC_JIT_ARGS) { if(r1>UINT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u32_2(ABC_JIT_ARGS) { if(r2>UINT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u32_3(ABC_JIT_ARGS) { if(r3>UINT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u32_4(ABC_JIT_ARGS) { if(r4>UINT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u32_5(ABC_JIT_ARGS) { if(r5>UINT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u32_6(ABC_JIT_ARGS) { if(r6>UINT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_u32_7(ABC_JIT_ARGS) { if(r7>UINT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_i32_0(ABC_JIT_ARGS) { if(abc_signed(r0)<INT32_MIN || abc_signed(r0)>INT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_i32_1(ABC_JIT_ARGS) { if(abc_signed(r1)<INT32_MIN || abc_signed(r1)>INT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_i32_2(ABC_JIT_ARGS) { if(abc_signed(r2)<INT32_MIN || abc_signed(r2)>INT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_i32_3(ABC_JIT_ARGS) { if(abc_signed(r3)<INT32_MIN || abc_signed(r3)>INT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_i32_4(ABC_JIT_ARGS) { if(abc_signed(r4)<INT32_MIN || abc_signed(r4)>INT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_i32_5(ABC_JIT_ARGS) { if(abc_signed(r5)<INT32_MIN || abc_signed(r5)>INT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_i32_6(ABC_JIT_ARGS) { if(abc_signed(r6)<INT32_MIN || abc_signed(r6)>INT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_i32_7(ABC_JIT_ARGS) { if(abc_signed(r7)<INT32_MIN || abc_signed(r7)>INT32_MAX)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_nn_0(ABC_JIT_ARGS) { if(r0>>63)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_nn_1(ABC_JIT_ARGS) { if(r1>>63)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_nn_2(ABC_JIT_ARGS) { if(r2>>63)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_nn_3(ABC_JIT_ARGS) { if(r3>>63)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_nn_4(ABC_JIT_ARGS) { if(r4>>63)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_nn_5(ABC_JIT_ARGS) { if(r5>>63)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_nn_6(ABC_JIT_ARGS) { if(r6>>63)return jit_error(); NEXT }
ABC_JIT_CC abc_value check_nn_7(ABC_JIT_ARGS) { if(r7>>63)return jit_error(); NEXT }
ABC_JIT_CC abc_value fcall_a_0(ABC_JIT_ARGS) { abc_value bridge,ext,target,out=0;__asm__("movabsq $HOLE_FINAL,%0":"=r"(bridge));__asm__("movabsq $HOLE_STATE,%0":"=r"(ext));__asm__("movabsq $HOLE_BIAS,%0":"=r"(target));if(((abc_foreign_bridge)(uintptr_t)bridge)((const void *)(uintptr_t)ext,(void(*)(void))(uintptr_t)target,asp+(int32_t)(intptr_t)HOLE_IMM,&out))return jit_error();NEXT }
ABC_JIT_CC abc_value fcall_a_1(ABC_JIT_ARGS) { abc_value bridge,ext,target,out=0;__asm__("movabsq $HOLE_FINAL,%0":"=r"(bridge));__asm__("movabsq $HOLE_STATE,%0":"=r"(ext));__asm__("movabsq $HOLE_BIAS,%0":"=r"(target));if(((abc_foreign_bridge)(uintptr_t)bridge)((const void *)(uintptr_t)ext,(void(*)(void))(uintptr_t)target,asp+(int32_t)(intptr_t)HOLE_IMM,&out))return jit_error();asp[(int32_t)(intptr_t)HOLE_IMM]=out;NEXT }
ABC_JIT_CC abc_value fcall_b_0(ABC_JIT_ARGS) { abc_value bridge,ext,target,out=0;__asm__("movabsq $HOLE_FINAL,%0":"=r"(bridge));__asm__("movabsq $HOLE_STATE,%0":"=r"(ext));__asm__("movabsq $HOLE_BIAS,%0":"=r"(target));if(((abc_foreign_bridge)(uintptr_t)bridge)((const void *)(uintptr_t)ext,(void(*)(void))(uintptr_t)target,bsp+(int32_t)(intptr_t)HOLE_IMM,&out))return jit_error();NEXT }
ABC_JIT_CC abc_value fcall_b_1(ABC_JIT_ARGS) { abc_value bridge,ext,target,out=0;__asm__("movabsq $HOLE_FINAL,%0":"=r"(bridge));__asm__("movabsq $HOLE_STATE,%0":"=r"(ext));__asm__("movabsq $HOLE_BIAS,%0":"=r"(target));if(((abc_foreign_bridge)(uintptr_t)bridge)((const void *)(uintptr_t)ext,(void(*)(void))(uintptr_t)target,bsp+(int32_t)(intptr_t)HOLE_IMM,&out))return jit_error();bsp[(int32_t)(intptr_t)HOLE_IMM]=out;NEXT }
ABC_JIT_CC abc_value abort(ABC_JIT_ARGS) { return jit_error(); }
ABC_JIT_CC abc_value guard_a(ABC_JIT_ARGS) { abc_value *limit,*next;__asm__("movabsq $HOLE_FINAL,%0":"=r"(limit));__asm__("leaq HOLE_IMM(%1),%0":"=r"(next):"r"(asp));if(next>limit)return jit_error();NEXT }
ABC_JIT_CC abc_value guard_b(ABC_JIT_ARGS) { abc_value *limit,*next;__asm__("movabsq $HOLE_FINAL,%0":"=r"(limit));__asm__("leaq HOLE_IMM(%1),%0":"=r"(next):"r"(bsp));if(next>limit)return jit_error();NEXT }
ABC_JIT_CC abc_value guard_c(ABC_JIT_ARGS) { abc_value *limit,*next;__asm__("movabsq $HOLE_FINAL,%0":"=r"(limit));__asm__("leaq HOLE_IMM(%1),%0":"=r"(next):"r"(csp));if(next>limit)return jit_error();NEXT }
ABC_JIT_CC abc_value resolve_indirect(ABC_JIT_ARGS) { abc_value resolver,pc,entry;__asm__("movabsq $HOLE_FINAL,%0":"=r"(resolver));__asm__("movabsq $HOLE_STATE,%0":"=r"(pc));abc_value status=((abc_resolve_fn)(uintptr_t)resolver)(r0,pc,(uintptr_t)asp+(intptr_t)HOLE_IMM,(uintptr_t)bsp+(intptr_t)HOLE_BIAS,(uintptr_t)csp+(intptr_t)HOLE_IMM2,&entry);if(status)return status;r0=entry;NEXT }
ABC_JIT_CC abc_value store_label(ABC_JIT_ARGS) { abc_value label;__asm__("movabsq $HOLE_TAKEN,%0":"=r"(label));__asm__("movq %1,HOLE_IMM(%0)"::"r"(csp),"r"(label):"memory");NEXT }
ABC_JIT_CC abc_value rebase_a(ABC_JIT_ARGS) { __asm__("leaq HOLE_IMM(%0),%0":"+r"(asp));NEXT }
ABC_JIT_CC abc_value rebase_b(ABC_JIT_ARGS) { __asm__("leaq HOLE_IMM(%0),%0":"+r"(bsp));NEXT }
ABC_JIT_CC abc_value rebase_c(ABC_JIT_ARGS) { __asm__("leaq HOLE_IMM(%0),%0":"+r"(csp));NEXT }
ABC_JIT_CC abc_value continue_0(ABC_JIT_ARGS) { TAIL return ((abc_jit_fn)(uintptr_t)r0)(ABC_JIT_PASS); }
ABC_JIT_CC abc_value continue_1(ABC_JIT_ARGS) { TAIL return ((abc_jit_fn)(uintptr_t)r1)(ABC_JIT_PASS); }
ABC_JIT_CC abc_value continue_2(ABC_JIT_ARGS) { TAIL return ((abc_jit_fn)(uintptr_t)r2)(ABC_JIT_PASS); }
ABC_JIT_CC abc_value continue_3(ABC_JIT_ARGS) { TAIL return ((abc_jit_fn)(uintptr_t)r3)(ABC_JIT_PASS); }
ABC_JIT_CC abc_value continue_4(ABC_JIT_ARGS) { TAIL return ((abc_jit_fn)(uintptr_t)r4)(ABC_JIT_PASS); }
ABC_JIT_CC abc_value continue_5(ABC_JIT_ARGS) { TAIL return ((abc_jit_fn)(uintptr_t)r5)(ABC_JIT_PASS); }
ABC_JIT_CC abc_value continue_6(ABC_JIT_ARGS) { TAIL return ((abc_jit_fn)(uintptr_t)r6)(ABC_JIT_PASS); }
ABC_JIT_CC abc_value continue_7(ABC_JIT_ARGS) { TAIL return ((abc_jit_fn)(uintptr_t)r7)(ABC_JIT_PASS); }
ABC_JIT_CC abc_value jump(ABC_JIT_ARGS) { TAIL return HOLE_TAKEN(ABC_JIT_PASS); }
ABC_JIT_CC abc_value finish(ABC_JIT_ARGS) { *(abc_value *)(uintptr_t)HOLE_FINAL=r0; return 0; }
ABC_JIT_CC abc_value return_ok(ABC_JIT_ARGS) { return 0; }
ABC_JIT_CC abc_value lazy_entry(ABC_JIT_ARGS) { abc_value state,prepare;__asm__("movabsq $HOLE_STATE,%0":"=r"(state));__asm__("movabsq $HOLE_FINAL,%0":"=r"(prepare));abc_value*s=(abc_value*)(uintptr_t)state;s[0]=(abc_value)(uintptr_t)asp;s[1]=(abc_value)(uintptr_t)bsp;s[2]=(abc_value)(uintptr_t)csp;s[3]=r0;s[4]=r1;s[5]=r2;s[6]=r3;s[7]=r4;s[8]=r5;s[9]=r6;s[10]=r7;abc_value body=((abc_lazy_prepare_fn)(uintptr_t)prepare)(state);if(s[11])return s[11];TAIL return ((abc_jit_fn)(uintptr_t)body)((abc_value*)(uintptr_t)s[0],(abc_value*)(uintptr_t)s[1],(abc_value*)(uintptr_t)s[2],s[3],s[4],s[5],s[6],s[7],s[8],s[9],s[10]); }
