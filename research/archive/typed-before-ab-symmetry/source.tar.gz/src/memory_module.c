#include "internal.h"

/* Canonical persistent stacks: a join compares IDs, not just depths.
 * C nodes distinguish scalar cells from opaque padded byte blocks. */
typedef struct { uint32_t prev, span, bytes, depth; unsigned kind; } Node;
typedef struct { Node *nodes; uint32_t *hash; uint32_t count, capacity, hash_size; abc_status error; } Pool;
typedef struct { uint32_t a, b, c; unsigned seen; } Shape;
enum { MAX_NODES = 1048576 };
static uint32_t hash_node(Node n) {
    return n.prev*UINT32_C(2654435761) ^ n.span*UINT32_C(2246822519) ^ n.bytes*UINT32_C(3266489917) ^ n.kind;
}
static int same_node(Node a, Node b) { return a.prev==b.prev && a.span==b.span && a.bytes==b.bytes && a.kind==b.kind; }
static uint32_t intern(Pool *pool, uint32_t prev, unsigned kind, uint32_t span, uint32_t bytes) {
    if (pool->error) return 0;
    Node n={prev,span,bytes,pool->nodes[prev].depth+span,kind};
    if (n.depth>ABC_MAX_FILE) { pool->error=ABC_INVALID; return 0; }
    uint32_t slot=hash_node(n)&(pool->hash_size-1);
    while (pool->hash[slot]) {
        uint32_t id=pool->hash[slot]; if (same_node(n,pool->nodes[id])) return id;
        slot=(slot+1)&(pool->hash_size-1);
    }
    if (pool->count==MAX_NODES) { pool->error=ABC_INVALID; return 0; }
    if (pool->count==pool->capacity) {
        uint32_t cap=pool->capacity*2; Node *nodes=realloc(pool->nodes,(size_t)cap*sizeof *nodes);
        if (!nodes) { pool->error=ABC_NOMEM; return 0; } pool->nodes=nodes; pool->capacity=cap;
    }
    uint32_t id=pool->count++; pool->nodes[id]=n; pool->hash[slot]=id;
    if ((uint64_t)pool->count*4>pool->hash_size*3) {
        uint32_t size=pool->hash_size*2; uint32_t *table=calloc(size,sizeof *table);
        if (!table) { pool->error=ABC_NOMEM; return 0; }
        for (uint32_t i=1;i<pool->count;i++) {
            uint32_t at=hash_node(pool->nodes[i])&(size-1); while (table[at]) at=(at+1)&(size-1); table[at]=i;
        }
        free(pool->hash); pool->hash=table; pool->hash_size=size;
    }
    return id;
}
static uint32_t push(Pool *p,uint32_t stack,unsigned kind) { return intern(p,stack,kind,1,0); }
static uint32_t cslot(const Pool *p,uint32_t c,uint32_t depth) {
    while (c) { Node n=p->nodes[c]; if (depth<n.span) return n.kind==ABC_KIND_BLOCK ? 0 : c; depth-=n.span; c=n.prev; }
    return 0;
}
static uint32_t cset(Pool *p,uint32_t c,uint32_t depth,unsigned kind) {
    uint32_t prefix[256], count=0, cursor=c;
    while (depth>=p->nodes[cursor].span) { prefix[count++]=cursor; depth-=p->nodes[cursor].span; cursor=p->nodes[cursor].prev; }
    if (p->nodes[cursor].kind==kind) return c;
    uint32_t result=push(p,p->nodes[cursor].prev,kind);
    while (count) { Node n=p->nodes[prefix[--count]]; result=intern(p,result,n.kind,n.span,n.bytes); }
    return result;
}
static int frame_access(const Pool *p,uint32_t c,uint32_t offset,unsigned width) {
    uint32_t above=0;
    while (c) {
        Node n=p->nodes[c]; uint32_t extent=n.span*8;
        if (offset>above && offset<=above+extent) {
            uint32_t index=above+extent-offset;
            return n.kind==ABC_KIND_BLOCK && index<n.bytes && width<=n.bytes-index;
        }
        above+=extent; c=n.prev;
    }
    return 0;
}
static int result_shape(const Pool *p,uint32_t a,const abc_function *f) {
    for (uint32_t i=f->results;i;i--) { if (!a || p->nodes[a].kind!=f->result_kinds[i-1]) return 0; a=p->nodes[a].prev; }
    return !a;
}
static int load64(unsigned op) {
    abc_memory_op m=op_memory[op]; return m.width==8 && (m.action==M_FLOAD || m.action==M_GLOAD || m.action==M_PLOAD || m.action==M_XLOAD);
}
static int value_kind(unsigned kind) { return kind==ABC_KIND_INT || kind==ABC_KIND_ADDR || kind==ABC_KIND_FLOAT; }
static abc_status verify_memory(abc_module *m,abc_error *e) {
    uint8_t *starts=calloc(m->code_size,1); Shape *shapes=calloc(m->code_size,sizeof *shapes);
    uint32_t *work=malloc(m->code_size*sizeof *work); Pool pool={0};
    pool.capacity=1024; pool.hash_size=2048; pool.count=1;
    pool.nodes=calloc(pool.capacity,sizeof *pool.nodes); pool.hash=calloc(pool.hash_size,sizeof *pool.hash);
    abc_status status=ABC_OK; uint32_t pc=0;
    #define BAD(...) do { status=abc_fail(e,ABC_INVALID,pc,__VA_ARGS__); goto done; } while(0)
    #define POOL_CHECK() do { if (pool.error) { status=abc_fail(e,pool.error,pc,"verifier state allocation/complexity limit reached"); goto done; } } while(0)
    if (!starts || !shapes || !work || !pool.nodes || !pool.hash) { status=abc_fail(e,ABC_NOMEM,UINT32_MAX,"verifier allocation failed"); goto done; }
    for (uint32_t fi=0;fi<m->function_count;fi++) {
        abc_function *f=&m->functions[fi];
        for (pc=f->entry;pc<f->end;pc+=abc_instruction_length(m->code+pc)) {
            unsigned op=m->code[pc];
            if (op>=OP_COUNT || op_kind[op]==K_INTERNAL) BAD("unknown or internal opcode %u",op);
            if (op==OP_EXT) BAD("EXT is unavailable in the typed-only VM");
            uint32_t length=op==OP_SWITCH?(f->end-pc<3?0:3u+4u*abc_u16(m->code+pc+1)):abc_instruction_length(m->code+pc);if(!length)BAD("truncated SWITCH instruction");
            if (length>f->end-pc) BAD("truncated instruction");
            if (!m->callable_profile && (op_kind[op]==K_ICALL || op_kind[op]==K_ITCALL)) BAD("indirect opcode requires callable profile");
            if (op==OP_ABORT && !m->code[pc+1]) BAD("ABORT reason must be nonzero");
            if (op==OP_HALT) f->has_halt=1;
            starts[pc]=1;
        }
    }
    for (pc=0;pc<m->code_size;pc++) if (m->load_kinds[pc] && (!starts[pc] || !load64(m->code[pc]))) BAD("load kind annotation requires a 64-bit memory load");
    for (uint32_t i=0;i<m->site_count;i++) {
        const abc_function *site=&m->sites[i]; pc=site->entry;
        if (!starts[pc] || (op_kind[m->code[pc]]!=K_ICALL && op_kind[m->code[pc]]!=K_ITCALL)) BAD("site signature requires an indirect instruction");
    }
    for (uint32_t i=0;i<m->reloc_count;i++) if (m->functions[m->relocs[i].function].has_halt) BAD("code relocation targets host-entry-only function");
    for (uint32_t fi=0;fi<m->function_count;fi++) {
        const abc_function *f=&m->functions[fi];
        for (pc=f->entry;pc<f->end;pc+=abc_instruction_length(m->code+pc)) {
            const uint8_t *p=m->code+pc; unsigned op=p[0],kind=op_kind[op]; uint32_t next=pc+abc_instruction_length(p);
            if (kind==K_BRANCH || kind==K_BRI || kind==K_JMP32) {
                int64_t target=(int64_t)next+(kind==K_JMP32?abc_i32(p+1):abc_i16(p+(kind==K_BRI ? 2:1)));
                if (target<f->entry || target>=f->end || !starts[target]) BAD("branch target is not an instruction in this function");
            } else if(kind==K_SWITCH) for(unsigned j=0;j<abc_u16(p+1);j++){int64_t target=(int64_t)next+abc_i32(p+3+4*j);if(target<f->entry||target>=f->end||!starts[target])BAD("SWITCH target is not an instruction in this function");}
            if (kind==K_CALL || kind==K_TCALL) {
                int64_t target=(int64_t)next+abc_i32(p+1); int callee=target<0 || target>UINT32_MAX ? -1 : abc_find_function(m,(uint32_t)target);
                if (callee<0) BAD("call target is not a function entry");
                const abc_function *g=&m->functions[callee];
                if (g->has_halt) BAD("a function containing HALT is host-entry-only");
                if (p[kind==K_CALL ? 5 : 6]!=g->arguments) BAD("call argument count disagrees with function table");
                if (kind==K_TCALL && (f->results!=g->results || memcmp(f->result_kinds,g->result_kinds,f->results))) BAD("tail call result contract disagrees");
            }
            if (kind==K_ICALL || kind==K_ITCALL) {
                const abc_function *site=abc_find_site(m,pc); unsigned tail=kind==K_ITCALL;
                if (!site || p[tail ? 2 : 1]!=site->arguments) BAD("missing or inconsistent indirect signature");
                if (abc_u32(p+(tail ? 3 : 2))) BAD("serialized indirect cache must be zero");
                if (tail && (f->results!=site->results || memcmp(f->result_kinds,site->result_kinds,f->results))) BAD("indirect tail result contract disagrees");
            }
            if (kind==K_FCALL && (!m->foreign_profile || abc_u16(p+1)>=m->extern_count)) BAD("invalid foreign-call index");
            abc_memory_op mem=op_memory[op]; uint32_t off=op_len[op]==5 ? abc_u32(p+1) : op_len[op]==3 ? abc_u16(p+1) : 0;
            if (mem.action==M_GLOAD && ((uint64_t)off+mem.width>m->image_size)) BAD("image load outside image");
            if (mem.action==M_GSTORE && ((uint64_t)off+mem.width>m->data_size)) BAD("image store outside writable prefix");
            if (mem.action==M_GADDR && off>=m->image_size) BAD("image address outside image");
        }
    }
    for (uint32_t fi=0;fi<m->function_count;fi++) {
        abc_function *f=&m->functions[fi]; size_t nw=0; uint32_t c=0;
        for (uint32_t i=f->arguments;i;i--) c=push(&pool,c,f->argument_kinds[i-1]);
        f->max_a=f->max_b=0; f->max_c=f->arguments;
        pc=f->entry; POOL_CHECK(); shapes[pc]=(Shape){0,0,c,1}; work[nw++]=pc;
        while (nw) {
            pc=work[--nw]; const uint8_t *p=m->code+pc; unsigned op=p[0],kind=op_kind[op];
            uint32_t next=pc+abc_instruction_length(p); Shape s=shapes[pc]; int terminal=0,branch=0;
            #define DEPTH(S) (pool.nodes[s.S].depth)
            #define NEED(A,B,C) do { if ((int64_t)DEPTH(a)<(int64_t)(A) || (int64_t)DEPTH(b)<(int64_t)(B) || (int64_t)DEPTH(c)<(int64_t)(C)) BAD("stack underflow or C access outside own frame"); } while(0)
            #define INTEGER(S) do { if (pool.nodes[s.S].kind!=ABC_KIND_INT) BAD("integer instruction given non-integer kind"); } while(0)
            #define FLOAT(S) do { if (pool.nodes[s.S].kind!=ABC_KIND_FLOAT) BAD("float instruction given non-float kind"); } while(0)
            #define ADDRESS(S) do { if (pool.nodes[s.S].kind!=ABC_KIND_ADDR) BAD("memory instruction requires address kind"); } while(0)
            #define POP(S) (s.S=pool.nodes[s.S].prev)
            if(kind==K_MEMORY) {
                abc_memory_op mem=op_memory[op]; uint32_t off=op_len[op]==5 ? abc_u32(p+1) : op_len[op]==3 ? abc_u16(p+1) : 0;
                uint32_t *dst=mem.to_b ? &s.b : &s.a; unsigned loaded=m->load_kinds[pc] ? m->load_kinds[pc]-1 : ABC_KIND_INT;
                switch (mem.action) {
                    case M_ALLOC: if (off) s.c=intern(&pool,s.c,ABC_KIND_BLOCK,(off+7)/8,off); break;
                    case M_FREE:
                        if (off) { if (!s.c || pool.nodes[s.c].kind!=ABC_KIND_BLOCK || pool.nodes[s.c].bytes!=off) BAD("CFREE must release the complete top frame block"); POP(c); } break;
                    case M_FLOAD: case M_FSTORE: case M_FADDR:
                        if (!frame_access(&pool,s.c,off,mem.width)) BAD("frame access outside a live byte block");
                        if (mem.action==M_FSTORE) {
                            if (!*dst) BAD("stack underflow");
                            if (mem.width<8 && pool.nodes[*dst].kind!=ABC_KIND_INT) BAD("narrow store requires integer kind");
                            *dst=pool.nodes[*dst].prev;
                        } else *dst=push(&pool,*dst,mem.action==M_FADDR ? ABC_KIND_ADDR : loaded);
                        break;
                    case M_GLOAD: *dst=push(&pool,*dst,loaded); break;
                    case M_GSTORE: NEED(1,0,0); if (mem.width<8) INTEGER(a); POP(a); break;
                    case M_GADDR: *dst=push(&pool,*dst,ABC_KIND_ADDR); break;
                    case M_PLOAD:
                        if (!*dst) BAD("stack underflow");
                        if (pool.nodes[*dst].kind!=ABC_KIND_ADDR) BAD("memory instruction requires address kind");
                        *dst=push(&pool,pool.nodes[*dst].prev,loaded); break;
                    case M_PSTORE: NEED(1,1,0); ADDRESS(a); if (mem.width<8) INTEGER(b); POP(a); POP(b); break;
                    case M_XLOAD: NEED(1,1,0); ADDRESS(a); INTEGER(b); POP(a); POP(b); s.a=push(&pool,s.a,loaded); break;
                    case M_INDEX: NEED(1,1,0); ADDRESS(a); INTEGER(b); POP(b); break;
                    case M_COPY: NEED(1,1,0); ADDRESS(a); ADDRESS(b); POP(a); POP(b); break;
                    default: BAD("unsupported memory instruction");
                }
            } else if(kind==K_FCALL) {
                const abc_extern *ext=&m->externs[abc_u16(p+1)]; NEED(ext->arguments,0,0);
                for(uint32_t i=ext->arguments;i;i--){if(pool.nodes[s.a].kind!=ext->argument_kinds[i-1])BAD("foreign argument kind disagrees with signature");POP(a);}
                if(ext->results)s.a=push(&pool,s.a,ext->result_kinds[0]);
            } else if (op>=OP_ADD_A && op<=OP_LEU_B) {
                NEED(1,1,0); unsigned base=OP_ADD_A+((op-OP_ADD_A)&~1u);
                if ((base==OP_EQ_A || base==OP_NE_A) && pool.nodes[s.a].kind==ABC_KIND_ADDR && pool.nodes[s.b].kind==ABC_KIND_ADDR) { /* address identity permitted */ }
                else { INTEGER(a); INTEGER(b); }
                POP(a); POP(b); if ((op-OP_ADD_A)&1) s.b=push(&pool,s.b,ABC_KIND_INT); else s.a=push(&pool,s.a,ABC_KIND_INT);
            } else if (op>=OP_FADD_A && op<=OP_FEQ_B) {
                NEED(1,1,0); FLOAT(a); FLOAT(b); unsigned compare=op>=OP_FLT_A; POP(a); POP(b);
                if ((op-OP_FADD_A)&1) s.b=push(&pool,s.b,compare?ABC_KIND_INT:ABC_KIND_FLOAT); else s.a=push(&pool,s.a,compare?ABC_KIND_INT:ABC_KIND_FLOAT);
            } else if (op>=OP_FNEG && op<=OP_F2IU) {
                NEED(1,0,0); unsigned from=pool.nodes[s.a].kind;
                if (op==OP_FNEG) { if(from!=ABC_KIND_FLOAT) BAD("FNEG requires float kind"); }
                else if (op==OP_I2FS || op==OP_I2FU) { if(from!=ABC_KIND_INT) BAD("integer-to-float conversion requires integer kind"); POP(a); s.a=push(&pool,s.a,ABC_KIND_FLOAT); }
                else { if(from!=ABC_KIND_FLOAT) BAD("float-to-integer conversion requires float kind"); POP(a); s.a=push(&pool,s.a,ABC_KIND_INT); }
            } else if (kind==K_OPI || kind==K_OPC) {
                unsigned index=op-(kind==K_OPI ? OP_ADDI_A : OP_ADDC_A);
                if (index&1) { NEED(0,1,0); INTEGER(b); } else { NEED(1,0,0); INTEGER(a); }
                if (kind==K_OPC) { uint32_t slot=cslot(&pool,s.c,p[1]); if (!slot) BAD("C arithmetic outside a scalar frame cell"); if (pool.nodes[slot].kind!=ABC_KIND_INT) BAD("C arithmetic requires integer kind"); }
            } else if (op>=OP_NEG_A && op<=OP_SX32_B) {
                if ((op-OP_NEG_A)&1) { NEED(0,1,0); INTEGER(b); } else { NEED(1,0,0); INTEGER(a); }
            } else if (op>=OP_ZX8 && op<=OP_CHKNN) {
                NEED(1,0,0); INTEGER(a); if (op==OP_POW || op==OP_POWS) { NEED(1,1,0); INTEGER(b); POP(b); }
            } else switch (op) {
                case OP_PUSH8_A: case OP_PUSH32_A: case OP_PUSH64_A: s.a=push(&pool,s.a,ABC_KIND_INT); break;
                case OP_PUSH8_B: case OP_PUSH32_B: case OP_PUSH64_B: s.b=push(&pool,s.b,ABC_KIND_INT); break;
                case OP_DUP_A: NEED(1,0,0); s.a=push(&pool,s.a,pool.nodes[s.a].kind); break;
                case OP_DUP_B: NEED(0,1,0); s.b=push(&pool,s.b,pool.nodes[s.b].kind); break;
                case OP_DROP_A: NEED(1,0,0); POP(a); break; case OP_DROP_B: NEED(0,1,0); POP(b); break;
                case OP_COPY_AB: case OP_MOVE_AB: NEED(1,0,0); s.b=push(&pool,s.b,pool.nodes[s.a].kind); if (op==OP_MOVE_AB) POP(a); break;
                case OP_COPY_BA: case OP_MOVE_BA: NEED(0,1,0); s.a=push(&pool,s.a,pool.nodes[s.b].kind); if (op==OP_MOVE_BA) POP(b); break;
                case OP_CPUSH_A: NEED(1,0,0); s.c=push(&pool,s.c,pool.nodes[s.a].kind); POP(a); break;
                case OP_CPUSH_B: NEED(0,1,0); s.c=push(&pool,s.c,pool.nodes[s.b].kind); POP(b); break;
                case OP_CPUSHN: NEED(p[1],0,0); for(unsigned j=0;j<p[1];j++){s.c=push(&pool,s.c,pool.nodes[s.a].kind);POP(a);} break;
                case OP_CPOP: NEED(0,0,1); if (pool.nodes[s.c].kind==ABC_KIND_BLOCK) BAD("CPOP cannot split a frame byte block"); POP(c); break;
                case OP_CGET0_A: case OP_CGET1_A: case OP_CGETN_A: case OP_CGET0_B: case OP_CGET1_B: case OP_CGETN_B: {
                    unsigned to_b=op>=OP_CGET0_B; uint32_t depth=(op==OP_CGET0_A || op==OP_CGET0_B) ? 0 : (op==OP_CGET1_A || op==OP_CGET1_B) ? 1 : p[1];
                    uint32_t slot=cslot(&pool,s.c,depth); if (!slot) BAD("CGET outside a scalar frame cell");
                    if (to_b) s.b=push(&pool,s.b,pool.nodes[slot].kind); else s.a=push(&pool,s.a,pool.nodes[slot].kind); break;
                }
                case OP_CGETR_A: case OP_CGETR_B: {
                    unsigned to_b=op==OP_CGETR_B; for(unsigned j=0;j<p[2];j++){uint32_t slot=cslot(&pool,s.c,p[1]+j);if(!slot)BAD("CGETR outside a scalar frame cell");if(to_b)s.b=push(&pool,s.b,pool.nodes[slot].kind);else s.a=push(&pool,s.a,pool.nodes[slot].kind);} break;
                }
                case OP_CSET0_A: case OP_CSETN_A: case OP_CSET0_B: case OP_CSETN_B: {
                    unsigned to_b=op==OP_CSET0_B || op==OP_CSETN_B; uint32_t depth=(op==OP_CSET0_A || op==OP_CSET0_B) ? 0 : p[1];
                    if (to_b) NEED(0,1,0); else NEED(1,0,0);
                    if (!cslot(&pool,s.c,depth)) BAD("CSET outside a scalar frame cell");
                    s.c=cset(&pool,s.c,depth,pool.nodes[to_b ? s.b : s.a].kind); if (to_b) POP(b); else POP(a); break;
                }
                case OP_JMP: case OP_JMP32: branch=terminal=1; break;
                case OP_SWITCH: NEED(1,0,0);INTEGER(a);POP(a);branch=2;break;
                case OP_JZ_A: case OP_JNZ_A: NEED(1,0,0); INTEGER(a); POP(a); branch=1; break;
                case OP_JZ_B: case OP_JNZ_B: NEED(0,1,0); INTEGER(b); POP(b); branch=1; break;
                case OP_BEQ: case OP_BNE: case OP_BLT: case OP_BLE: case OP_BLTU: case OP_BLEU:
                    NEED(1,1,0);
                    if ((op!=OP_BEQ && op!=OP_BNE) || pool.nodes[s.a].kind!=ABC_KIND_ADDR || pool.nodes[s.b].kind!=ABC_KIND_ADDR) { INTEGER(a); INTEGER(b); }
                    POP(a); POP(b); branch=1; break;
                case OP_FBLT: case OP_FBLE: case OP_FBEQ:
                    NEED(1,1,0); FLOAT(a); FLOAT(b); POP(a); POP(b); branch=1; break;
                case OP_CALL_A: case OP_CALL_B: case OP_TCALL:
                case OP_CALLI_A: case OP_CALLI_B: case OP_TCALLI: {
                    unsigned indirect=kind==K_ICALL || kind==K_ITCALL, tail=op==OP_TCALL || op==OP_TCALLI;
                    const abc_function *g=indirect ? abc_find_site(m,pc) : &m->functions[abc_find_function(m,(uint32_t)((int64_t)next+abc_i32(p+1)))];
                    if (indirect) { NEED(0,1,0); ADDRESS(b); POP(b); }
                    NEED(g->arguments,0,0);
                    if (tail && (DEPTH(a)!=g->arguments || s.b || DEPTH(c)!=p[indirect ? 1 : 5])) BAD("tail call must replace the complete frame and operand region");
                    for (uint32_t i=g->arguments;i;i--) { if (pool.nodes[s.a].kind!=g->argument_kinds[i-1]) BAD("call argument kind disagrees with function signature"); POP(a); }
                    if (tail) terminal=1;
                    else for (uint32_t i=0;i<g->results;i++) { if (op==OP_CALL_B || op==OP_CALLI_B) s.b=push(&pool,s.b,g->result_kinds[i]); else s.a=push(&pool,s.a,g->result_kinds[i]); }
                    break;
                }
                case OP_RET:
                    if (DEPTH(c)!=p[1] || s.b || p[2]!=f->results || !result_shape(&pool,s.a,f)) BAD("RET disagrees with frame or typed result contract (C %u/%u, B %u, A %u, results %u/%u)",DEPTH(c),(unsigned)p[1],DEPTH(b),DEPTH(a),(unsigned)p[2],f->results);
                    terminal=1; break;
                case OP_HALT:
                    if (s.c || s.b || !result_shape(&pool,s.a,f)) BAD("HALT must leave only declared results and an empty frame");
                    terminal=1; break;
                case OP_ABORT: terminal=1; break;
                default: if (kind==K_BRI) { NEED(1,0,0); INTEGER(a); POP(a); branch=1; } else BAD("unsupported instruction");
            }
            POOL_CHECK();
            uint32_t da=pool.nodes[s.a].depth,db=pool.nodes[s.b].depth,dc=pool.nodes[s.c].depth;
            if(da>f->max_a)f->max_a=da; if(db>f->max_b)f->max_b=db; if(dc>f->max_c)f->max_c=dc;
            unsigned ne=branch==2?(unsigned)abc_u16(p+1)+1u:(branch?1u:0u)+(!terminal?1u:0u);
            for(unsigned i=0;i<ne;i++){uint32_t edge;
                if(branch==2)edge=i<abc_u16(p+1)?(uint32_t)((int64_t)next+abc_i32(p+3+4*i)):next;
                else if(branch&&i==0)edge=(uint32_t)((int64_t)next+(kind==K_JMP32?abc_i32(p+1):abc_i16(p+(kind==K_BRI?2:1))));else edge=next;
                if(edge>=f->end)BAD("execution falls out of function");Shape *old=&shapes[edge];
                if (old->seen) { if (old->a!=s.a || old->b!=s.b || old->c!=s.c) BAD("incompatible kinds or live frame blocks at join"); }
                else { *old=s; old->seen=1; work[nw++]=edge; }
            }
            #undef DEPTH
            #undef NEED
            #undef INTEGER
            #undef FLOAT
            #undef ADDRESS
            #undef POP
        }
    }
done:
    free(starts); free(shapes); free(work); free(pool.nodes); free(pool.hash); return status;
    #undef BAD
    #undef NEED
#undef POOL_CHECK
}

abc_status abc_load_memory(const void *bytes,size_t size,abc_module **out,abc_error *e) {
    const uint8_t *p=bytes; const uint16_t endian=1;
    if (*(const uint8_t *)&endian!=1) return abc_fail(e,ABC_INVALID,UINT32_MAX,"memory profile requires little-endian host memory");
    unsigned profile=abc_u16(p+4),foreign=profile==4,callable=profile>=3,sections=foreign?9:callable?8:6;
    if(profile==5)return abc_fail(e,ABC_INVALID,UINT32_MAX,"dynamic profile 5 is unavailable in the typed-only VM");
    if ((profile<2||profile>4) || p[6]!=8 || p[7]!=profile || abc_u32(p+8)!=sections || abc_u32(p+12)) return abc_fail(e,ABC_INVALID,UINT32_MAX,"invalid memory/callable/foreign profile header");
    const uint8_t *sec[10]={0}; uint32_t len[10]={0}; size_t at=16;
    for (unsigned i=0;i<sections;i++) {
        if (size-at<8) return abc_fail(e,ABC_INVALID,UINT32_MAX,"truncated section header");
        uint32_t tag=abc_u32(p+at),n=abc_u32(p+at+4); at+=8;
        if (tag<1 || tag>sections || sec[tag] || n>size-at) return abc_fail(e,ABC_INVALID,UINT32_MAX,"invalid, duplicate or unsupported section");
        sec[tag]=p+at; len[tag]=n; at+=n;
    }
    if (at!=size || len[1]<4 || !len[2] || len[3]<4 || len[6]<4 || (callable && (len[7]<4 || len[8]<4)) || (foreign && len[9]<4)) return abc_fail(e,ABC_INVALID,UINT32_MAX,"missing sections or trailing bytes");
    uint32_t nf=abc_u32(sec[1]),nx=abc_u32(sec[3]),nk=abc_u32(sec[6]);
    uint32_t ns=callable ? abc_u32(sec[7]) : 0,nr=callable ? abc_u32(sec[8]) : 0,ne=foreign?abc_u32(sec[9]):0;
    if (!nf || nf>ABC_MAX_FUNCTIONS || nx>ABC_MAX_FUNCTIONS || ns>ABC_MAX_FUNCTIONS || nr>ABC_MAX_FUNCTIONS || ne>65535 || len[6]!=4+(uint64_t)nk*5 || (callable && len[8]!=4+(uint64_t)nr*8) || (uint64_t)len[4]+len[5]>ABC_MAX_FILE) return abc_fail(e,ABC_INVALID,UINT32_MAX,"invalid table or image size");
    abc_module *m=calloc(1,sizeof *m); if (!m) return abc_fail(e,ABC_NOMEM,UINT32_MAX,"module allocation failed");
    atomic_init(&m->references,1); m->memory_profile=1; m->callable_profile=callable; m->foreign_profile=foreign; m->function_count=nf; m->export_count=nx;
    m->site_count=ns; m->reloc_count=nr; m->extern_count=ne;
    m->code_size=len[2]; m->data_size=len[4]; m->image_size=len[4]+len[5];
    m->functions=calloc(nf,sizeof *m->functions); m->exports=calloc(nx ? nx : 1,sizeof *m->exports);
    m->code=malloc(len[2]); m->load_kinds=calloc(len[2],1); m->image=malloc(m->image_size ? m->image_size : 1);
    abc_status status=ABC_INVALID;
    #define FAIL(...) do { status=abc_fail(e,ABC_INVALID,UINT32_MAX,__VA_ARGS__); goto failed; } while(0)
    if (!m->functions || !m->exports || !m->code || !m->load_kinds || !m->image) { status=abc_fail(e,ABC_NOMEM,UINT32_MAX,"module allocation failed"); goto failed; }
    memcpy(m->code,sec[2],len[2]); memcpy(m->image,sec[4],len[4]); memcpy(m->image+len[4],sec[5],len[5]);
    at=4;
    for (uint32_t i=0;i<nf;i++) {
        if (len[1]-at<16) FAIL("truncated function signature");
        const uint8_t *q=sec[1]+at; abc_function *f=&m->functions[i];
        f->entry=abc_u32(q); f->arguments=abc_u32(q+4); f->results=abc_u32(q+8); f->hidden_bytes=abc_u32(q+12); at+=16;
        if ((i==0 && f->entry) || f->entry>=len[2] || (i && f->entry<=m->functions[i-1].entry) || f->arguments>255 || f->results>255 || f->hidden_bytes>ABC_MAX_FILE || f->arguments+f->results>len[1]-at) FAIL("invalid function entry/count or hidden result size");
        memcpy(f->argument_kinds,sec[1]+at,f->arguments); at+=f->arguments; memcpy(f->result_kinds,sec[1]+at,f->results); at+=f->results;
        for (uint32_t j=0;j<f->arguments;j++) if (!value_kind(f->argument_kinds[j])) FAIL("unsupported argument kind");
        for (uint32_t j=0;j<f->results;j++) if (!value_kind(f->result_kinds[j])) FAIL("unsupported result kind");
        if (f->hidden_bytes && (!f->arguments || f->argument_kinds[0]!=ABC_KIND_ADDR)) FAIL("hidden aggregate result requires first argument address");
        if (i) m->functions[i-1].end=f->entry;
    }
    if (at!=len[1]) FAIL("trailing function signature bytes");
    m->functions[nf-1].end=len[2]; at=4;
    for (uint32_t i=0;i<nx;i++) {
        if (len[3]-at<6) FAIL("truncated export");
        uint32_t index=abc_u32(sec[3]+at); unsigned n=abc_u16(sec[3]+at+4); at+=6;
        if (index>=nf || !n || n>255 || n>len[3]-at) FAIL("invalid export name or index");
        for (unsigned j=0;j<n;j++) { unsigned ch=sec[3][at+j];
            if (!(ch=='_' || (ch>='a' && ch<='z') || (ch>='A' && ch<='Z') || (j && ch>='0' && ch<='9'))) FAIL("export names must be ASCII identifiers");
        }
        m->exports[i].name=malloc(n+1); if (!m->exports[i].name) { status=abc_fail(e,ABC_NOMEM,UINT32_MAX,"export allocation failed"); goto failed; }
        memcpy(m->exports[i].name,sec[3]+at,n); m->exports[i].name[n]=0; m->exports[i].function=index; at+=n;
        for (uint32_t j=0;j<i;j++) if (!strcmp(m->exports[j].name,m->exports[i].name)) FAIL("duplicate export name");
    }
    if (at!=len[3]) FAIL("trailing export bytes");
    for (uint32_t i=0;i<nk;i++) {
        const uint8_t *q=sec[6]+4+i*5; uint32_t offset=abc_u32(q); unsigned kind=q[4];
        if (offset>=len[2] || !value_kind(kind) || m->load_kinds[offset]) FAIL("invalid or duplicate load kind annotation");
        m->load_kinds[offset]=(uint8_t)(kind+1);
    }
    if (callable) {
        m->sites=calloc(ns ? ns : 1,sizeof *m->sites); m->relocs=calloc(nr ? nr : 1,sizeof *m->relocs);
        if (!m->sites || !m->relocs) { status=abc_fail(e,ABC_NOMEM,UINT32_MAX,"callable table allocation failed"); goto failed; }
        at=4;
        for (uint32_t i=0;i<ns;i++) {
            if (len[7]-at<16) FAIL("truncated indirect signature");
            const uint8_t *q=sec[7]+at; abc_function *s=&m->sites[i];
            s->entry=abc_u32(q); s->arguments=abc_u32(q+4); s->results=abc_u32(q+8); s->hidden_bytes=abc_u32(q+12); at+=16;
            if (s->entry>=m->code_size || (i && s->entry<=m->sites[i-1].entry) || !s->arguments || s->arguments>255 || s->results>255 || s->hidden_bytes>ABC_MAX_FILE || s->arguments+s->results>len[7]-at) FAIL("invalid indirect signature offset/count");
            memcpy(s->argument_kinds,sec[7]+at,s->arguments); at+=s->arguments; memcpy(s->result_kinds,sec[7]+at,s->results); at+=s->results;
            for (uint32_t j=0;j<s->arguments;j++) if (!value_kind(s->argument_kinds[j])) FAIL("unsupported indirect argument kind");
            for (uint32_t j=0;j<s->results;j++) if (!value_kind(s->result_kinds[j])) FAIL("unsupported indirect result kind");
            if (s->argument_kinds[0]!=ABC_KIND_ADDR) FAIL("indirect signature needs environment address as first argument");
        }
        if (at!=len[7]) FAIL("trailing indirect signature bytes");
        for (uint32_t i=0;i<nr;i++) {
            const uint8_t *q=sec[8]+4+i*8; abc_code_reloc *r=&m->relocs[i]; r->offset=abc_u32(q); r->function=abc_u32(q+4);
            if ((uint64_t)r->offset+8>m->data_size || r->function>=nf || (i && r->offset<(uint64_t)m->relocs[i-1].offset+8)) FAIL("invalid or overlapping code image relocation");
        }
    }
    if (foreign) {
        m->externs=calloc(ne?ne:1,sizeof *m->externs); if(!m->externs){status=abc_fail(e,ABC_NOMEM,UINT32_MAX,"extern allocation failed");goto failed;}
        at=4; for(uint32_t i=0;i<ne;i++) {
            if(len[9]-at<4) FAIL("truncated extern signature"); abc_extern *ext=&m->externs[i]; ext->arguments=sec[9][at]; ext->results=sec[9][at+1]; unsigned nn=abc_u16(sec[9]+at+2); at+=4;
            if(ext->arguments>10||ext->results>1||!nn||nn>255||(uint64_t)ext->arguments+ext->results+nn>len[9]-at) FAIL("invalid extern signature");
            unsigned ni=0,nf64=0; for(unsigned j=0;j<ext->arguments;j++){unsigned k=sec[9][at+j];if(!value_kind(k))FAIL("invalid extern argument kind");if(k==ABC_KIND_FLOAT)nf64++;else ni++;ext->argument_kinds[j]=(uint8_t)k;} at+=ext->arguments;
            if(ni>6||nf64>4) FAIL("extern exceeds C ABI argument limits");
            if(ext->results){unsigned k=sec[9][at++];if(!value_kind(k))FAIL("invalid extern result kind");ext->result_kinds[0]=(uint8_t)k;}
            ext->name=malloc(nn+1);if(!ext->name){status=abc_fail(e,ABC_NOMEM,UINT32_MAX,"extern name allocation failed");goto failed;} memcpy(ext->name,sec[9]+at,nn);ext->name[nn]=0;
            for(unsigned j=0;j<nn;j++){unsigned ch=(unsigned char)ext->name[j];if(!(ch=='_'||(ch>='a'&&ch<='z')||(ch>='A'&&ch<='Z')||(j&&ch>='0'&&ch<='9')))FAIL("extern names must be ASCII identifiers");} at+=nn;
            for(uint32_t j=0;j<i;j++)if(!strcmp(m->externs[j].name,ext->name))FAIL("duplicate extern name");
        } if(at!=len[9])FAIL("trailing extern bytes");
    }
    status=verify_memory(m,e); if (status!=ABC_OK) goto failed; *out=m; return ABC_OK;
failed: abc_module_free(m); return status;
    #undef FAIL
}

