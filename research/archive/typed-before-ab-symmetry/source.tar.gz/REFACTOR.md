# ABC VM and JIT refactor target

## Status and latest decisions

This document records the redesign target, not the current executable ISA. The isolated typed engine builds and its active validation passes, including the capture correction. Those results predate the symmetric-ISA migration and do not validate the new semantics described here.

- **A and B are semantically symmetric.** `.X` selects the relevant operand stack. A binary `OP.X` computes `X0 op Y0`, where Y is the other stack, and leaves its result on X. A and B have no permanent left/right roles.
- **C remains structured state.** Reads from C select their A/B destination; writes to C select their A/B source. Only operations touching neither operand stack are stack-neutral.
- **Bytecode quickening is deferred.** The immediate encoding design reserves no slots for internal quickened opcodes. Keep the existing ahead-of-time cache-state interpreter machinery; it is not bytecode quickening.
- **Observations and native specialization remain separate.** VM-local site state need not rewrite bytecode. Native residualization selects stencils directly from immutable instruction operands and proven facts; it does not need a bytecode quickening phase.
- **Symmetric calls are specified below as the proposed end-to-end contract.** `CALL.X` selects the caller's argument/result channel; `RET.Y` selects the callee's result source. This requires no implicit bank-orientation mode or mirrored function bodies.
- **The concrete ISA design is now specified for approval in [docs/symmetric-isa.md](docs/symmetric-isa.md).** The complete byte map has 124 ordinary A/B families, EXT.A/EXT.B and six neutral instructions. Four C-operand arithmetic and ten immediate-branch families use EXT. Revision 6 is independent of capability profiles 1–4; indirect calls no longer serialize cache words. This is a design proposal, not implemented or approved encoding.

The runtime, producers, verifier, `docs/spec.md` and project instruction text still require a coordinated migration. This document does not claim that migration, caller-owned region accounting, shared-site dispatch or lazy bytecode execution has been implemented. The experimental private return-layout change remains unadopted.

## Execution strategy and implementation checklist

### Governing rule

**Replace the assumption, finish the responsibility, delete the old path, then validate the boundary.**

The working strategy is agreed; the exact opcode allocation and end-to-end call/encoding contract still require approval before runtime implementation. The checkboxes below track the migration, not the already validated old-semantics checkpoint. The architecture sections following this plan explain the target; they do not expand the scope of an implementation phase automatically.

### Instructions for every implementation chunk

- Work by coherent responsibility and contract, not by the smallest possible diff. Prefer replacing an entire organizing section or file when its assumptions change; preserve correct algorithms and unrelated user work.
- Trace authoritative definitions, producers, consumers and relevant tests before editing. List the files and obsolete assumptions that the chunk replaces.
- Keep one authoritative semantic definition. Generate bindings from it rather than writing independent A and B algorithms or backend-specific semantic repairs.
- Delete replaced implementations, dead variants and obsolete orchestration in the same chunk. Do not retain the old implementation beneath a new facade.
- Do not introduce adapters, compatibility modes, opaque fallbacks, new allocators or new subsystems without discussing a material design change first.
- Keep changes within the approved scope. No opportunistic cleanup or new scheduling optimizations during the semantic migration.
- Temporary build breakage inside a coordinated chunk is acceptable. Record it plainly; do not mark that chunk complete or preserve an incorrect compatibility layer solely to make an intermediate build green.
- Build and run the relevant checks at coherent boundaries, not after each edit. Diagnose failures before repeating suites indiscriminately.
- Preserve explicit ABC continuations, capture/liveness, result order, escaped storage, traps and the agreed stack-capacity policy.
- Do not silently switch to a new return-slot layout or host-recursive ABC execution.
- Do not use subagents or internal edit-plan sidecars without a separate explicit request. This file is the checklist.

Before a chunk, record its scope and expected exit condition. Afterward, record changed responsibilities, removed paths, checks actually run and their outcomes. Check a box only when that specific item is complete; use a short blocked/partial note otherwise. A passing output test is not evidence that an obsolete abstraction was removed.

### C naming and defensive-code policy

Prefer descriptive responsibility names, especially where multiple stack roles coexist:

```c
selected_stack
opposite_stack
return_result_source_stack
continuation_result_destination
capture_value_before_home_replacement()
```

Avoid ambiguous abbreviations such as `s`, `rs` or `fix()` for these roles. Names should explain what a value or operation means and, where useful, why it exists. Put deeper rationale and invariants in comments rather than making names narrate every implementation step. Established mathematical notation and fixed ABI names remain appropriate in their local contexts; do not perform unrelated renaming sweeps.

Validate at trust boundaries; rely on established invariants internally. Module verification, indirect target/ABI validation, allocation limits, required traps and effect boundaries are real obligations. Rechecking verifier guarantees throughout hot execution, speculative fallback paths and defensive layers for impossible states are not the default design. Use focused assertions where they help expose implementation errors without inventing new runtime behavior.

### Phase 0 — Freeze scope and baseline

- [ ] Record and preserve the exact dirty typed checkpoint, including relevant untracked files; do not use HEAD alone as the baseline or overwrite existing work.
- [ ] Record the known passing validation commands/logs. Reuse existing evidence where applicable rather than rerunning the entire suite merely to begin planning.
- [ ] Select a small fixed performance set and commands covering arithmetic, calls/recursion, branches and memory. Capture the baseline before changing runtime behavior.
- [ ] Scope this migration to symmetric typed execution, coordinated producers/consumers and removal of bytecode quickening.
- [ ] Explicitly exclude dynamic reintegration, caller-owned region implementation, new lazy-bytecode execution, pressure-driven evaluation reordering and the experimental physical return ABI.

**Exit:** reproducible reference state and bounded scope. The broader JIT target remains documented, not bundled into this migration.

### Phase 1 — Finalize the machine contract and encoding

Primary areas: `tools/opcodes.lua`, `gen/semantics.lua`, `docs/spec.md`, module/callable/foreign format contracts and the verification rules they imply.

- [x] Inventory every public instruction family, operand layout, stack effect and mirrored semantics. Evidence: `docs/symmetric-isa.md` covers the 145 existing typed families, including C/memory/control operations and host entry/exit.
- [x] Specify the proposed direct, indirect, tail, foreign and return contracts end to end. Evidence: the ISA design defines argument source, vector/C order, result source, continuation destination and protected prefixes. User approval is still pending.
- [x] Allocate the proposed 256-entry core opcode map without quickening reservations. Evidence: 124 ordinary pairs + two EXT prefixes + six neutral bytes; fourteen named families receive explicit EXT selectors. No typed operation is removed.
- [x] Specify the proposed module revision independently of capabilities. Evidence: revision 6, profiles 1–4, regenerated producers/offsets, no old-semantic compatibility engine; four serialized cache bytes are removed from each indirect call.
- [ ] Trace every existing bytecode quickening dependency. Distinguish opcode rewriting from cache-state handlers, indirect-site observation and native linkage; identify what is deleted and what still must execute correctly.
- [ ] Identify any minimum observing-site change required to remove opcode rewriting. Present it explicitly; do not silently pull in the broader region/site redesign.
- [ ] Present the concrete contract, file ownership and encoding to the user and obtain approval before implementation.

**Exit:** no unresolved operand-role, call-interface or encoding questions delegated to coding. If later inspection exposes a material incompatibility, stop and return to this gate.

### Phase 2 — Replace definitions and concrete execution

Primary areas: `tools/opcodes.lua`, `tools/gen_opcodes.lua`, `tools/assembler.lua`, `gen/semantics.lua`, `gen/banked.lua`, `gen/cache.lua`, relevant cold/foreign generation, `src/module.c`, `src/memory_module.c`, `src/vm.c` and their interfaces. This is a responsibility map, not permission to rewrite files whose responsibilities have not changed.

- [ ] Replace authoritative instruction definitions with selected-stack contracts; generate their decoding/metadata rather than duplicating the new map.
- [ ] Generate mirrored interpreter bindings and cache transitions from one semantic operation definition.
- [ ] Update assembly, disassembly, decoding and verification together, including revision handling and target/result kinds.
- [ ] Implement symmetric argument gathering, frame transport and return-result source selection without changing the approved physical continuation ABI.
- [ ] Remove internal quickened opcode variants, their rewriting paths and now-dead metadata; preserve required target validation and observation behavior.
- [ ] Retain the ahead-of-time cache-state interpreter, capture/liveness behavior and explicit control transfers.
- [ ] Build the affected runtime/tooling targets and run the focused interpreter contract cases.

**Exit:** hand-written new-ISA programs run correctly in the interpreter; the concrete layer does not retain the old semantics as an alternative path. Downstream migration still pending is recorded explicitly, not hidden behind shims.

### Phase 3 — Replace symbolic and residual bindings

Primary areas: `gen/symbolic.lua`, `src/symbolic.{c,h}`, `src/residualize.c`, `gen/stencils.lua`, `src/optimize.c`, `src/residual_builder.c`, residual analysis/validation and ABC/C emission, with their declared interfaces.

- [ ] Make selected-stack-first operand ordering authoritative in symbolic execution, folding and callback contracts.
- [ ] Parameterize call argument gathering and return-result sources; keep the continuation destination distinct.
- [ ] Bind native operations directly to selected/other registers through the existing cache allocation state.
- [ ] Remove reverse stencil families and B-only fusion exceptions whose sole purpose was the old A-left convention; retain any independently justified operation forms.
- [ ] Update optimizer, residual ABC and portable-C producers/consumers consistently. No backend-only repacking adapter for the old semantics.
- [ ] Preserve the capture fix, consumed-operand liveness and existing error propagation; do not add a second value IR, allocator or transport scheduler.
- [ ] Build the affected targets and run focused interpreter/native/tooling equivalence checks, including both destinations and capture regressions.

**Exit:** concrete and residual execution share the new contract, with obsolete native orientation machinery removed. The result is not merely a manifest edit or a working facade over old internals.

### Phase 4 — Replace frontend lowering

Primary areas: `frontend/let/abc.lua`, affected frontend/staging producers, active assembly examples and relevant compiler/lowering/optimizer fixtures.

- [ ] Implement destination-parametric expression lowering with preservation of live prefixes on both stacks.
- [ ] Lower reversed comparisons by operand placement while preserving source evaluation order and floating-point NaN behavior.
- [ ] Update calls, conversions, checks, C transfers and memory operations to the new instruction contracts.
- [ ] Delete obsolete A/B lowering special cases and moves whose only purpose was repairing the old operand orientation.
- [ ] Regenerate active fixtures/examples and update their independent expectations; preserve archived old-format evidence as historical material.
- [ ] Keep unsupported dynamic execution clearly separated. Do not reinstate an A-only dynamic contract or claim that frontend-only checks validate a dynamic runtime.
- [ ] Run focused frontend end-to-end cases through the supported execution modes and applicable tooling sinks.

**Exit:** frontend-produced typed programs exercise the new ISA end to end. Parametric placement is implemented; new Ershov scheduling/evaluation reordering remains a separately approved optimization follow-up.

### Phase 5 — Close the migration

- [ ] Run the full active validation suite after integration. Rerun affected checks if subsequent fixes alter their contracts; do not treat an earlier pass as covering later edits.
- [ ] Run the fixed performance comparison against the preserved typed baseline, with the same tools and workloads.
- [ ] Audit for old A-left/A-only assumptions, quickened opcode paths, dead reverse families, duplicated semantics and hidden adapters.
- [ ] Align `docs/spec.md`, format/profile documentation, project instructions and this file with what is actually implemented and validated.
- [ ] Report code/metadata size, interpreter and native performance changes, incomplete work and untested paths. Distinguish structural expectations from measurements.
- [ ] Review the complete migration diff for unrelated changes and preserve user work.

**Exit:** a coherent new-ISA checkpoint with evidence, not a collection of partial patches. Resume the broader JIT redesign only as a separate approved phase.

### Validation budget and completion evidence

Use a small decisive contract set during implementation:

- mirrored noncommutative arithmetic, correct divisor/shift count/exponent and representative comparisons;
- live-prefix preservation, mutable-HOME capture and full-bank/spill transitions;
- all four CALL.X/RET.Y combinations, ordered multiple results and preserved continuations;
- representative indirect, tail and foreign calls;
- selected-stack C/memory transfers, conversions and checks;
- representative traps, stack limits and source provenance.

Reuse and adapt existing validators where they already cover the contract. Add missing architectural cases rather than creating overlapping suites. Run the relevant subset at each chunk boundary and the full active suite at integration. A generator and tests derived from that same generator are not independent evidence: retain explicit expected results and mirrored execution checks.

Measure baseline/final performance rather than benchmarking every intermediate edit. Investigate unexpected regressions with targeted measurements. Record preparation time, steady-state time, emitted code/handler bytes and relevant transport/dispatch counts separately; do not claim that fewer source definitions necessarily mean less emitted code or faster execution.

Suggested chunk completion record:

```text
Chunk:
Contract replaced:
Files/responsibilities changed:
Old paths removed:
Checks run and outcome:
Performance evidence, if relevant:
Remaining work or design questions:
```

---

## Architectural target

 The redesign should make the fast core the center of the architecture, not a backend hidden underneath an increasingly elaborate JIT.

 Here is the target for the specification, building on the validated typed engine—not a claim that every part is already implemented.

 The governing idea is:

 │ Execute the shared ABC semantics with symbolic values. Let the existing cache determine placement. Emit the remaining work directly into the chosen target.

 Everything else exists to establish valid entry facts, connect those emitted pieces, and bound specialization.

 ────────────────────────────────────────────────────────────────────────────────

 1. The whole machine

 There are two ways to execute the instruction semantics:

 ```text
                              ABC instruction semantics
                                         │
                       ┌─────────────────┴─────────────────┐
                       ▼                                   ▼
                concrete execution                  symbolic execution
                       │                                   │
            values in the stack cache           constants, captured values,
                       │                         homes, proofs and placement
                       ▼                                   │
             interpreter handlers              ┌───────────┼───────────┐
                                               ▼           ▼           ▼
                                              ABC        native        C
                                            bytecode    stencils
 ```

 The interpreter and residualizer are not independent implementations of the language.

 They differ in what they know:

 ```text
   Interpreter:
       A0 contains 40.
       B0 contains 2.
       Execute the addition.

   Residualizer:
       A0 is the value held in r3.
       B0 is the known constant 2.
       Emit an add-immediate stencil.

   Residualizer, stronger facts:
       A0 is known to be 40.
       B0 is known to be 2.
       Record the constant 42; emit no addition.
 ```

 The native path is deliberately short:

 ```text
   verified ABC + entry contract
                │
                ▼
   shared symbolic instruction execution
                │
                ├── update stack names and cache placement
                ├── fold proven computations
                ├── preserve checks and effects that remain
                └── copy and patch register-addressed stencils
 ```

 abc-opt is not a prerequisite. It may improve the bytecode beforehand, but the runtime must accept verified ABC without invoking the build-time optimizer.

 The ABC and C sinks may use their own build-time representations. Those representations must not become an intermediate stage in native stencil emission.

 ────────────────────────────────────────────────────────────────────────────────

 2. Why ABC gives this compiler so much for free

 The architecture should begin with the machine, rather than with a generic compiler diagram.

 ```text
   Selected stack X          Other stack Y
   ┌──────────────┐          ┌───────────────┐
   │ left operand │ X0       │ right operand │ Y0
   └──────────────┘          └───────────────┘
              \                 /
               \   operation   /
                └──────┬──────┘
                       │
                  result on X

   .A selects X=A, Y=B
   .B selects X=B, Y=A

   C
   ┌─────────────────────────┐
   │ bindings                │
   │ frame blocks            │
   │ arguments               │
   │ explicit continuations  │
   └─────────────────────────┘
 ```

 For a binary operation:

 ```text
   SUB.A:
       result = A0 - B0
       consume both operands
       put result on A

   SUB.B:
       result = B0 - A0
       consume both operands
       put result on B
 ```

 `.X` selects the primary operand stack, not merely the result destination. Operand order is always selected stack first, other stack second. The same orientation applies to division, remainder, shifts, powers, floating-point operations and comparisons.

 ```text
   SUB.X:     X0 ← X0 - Y0
   SUBI.X k:  X0 ← X0 - k
   SUBC.X d:  X0 ← X0 - C[d]
 ```

 These are operand forms of one semantic operation. Dynamic scalar operations must use the same selected-stack-first rule, not two operands on A or B forms implemented by repacking through A.

 C reads and writes are symmetric with respect to the operand stacks:

 ```text
   CGET.A d:  A.push(C[d])       CGET.B d:  B.push(C[d])
   CPUSH.A:   C.push(A.pop())   CPUSH.B:   C.push(B.pop())
   CSET.A d:  C[d] = A.pop()    CSET.B d:  C[d] = B.pop()
 ```

 CGET/CGETR and frame-address/load forms select an A/B destination. CPUSH/CPUSHN, CSET and frame stores select an A/B source. C itself is not exchanged with either operand stack. CPOP, CALLOC, CFREE, unconditional jumps and aborts are stack-neutral.

 The remaining families follow the same explicit orientation:

 | Family | Selected-stack contract, with Y opposite X |
 | --- | --- |
 | Unary, conversion, normalization, check `.X` | Operate on X0 |
 | Binary branch `.X` | Consume and compare X0 against Y0 |
 | Immediate branch `.X` | Consume and compare X0 against the immediate |
 | SWITCH.X | Consume the selector from X |
 | GLD.X / GST.X | Load onto / store from X |
 | LD.X | Address and loaded result on X |
 | ST.X | Address on X, value on Y; consume both |
 | IDX.X / LDX.X | Base on X, index on Y, result on X |
 | MEMCPY.X | Destination address on X, source address on Y |
 | HALT.X | Supply host-entry results from X under the verified halt contract |

 These are target contracts, not assertions that the mirrored opcode forms already exist. Source evaluation order is unchanged: placement choices must not reorder effects, checks or traps.

 The symmetry law is: exchanging A and B in the program and machine state, including continuation destination selectors, produces the corresponding exchanged execution. It does not exchange C's role or require identical physical register assignments or timings.

 The compiler already knows:

 - which values an instruction reads;
 - which operand cells it consumes;
 - where its result belongs;
 - which C locations it accesses;
 - the verified stack shape at control-flow boundaries.

 It therefore does not have to recover those properties from an unstructured instruction stream.

 The symbolic cache is already the allocation state.

### Parametric expression lowering

 Symmetry replaces A-shaped and B-shaped lowering cases with one destination-parametric rule:

 ```text
   compile(left op right, dst):
       compile(left, dst)
       compile(right, other(dst))
       emit OP.dst
 ```

 This applies to noncommutative operations too. There is no reverse-operation case for a B destination, and no MOVE whose purpose is to repair the old permanent-A-left operand convention.

 The recursive contract is essential: compile(E, dst) produces E's result on dst while preserving pre-existing live operand values on both stacks. The existing cache owns capture, alias preservation and spills. Necessary transport for those obligations, calls, returns and edge conformance does not disappear.

 Greater-than needs no extra comparison or operand-order repair:

 ```text
   compile(a > b, dst):
       compile(a, other(dst))   // evaluate a first
       compile(b, dst)          // evaluate b second
       emit LT.dst             // compute b < a
 ```

 Likewise, a >= b uses b <= a. Use the corresponding signed, unsigned or floating-point comparison. In particular, floating-point greater-than is a reversed less-than, not a negated less-or-equal: NaN behavior must be preserved. Operand placement is independent of evaluation order; reversing the comparison does not authorize evaluating b before a.

### The two cached tops are the binary-operation interface

 Relative roles connect expression lowering directly to the divided stack cache:

 ```text
   left   = top(me)
   right  = top(other)
   result replaces top(me)
   consume top(other), exposing its next value
 ```

 Both stack tops have a useful role in every two-stack binary computation. When both operands are resident and the selected register is safely writable, the operation binds directly to `selected_register OP= other_register`. There is no rearrangement merely to repair operand orientation.

 Recursive me/other lowering naturally distributes intermediate values across the banks. For example, compile a - (b - c) into A, preserving evaluation order:

 ```text
   evaluate a → A
   evaluate b → B
   evaluate c → A     // above the preserved a
   SUB.B              // b - c on B; exposes a on A
   SUB.A              // a - (b - c) on A
 ```

 Divided stacks, destination-parametric lowering, cached tops and destructive native operations therefore reinforce one another. This is a structural benefit, not a guarantee of optimal balance or minimum register pressure. Tree shape and live prefixes still matter; aliases may require capture, and deeper values may require spills or refills. Caching both tops does not mean replacing the existing bank with only two registers. No new allocator or scheduling pass is implied.

### One handler definition, mirrored bank bindings

 The existing operand bank has A anchored at h0 and B at h3. Its mirror transformation is:

 ```text
   selected stack:  A ↔ B
   cache counts:    (a, b) ↔ (b, a)
   bank registers: h[i] ↔ h[3-i]   for i = 0..3
   C state:        unchanged
 ```

 Generate the selected-stack operation once and derive both bindings, including their cache-state transitions and operand-home accesses. Do not maintain a separately handwritten B algorithm. The transformation applies to operand-bank registers, not to all native ABI registers or C's cache registers. Continuation destination selectors mirror where the instruction contract requires them.

 This removes a class of B-only semantic and placement drift by construction. Mirrored-state execution tests must still check the generator and its bindings; generated code is not its own correctness oracle.

 In this sense the compiler and generator's A/B-specific logic halves: two directional implementations collapse into one parametric definition. This is not a promise that the entire compiler or emitted handler text halves. Distinct concrete cache-state handlers still exist. Removing reverse native stencil families required solely by the old operand convention is a separate code-size opportunity to measure.

### Ershov scheduling without a privileged side

 Subtree pressure can guide scheduling independently of operand-bank identity. For example, if the right subtree is heavier and evaluation reordering is proven safe:

 ```text
   compile(right, other(dst))
   compile(left, dst)
   emit OP.dst
 ```

 The results are already on their semantic sides even though the right subtree was evaluated first. Either stack can hold the heavier subtree; neither has a permanently privileged position in the operation.

 Ershov-style pressure estimates inform the existing compiler's scheduling; they do not introduce another allocator or override the symbolic cache's placement state. Classical single-pool estimates are not by themselves a complete cost model for the divided stacks and live prefixes. Preserve required effect and trap order, including resource-failure behavior under the agreed policy; purity alone is not sufficient proof that reordering is harmless. Compare actual spills, captures, transport and execution costs before claiming a scheduling improvement.

### Encoding: compact public operations first

 The complete proposed allocation and instruction layouts are in [the revision-6 ISA design](docs/symmetric-isa.md). The map fits exactly:

 ```text
   00–F7: 124 ordinary selected-stack families, even=A / odd=B
   F8/F9: EXT.A / EXT.B; followed by one family-selector byte
   FA–FF: six neutral operations, with no bank selector

   124 × 2 + 2 + 6 = 256 core bytes
 ```

 Neutral bytes encode CPOP, CALLOC, CFREE, JMP, JMP32 and ABORT individually, rather than wasting a pair on each. All selected core operations use bit 0 consistently. CGET.A and CGET.B are one family with two destinations, and their short-depth forms remain in the core.

 The existing manifest has 145 public typed families after pairing. All are represented: 124 ordinary core families + one EXT family + six neutral families + fourteen extended families. ADDC/SUBC/MULC/XORC and the ten immediate-branch relations receive EXT selectors 00–0D. Their one extra operation byte and interpreter dispatch cost are explicit trade-offs to measure, not assumed negligible. Ordinary integer/float comparisons and fused two-stack branches retain direct core encodings.

 This is a one-byte core ISA, not a claim that all historical fused forms have a single-byte operation encoding. No extra bank mode, quickened variant or hidden A-only execution path is introduced. The exact allocation is specified but still requires approval before implementation.

 **No opcode slots are reserved for bytecode quickening in this design stage.** Do not add internal arity, signature-shape or observed-target opcode families merely to preserve the old quickening scheme. EXT remains an escape for extended operations, not a reason to add a new rejection subsystem. No new dynamic selectors or guard encodings are allocated by this document.

 The new meaning of SUB.B and CALL.B is incompatible with old bytecode. The proposal assigns module revision 6 with independent profiles 1–4, retains the existing profile-specific metadata layouts and regenerates code offsets and active fixtures. CALLI/TCALLI lose their four-byte mutable cache field; immutable signatures and VM-local observing state remain. Old modules are not reinterpreted under the new rules or executed through a compatibility engine. The complete byte layouts and migration policy are specified in the linked ISA design.

 ────────────────────────────────────────────────────────────────────────────────

 3. Keep three identities separate

 This is important enough to make explicit in the spec.

 ┌─────────────────────┬───────────────────────────────────────────────────────────┐
 │ Identity            │ Answers                                                   │
 ├─────────────────────┼───────────────────────────────────────────────────────────┤
 │ Source origin       │ Which original ABC instruction is this?                   │
 ├─────────────────────┼───────────────────────────────────────────────────────────┤
 │ Region owner        │ Whose specialization budget pays for this emitted code?   │
 ├─────────────────────┼───────────────────────────────────────────────────────────┤
 │ Local control point │ Where are we inside this particular residual realization? │
 └─────────────────────┴───────────────────────────────────────────────────────────┘

 They are not interchangeable.

 Suppose main inlines helper twice:

 ```text
   main region, version 2
       ...
       first inline copy of helper
           original helper PC 0x120
       ...
       second inline copy of helper
           original helper PC 0x120
 ```

 Those two instructions have:

 - the same source origin;
 - the same region owner;
 - different local control points because their continuations differ.

 Consequences:

 - Traps still report original PC 0x120.
 - An observing instruction at that PC still refers to one shared site history.
 - The two inline copies do not consume the standalone helper’s version budget.
 - Their branches and returns cannot be confused merely because their original PCs match.

 The local distinction can use the existing virtual-continuation path. It does not require a new value IR.

 ────────────────────────────────────────────────────────────────────────────────

 4. Caller-owned residual regions

 This is the substantial correction to the old “eight versions per callee block” rule.

 What a region is

 I propose this definition:

 │ A residual region is a compilation unit rooted at a declared entry in the caller’s original control flow. A region realization includes the internal control flow of the acyclic callees it virtualizes.

 A straight-line caller can therefore include several calls:

 ```text
   Region R, rooted in caller A

       caller computation
       CALL helper_B       ── virtualized
           B's computation
           B's branch
           B's join
           RET
       caller computation
       CALL helper_C       ── virtualized
           C's computation
           RET
       caller branch       ── edges to successor regions
 ```

 A practical boundary rule is:

 - Original function entries and ordinary caller control-flow entries provide region roots.
 - A virtual call and its matching return do not, by themselves, create a new owner.
 - Control flow inside an inlined activation remains owned by the enclosing region.
 - A real call transfers into independently compiled callee code; its return resumes the existing caller realization.
 - Caller control-flow exits connect to successor region entries.

 That gives caller ownership a concrete meaning without making an entire program one region.

 What consumes a slot

 ```text
   Owner: (VM/module instance, region root R)

       slot 0: general realization
       slot 1: specialized realization
       slot 2: specialized realization
       ...
       slot 7: specialized realization
 ```

 A realization consumes one slot. Its constituent blocks do not each consume another slot.

 ```text
   R, specialization 1
       caller block
       inline B
           3 internal blocks
           inline C
               2 internal blocks
       inline D
           5 internal blocks

   Total: one region realization
   Not: eleven versions charged separately
 ```

 Twenty known small helpers can belong to one realization.

 Another caller has its own owner:

 ```text
   Caller A ── owns its inline copies of helper
   Caller B ── owns its inline copies of helper
   Caller C ── owns its inline copies of helper

   helper's standalone owner
       covers separately entered helper code
 ```

 This removes the cross-caller cliff.

 It does not make all specialization order irrelevant: the first seven distinct specialized arrival contracts at one owner can still depend on eager scheduling or lazy arrival order. What disappears is competition between unrelated callers of a
 popular helper.

 No hidden internal version families

 There is an essential companion rule:

 │ Internal labels are not independent, unlimited specialization tables.

 Within one realization, arrivals at the same local control point must converge on compatible contracts. Branches merge facts; loops widen changing facts.

 An interior observation does not silently create an unbudgeted family of native blocks. New externally selectable entries require an explicit region boundary and ownership rule.

 This is how “a large realization counts once” avoids becoming a loophole.

 ────────────────────────────────────────────────────────────────────────────────

 5. An entry contract is a proof obligation

 A version’s contract describes what must be true when that version is entered.

 Conceptually:

 ```c
   struct EntryContract {
       VerifiedStackShape shape;
       SymbolicCache placement;
       ProvenFacts facts;
       ContinuationContract continuation;
   };
 ```

 These names illustrate the responsibilities. They are not a proposal for another collection of runtime value objects.

 The facts can include:

 ```text
   A0:
       captured value in r3
       exact constant unknown
       represented as raw integer bits
       upper 32 bits proven zero

   B0:
       exact constant 7

   C2:
       aliases the same captured value as A0

   call target:
       exact function F, with this site's ABI validated
 ```

 Things that do not belong in the contract:

 ```text
   "this site was monomorphic last time"
   "the first sample happened to be a u32"
   "this block has executed 200 times"
 ```

 An observation can suggest which contract is worth compiling. It cannot establish that contract for subsequent arrivals.

 Compatibility first, conformance second

 Suppose a target requires:

 ```text
   value x: normalized u32 in r1
   value y: arbitrary integer in r4
 ```

 An arrival provides:

 ```text
   x: exact constant 12
   y: arbitrary integer in r2
 ```

 The proof requirements are satisfied:

 ```text
   12 is a normalized u32.
   y meets the unrestricted integer requirement.
 ```

 But the placement is not:

 ```text
   materialize 12 into r1
   place y into r4
 ```

 Conversely, having the right registers does not compensate for a missing proof.

 This distinction prevents both unsafe specialization and unnecessary rejection of arrivals that know more than the target requires.

 ────────────────────────────────────────────────────────────────────────────────

 6. Native emission remains copy-and-patch

 The existing native signature already captures the intended shape:

 ```c
   #define JIT_ARGS                      \
       uint64_t *asp,                    \
       uint64_t *bsp,                    \
       uint64_t *csp,                    \
       uint64_t r0, uint64_t r1,          \
       uint64_t r2, uint64_t r3,          \
       uint64_t r4, uint64_t r5,          \
       uint64_t r6, uint64_t r7
 ```

 There is no bytecode instruction pointer in the running native stream.

 A stencil binds an operation to the registers it touches:

 ```c
   /* Illustrative stencil source. */
   JIT_CC uint64_t add_r3_r5(JIT_ARGS)
   {
       r3 = r3 + r5;
       MUSTTAIL return HOLE_NEXT(JIT_PASS);
   }
 ```

 Other registers remain in their fixed argument positions.

 With symmetric operands, both A and B bind the same destructive operation shape:

 ```text
   rd = writable(selected stack's value)
   rs = materialize(other stack's value)
   emit(operation, rd, rs)      // rd ← rd op rs
 ```

 The old native emitter selects reverse-operation stencil families specifically for B destinations, and contains a B-specific SUB/ZX32 fusion exception. The corrected semantics removes that semantic reason for reverse families and B-only fusion rules. Alias preservation, capture and valid normalization proofs still apply. This is a structural simplification to implement and measure, not a claim of an already achieved code-size or speed improvement.

 Native emission already consumes immutable operands, signatures and proven facts. It selects their stencil bindings directly; it neither waits for nor performs bytecode opcode quickening.

 Offline:

 ```text
   shared operation definition
             │
             ▼
   register-bound stencil C
             │
             ▼
   Clang optimization and instruction selection
             │
             ▼
   extracted machine bytes + relocation descriptions
 ```

 At runtime compilation:

 ```text
   choose stencil
   copy bytes
   patch operands and destinations
   connect control flow
 ```

 That is where the speed comes from: the expensive backend work has already happened.

 We should not promise that every stencil is one machine instruction. Simple arithmetic frequently is; division, conversions, checks, calls and error paths may not be.

 Nor should we reserve a new scratch register merely because a generic parallel-copy algorithm uses one. The allocation and conformance mechanisms should continue to use the existing cache model.

 ────────────────────────────────────────────────────────────────────────────────

 7. Value capture is part of semantics

 This is the lesson from the bug we actually fixed.

 These are different:

 ```text
   "the value that was read from home H"

   "whatever is currently stored in home H"
 ```

 Consider:

 ```text
   C0 initially refers to mutable home H, containing 42

   CGET.A 0
   PUSH.B 99
   CSET0.B
 ```

 The required result is:

 ```text
   A0 = 42
   C0 = 99
 ```

 A symbolic implementation must not leave A0 as a deferred request to reread H after H has been reused.

 Correct projection:

 ```text
   Instruction       Symbolic action                 Native work

   CGET.A 0          capture H's current value        load H → r2
                     A0 names r2

   PUSH.B 99         B0 names constant 99             none yet

   CSET0.B           C0 names constant 99             store when required
                     A0 still names r2
 ```

 If C0 already names an immutable captured register value, CGET can simply add another name for it.

 So the rule is:

 │ Rename captured values. Capture mutable storage reads before their sources can be overwritten.

 The same applies to call arguments, tail-frame replacement and returned values.

 Liveness must also extend through the consuming operation. Popping an operand from the symbolic stack does not make its register disposable before the emitted comparison or arithmetic instruction has read it.

 This is why the correct architecture is not “all stack moves disappear.” It is:

 │ Stack transport disappears when semantic value preservation permits renaming; otherwise the existing cache emits the necessary capture or transport.

 ────────────────────────────────────────────────────────────────────────────────

 8. Residualization is direct, but control flow must converge

 An illustrative compiler driver is:

 ```c
   compile_region(owner, entry_contract, sink)
   {
       state = enter_symbolically(entry_contract);

       while (there_is_pending_control_flow()) {
           select_pending_entry(&state);

           execute_shared_semantics(
               &state,
               sink,
               /* fold known work;
                  update cache names;
                  emit residual operations directly */);
       }

       finalize_links_and_publish();
   }
 ```

 The pending entries describe control flow and symbolic cache states. They are not a second instruction representation waiting for a register-allocation pass.

 Branches

 For a known condition:

 ```text
   fold condition
   follow the selected successor
 ```

 For an unknown condition:

 ```text
   emit the comparison and branch
   derive the facts valid on each successor
   compile those successors
 ```

 At a join, only facts established on every incoming path survive without an additional check.

 Loops

 Suppose a loop initially arrives with:

 ```text
   value = 0
   steps = 0
   limit = 50
   increment = 7
 ```

 A backedge provides:

 ```text
   value = 7
   steps = 1
   limit = 50
   increment = 7
 ```

 The useful widening is:

 ```text
   value = unknown
   steps = unknown
   limit = 50
   increment = 7
 ```

 Not:

 ```text
   forget everything
 ```

 The physical values of value and steps still have to reach the loop header. Forgetting their constants does not discard those values.

 For internal cyclic control flow, provisional contracts may need weakening before publication. If that invalidates already emitted private draft code, the affected draft must be regenerated through the same emitter. Published assumptions are
 never silently weakened.

 This need not impose a separate analysis-and-allocation pipeline on ordinary straight-line regions. But its compile-time cost must be measured; “direct emission” is not permission to publish code before its entry assumptions are sound.

 ────────────────────────────────────────────────────────────────────────────────

 9. Calls are transport followed by control transfer

 Keep the semantic and physical descriptions separate.

### Proposed symmetric call contract

 ```text
   CALL.X f, n:
       consume n arguments from X in the declared vector convention
       establish the continuation, recording result destination X
       transport arguments into C and transfer to f

   RET.Y k, r:
       take the ordered r-result vector from the callee's Y
       remove the complete k-cell frame
       deliver results to the destination recorded by the continuation
       continue at its return point
 ```

 Here X and Y are independent selectors belonging to two different instructions; Y is not necessarily the opposite of X. The callee reads its arguments from C and may compute on either operand stack. There is no implicit A/B execution mode and no requirement to compile two mirrored bodies of each function.

 ```text
   .function twice 1 1
       CGET.B 0
       MULI.B 2
       RET.B 1 1

   PUSH.A 21; CALL.A twice 1    // receives 42 on A
   PUSH.B 21; CALL.B twice 1    // receives 42 on B
 ```

 | Caller | Callee return | Result transport |
 | --- | --- | --- |
 | CALL.A | RET.A | callee A → caller A |
 | CALL.A | RET.B | callee B → caller A |
 | CALL.B | RET.A | callee A → caller B |
 | CALL.B | RET.B | callee B → caller B |

 Argument order and C parameter depths remain the declared vector convention: repeated CPUSH.X transfers place the first argument at C0. At entry both private operand regions are empty. At RET.Y, Y contains exactly the declared local results, the other local operand region is empty, and the complete C frame is removed. The verifier checks result kinds/order against the function signature, independently of the selected source stack. Caller operand prefixes on both stacks remain protected.

 ```text
   TCALL.X f, k, n:
       take new arguments from X
       replace the current frame
       preserve the existing continuation and its result destination
       transfer to f

   CALLI.X:
       arguments, including the environment, on X
       target on the opposite stack
       results delivered to X

   TCALLI.X:
       the same argument/target orientation
       preserve the original continuation

   FCALL.X:
       consume arguments from X
       marshal through the declared foreign ABI
       deliver results to X
 ```

 Indirect target identity and full ABI validation remain mandatory. Foreign bridges consume the selected stack directly; B forms must not route through an A-only bytecode path. A host adapter may choose a fixed boundary convention without making that stack privileged inside the machine.

 This contract changes argument gathering and result-source semantics. It does not adopt a new physical return-slot layout or C-base restoration ABI. Such implementation decisions require a coordinated audit of all producers and consumers.

 Virtual call

 ```text
   caller symbolic state
           │
           ├── capture arguments from the selected source where necessary
           ├── rename them into callee-visible C frame positions
           ├── record a virtual continuation
           ▼
   callee symbolic execution
           │
           ├── capture results from the RET-selected source where necessary
           ├── preserve result order and route to the continuation's destination
           └── resume caller symbolic execution
 ```

 When all the transport is renaming, no call protocol remains in the native stream.

 But virtualization does not authorize:

 - moving addressed storage;
 - changing what escaped pointers identify;
 - forgetting live caller values;
 - weakening stack-capacity guarantees;
 - assuming every frame exists only as register names.

 Real call

 ```text
   preserve values live across the activation
   establish the explicit ABC continuation
   conform callee arguments
   transfer to the callee entry
 ```

 Return:

 ```text
   obtain the explicit continuation
   capture the RET-selected result vector
   deliver results under the continuation's A/B destination contract
   restore the caller's required coordinates
   continue at its native resume label
 ```

 These are operations in the ABC execution model. They do not become recursive calls to a C function that executes ABC.

 A resolver helper may:

 ```text
   validate a target
   find or prepare its entry
   return transport/linkage information
 ```

 It must not:

 ```text
   recursively execute the callee
   then return its ABC results through the host stack
 ```

 Recursion

 Recursive activations use the real continuation convention. Tail recursion preserves the existing continuation and becomes a backedge or tail transfer.

 ```text
   fib:
       compute first argument
       save continuation k1
       transfer to fib

   k1:
       preserve first result
       compute second argument
       save continuation k2
       transfer to fib

   k2:
       combine results
       continue through caller's continuation
 ```

 The exact C-base restoration convention remains a separate ABI decision. This redesign should not silently adopt the experimental return-layout proposal.

 Why region ownership helps here

 Budget selection happens at a region’s entry, before that realization executes.

 We no longer need to discover halfway through a known helper that “this callee has already been inlined seven times elsewhere” and suddenly reconstruct a real call.

 That removes an artificial reason for mid-inline materialization. It does not eliminate the genuine transport obligations of real calls inside an inlined region.

 ────────────────────────────────────────────────────────────────────────────────

 10. Shared observing sites are small, authoritative state

 For CALLI, I favor the proposed shared-table design over a registry of native patch points.

 ```text
   VM/module instance
       │
       └── observing sites indexed by original PC
               │
               ├── unseen
               ├── monomorphic(validated F)
               └── final generic
 ```

 All realizations refer to that state:

 ```text
   interpreter handler ─────┐
   native region version ───┼──► same original observing site
   inlined native copy ─────┤
   future bytecode version ┘
 ```

 The logical transition procedure is:

 ```c
   ValidatedTarget observe_call(Site *site, Target actual, ABI expected)
   {
       switch (site->state) {
       case UNSEEN:
           F = validate_exact_target(actual, expected);
           /* Failure leaves the site unseen. */
           site->state = MONOMORPHIC(F);
           return F;

       case MONOMORPHIC:
           if (actual == public_identity(site->target))
               return previously_validated_target(site);

           site->state = FINAL_GENERIC;
           /* Transition happens before validation, including failure. */
           return validate_exact_target(actual, expected);

       case FINAL_GENERIC:
           return validate_exact_target(actual, expected);
       }
   }
 ```

 That is semantic pseudocode, not a prescribed C representation. CALLI.X selects the actual target from the opposite operand stack; bank selection is immutable instruction information, not observing-site state.

 **Site observation does not require opcode rewriting.** The interpreter and native realizations consult VM-local site state while the public instruction retains its meaning and encoding. Deferring bytecode quickening does not defer target validation or erase the site's lifecycle. Native region linkage is also distinct from quickening a bytecode opcode.

 For callable sites, an encoded target plus reserved markers may fit in one word. We should not assume that every possible future observation kind has the same encoding.

 Specialization still needs a guard

 An observation-controlled native path for F must establish:

 ```text
   the site still permits its F-specific entrance
   AND
   this invocation's actual target is F
 ```

 Only then can the successor use F as a proven callee.

 If the site becomes final generic, old code can remain allocated, but its obsolete observing entrance cannot keep selecting the monomorphic path.

 An invocation already past its successful guard retains its proof.

 An independently program-proven direct target is different: it can bypass observing dispatch entirely, after the required ABI validation.

 No invented concurrency requirement

 The present API does not permit concurrent use of one VM. The design therefore does not require per-location compilation locks or lock-free patching protocols for simultaneous execution.

 Code publication still needs correct relocation, executable-memory and instruction-cache handling for the target platform. That is a different obligation.

 And the extra site-table load is a cost to measure—not something to declare negligible in the spec.

 ────────────────────────────────────────────────────────────────────────────────

 11. Eager and lazy differ in scheduling, not semantics

 The execution-policy table should be stated once.

 ┌──────────────────────────┬────────────────────────────────────────┬──────────────────────────────────┐
 │ Policy                   │ What executes                          │ When residual code is produced   │
 ├──────────────────────────┼────────────────────────────────────────┼──────────────────────────────────┤
 │ Interpreted              │ Ahead-of-time generated cache handlers │ No runtime residual code         │
 ├──────────────────────────┼────────────────────────────────────────┼──────────────────────────────────┤
 │ Eager native             │ Register-addressed stencil regions     │ Before execution                 │
 ├──────────────────────────┼────────────────────────────────────────┼──────────────────────────────────┤
 │ Lazy native              │ The same kind of stencil regions       │ On first required region arrival │
 ├──────────────────────────┼────────────────────────────────────────┼──────────────────────────────────┤
 │ Lazy bytecode — proposed │ VM-private residual ABC regions        │ On first required region arrival │
 └──────────────────────────┴────────────────────────────────────────┴──────────────────────────────────┘

 Build-time ABC optimization and portable-C generation are separate uses of the symbolic semantics, not additional automatic runtime tiers.

### Bytecode quickening is deferred, not moved into another engine

 The interpreter initially executes public instructions through the existing ahead-of-time cache-state-specialized handlers. Those handlers encode register-cache occupancy and placement; they are not observed-type versions or rewritten instruction sites. Preserve that fast core rather than replacing it with a synchronized generic interpreter.

 Counts and signatures remain immutable operands/metadata. Interpreter handlers execute their declared forms without internal quickened opcode variants; native residualization can use the same information to select transport and operation stencils directly. Shared observing-site records remain independent of either mechanism.

 Removing existing quickening paths is implementation work still to do. Measure interpreter dispatch, calls, handler text size and native emission against the isolated typed baseline. Do not claim postponement is performance-neutral before those measurements. Reconsider bytecode quickening only if evidence justifies it; it is not a prerequisite for the symmetric ISA or native JIT.

 Strict eager

 Before execution:

 ```text
   prepare bounded specialized regions that load-time facts justify
   prepare general coverage for unavailable facts
   prepare callable general entries for every valid runtime target
   publish complete executable code
 ```

 During execution:

 ```text
   execute
   validate targets
   update observing-site state
   select already prepared code
 ```

 No new block or region compilation.

 If a newly observed target has no prepared specialized path, eager mode uses its prepared general execution. It does not quietly call the compiler.

 Lazy

 On an unresolved region entry:

 ```text
   preserve the incoming machine state
   derive a valid entry contract
   select an existing compatible realization,
   or compile one if the budget permits,
   or select the reserved general realization
   publish and link
   enter it
 ```

 An initial sample is not enough to authorize an unchecked reusable specialization. Subsequent arrivals must establish its requirements.

 Ordinary established edges should transfer directly. They should not search the whole version table every time.

 Guard failure is not restart

 If effects have already occurred:

 ```text
   store something
   perform a check
   check fails
 ```

 the failure path cannot jump back to a general region entry that repeats the store.

 It must take a checked alternative at the current semantic point, or a successor entry whose contract represents that point.

 This is one reason general checked branches remain part of region code even when specialized paths exist.

 ────────────────────────────────────────────────────────────────────────────────

 12. Lazy bytecode is a proposed peer target—not a hidden second interpreter

 Lazy bytecode remains future design work. It is neither implemented by the current checkpoint nor required to compensate for deferred bytecode quickening. Residualizing a private bytecode region under checked facts is distinct from replacing an instruction opcode with an internal quickened variant.

 Its useful shape is:

 ```text
   original verified ABC
            │
   shared symbolic semantics
            │
   VM-private residual ABC
            │
   existing cache-state interpreter handlers
 ```

 No executable memory is required.

 But several contracts are essential:

 - Residual instructions retain their original source provenance.
 - Observing instructions still reference the original shared site.
 - Entry guards establish the facts used by the residual bytecode.
 - Branch offsets and continuation destinations refer to the correct private code.
 - Private generated code is validated under its declared entry contract.
 - The runtime does not start invoking the existing whole-module abc-opt pipeline.

 Specialized bytecode can contain typed operations after checks:

 ```text
   check operand representations and tags
       success:
           typed operations
       failure:
           checked general computation
 ```

 Whether checks need fused EXT forms is an encoding decision. It is not necessary to settle the architecture.

 The version-accounting rule should be shared across versioning sinks. That means one definition of ownership and limits—not one physical pool mixing a build-time C artifact with code in unrelated VM instances.

 The optimizer’s speculative analysis limit remains a different concept.

 ────────────────────────────────────────────────────────────────────────────────

 13. Dynamic reintegration plugs into this core

 The future dynamic layer should contribute semantic computations, not another execution engine.

 For a dynamic binary operation:

 ```text
   X0: left dynamic value, on the selected stack
   Y0: right dynamic value, on the opposite stack
                 │
                 ▼
   shared semantic computation
       classify representations
       establish type cases
       apply conversion/promotion rules
       perform typed computation
       handle errors
       choose result representation
       perform required allocation, if any
                 │
                 ▼
   result on selected stack X
 ```

 The opcode selects X; no dynamic scalar family hard-codes A as its left operand or gathers both operands on A. Unary, boxing, cast and test forms likewise operate on their selected stack under explicit layout contracts. Dynamic call argument/result transport must follow the symmetric call contract rather than reinstate the retired A-only convention.

 The same computation supplies:

 - concrete interpreter execution;
 - symbolic folding;
 - checked residual branches;
 - typed stencil emission;
 - future residual bytecode;
 - supported C emission.

 A schematic semantic definition might read:

 ```text
   dynamic_add(left, right):
       determine the applicable numeric or other defined case
       validate that case
       obtain its typed operands
       invoke the shared typed addition semantics
       construct the required semantic result
 ```

 The concrete binding performs the operations.

 The symbolic binding:

 - removes checks already proved;
 - follows known branches;
 - emits unknown checks and their successors;
 - emits the remaining typed work;
 - retains required effects.

 There must not be one interpreter algorithm and a separately handwritten native algorithm for promotion, overflow, error ordering or boxing.

 Tag, representation and normalization remain distinct

 ```text
   tag:
       what semantic type does this value have?

   representation:
       how are its bits currently carried?

   normalization:
       which bit-level properties are established?
 ```

 A u32 tag does not automatically prove that a register is raw and zero-extended.

 A boolean tag does not automatically prove arbitrary incoming bits are 0 or 1.

 Boxing must not silently normalize a payload that the language says to preserve.

 Keeping these distinctions in the core is what lets dynamic execution recover typed speed without inventing unsafe shortcuts.

 ────────────────────────────────────────────────────────────────────────────────

 14. Memory facts are proofs, not cached memory semantics

 The right distinction is:

 │ Every emitted load loads, and every emitted store stores. Residualization may omit an access only when a valid fact proves that omission correct.

 A useful fact has a shape like:

 ```text
   at location:
       base identity + byte offset + width

   the current contents equal:
       captured value V

   valid until:
       an effect that may change or invalidate that location
 ```

 Examples:

 ┌─────────────────────────────────────────────────────────────┬─────────────────────────────────────────────────────┐
 │ Memory category                                             │ Possible optimization                               │
 ├─────────────────────────────────────────────────────────────┼─────────────────────────────────────────────────────┤
 │ Immutable, non-relocated image bytes                        │ Fold a known load                                   │
 ├─────────────────────────────────────────────────────────────┼─────────────────────────────────────────────────────┤
 │ Storage proved unobservable except through tracked accesses │ Promote tracked contents                            │
 ├─────────────────────────────────────────────────────────────┼─────────────────────────────────────────────────────┤
 │ Writable image or escaped storage                           │ Forward only while alias/effect proofs remain valid │
 ├─────────────────────────────────────────────────────────────┼─────────────────────────────────────────────────────┤
 │ Unknown pointer memory                                      │ Emit the access unless a sufficient proof exists    │
 └─────────────────────────────────────────────────────────────┴─────────────────────────────────────────────────────┘

 A constant offset alone does not make a relocated address a portable constant.

 Calls and foreign effects invalidate facts according to justified footprints. Unknown effects require conservative invalidation.

 Allocation being nonmoving does not prove it preserves every memory fact: its slow path and associated runtime effects still matter.

 Also:

 ```text
   invalidate "memory H currently contains V"
 ```

 does not mean:

 ```text
   invalidate the previously captured value V
 ```

 The old loaded value can remain perfectly valid in a register after H changes.

 That is the same value-versus-storage distinction as the capture fix.

 ────────────────────────────────────────────────────────────────────────────────

 15. Allocation, GC and foreign effects stay explicit

 These boundaries must not be inferred merely from the word “dynamic.”

 For an operation that may collect:

 ```text
   complete required captures
   publish all live roots in the supported root representation
   perform the effect
   restore or continue with a valid cache state
 ```

 Roots may reside in A, B, C and the register bank. “Store everything to C” is not a complete root contract.

 A proven raw integer need not be boxed merely so that collection can occur. A managed address must remain visible as a root.

 The exact safepoint and pending-collection policy belongs in the GC contract. Reintegrating dynamic values must not silently add polling overhead to ordinary typed instructions.

 For foreign calls:

 ```text
   shared call semantics
       + declared foreign ABI
       + existing synchronization requirements
       → argument transport, host call, result transport
 ```

 A leaf-foreign optimization could be useful later, but needs a declared effect and re-entry contract. It should not appear in the spec as though that interface already exists.

 ────────────────────────────────────────────────────────────────────────────────

 16. What the resulting code can look like

 For a counter with known limit 50 and increment 7, the useful arithmetic kernel is:

 ```asm
   top:
       cmp  value, 50
       jae  done
       add  value, 7
       add  steps, 1
       jmp  top
   done:
 ```

 That is the shape we want to approach.

 But the specification should distinguish:

 ```text
   essential arithmetic/control work
 ```

 from:

 ```text
   capture, alias-preservation, transport and edge-placement work
 ```

 Knowing limit and increment does not itself prove that the old value and steps registers can be overwritten. That follows from actual liveness and alias obligations.

 A valid emitted stream might therefore contain:

 ```text
   copy an aliased operand
   perform the arithmetic
   rename the updated binding
   restore the next entry's placement
 ```

 Those extra moves are not automatically evidence of a bad architecture. The important questions are:

 - Are they required by the current contract?
 - Can the shared cache avoid them without violating value preservation?
 - Do they affect measured throughput or latency?
 - Would eliminating them require a disproportionate new subsystem?

 The existing experiments already show why this distinction matters: a mechanically allocated stencil loop can perform very well without matching a hand-written register schedule instruction for instruction.

 ────────────────────────────────────────────────────────────────────────────────

 17. What must be tested and measured

 Architectural correctness

 Not just final answers:

 - Selected-stack-first operand order: OP.A computes A0 op B0; OP.B computes B0 op A0.
 - Both selected stacks, including noncommutative integer/float operations and the correct divisor, shift count and exponent.
 - Whole-machine A/B exchange tests over mirrored programs, operand states and continuation selectors, with corresponding effects, results and failures.
 - C reads to both destinations and C writes from both sources; C retains its structured-state role.
 - Selected-stack conversions, checks, branches, memory operations and host-entry results.
 - All four CALL.X/RET.Y source/destination combinations; indirect targets on the opposite stack and tail calls preserving the original destination.
 - Foreign argument/result transport on either stack, without an A-only staging path.
 - Destination-parametric expression lowering preserves pre-existing live values on both stacks, including nested noncommutative expressions.
 - Greater-than/greater-or-equal use reversed comparisons without changing source evaluation order; test effects, traps and floating-point NaNs.
 - Mirrored handler bindings exchange (a, b) and h[i]/h[3-i] while retaining C's role, across full-bank and spill transitions.
 - Operand orientation introduces no repair MOVE; distinguish this from legitimate capture, alias and conformance transport.
 - Pressure-driven reordering occurs only when permitted by effect, trap and resource-failure semantics.
 - Untouched live values on the other stack.
 - HOME capture before replacement.
 - Consumed operands remaining live until their operation finishes.
 - Ordered multi-result returns.
 - Escaped addresses surviving calls and conformance.
 - Guard failures not replaying effects.
 - Original trap provenance.
 - Stack-capacity behavior under the agreed policy.

 Region accounting

 ```text
   one helper called from many unrelated callers
       → no shared helper-budget cliff

   many helpers inside one caller realization
       → one slot

   many distinct caller entry contracts
       → at most seven specialized realizations

   internal loops and joins
       → converge, not free hidden version families
 ```

 Site behavior

 - Shared history across interpreted, native and inlined realizations.
 - Invalid first target leaves the site unseen.
 - Mismatch transitions before validation.
 - Final generic never restarts.
 - Later realizations see the current state.
 - VM instances remain isolated.
 - Observing-state transitions remain correct without rewriting public instruction opcodes.

 Encoding and migration

 - Enumerate the complete one-byte opcode allocation, including EXT, without reserving internal quickening variants.
 - Keep mirrored forms structurally consistent and verify their operand layouts independently of native register placement.
 - A new ISA/module revision prevents old SUB.B/CALL.B semantics from being silently reinterpreted.
 - Regenerated frontend, assembler, optimizer and C-sink output agrees with the authoritative selected-stack contracts.
 - Independent expected-value tests accompany metamorphic symmetry tests; updating a shared generator alone is not sufficient evidence.

 Compilation policy

 - Eager execution performs zero region compilation.
 - Lazy first arrival compiles only through the declared compiler path.
 - Repeated arrivals reuse published code.
 - Failed publication leaves no callable partial code.

 Performance

 Keep separate measurements for:

 ```text
   load/preparation time
   first-arrival latency
   steady-state execution
   generated code bytes
   metadata bytes
 ```

 Use the isolated typed core as the baseline. Measure source-definition reduction separately from emitted handler/stencil bytes. For parametric lowering and pressure-driven scheduling, compare bytecode size, dispatch count, spills, captures and transport as well as execution time; symmetry alone does not prove a performance improvement.

 Measure tiny helpers, recursive calls, branchy code, throughput-heavy arithmetic and memory—not only a latency-bound loop. Later, compare dynamic code with equivalent typed computations, separating proven, checked and allocating paths.

 ────────────────────────────────────────────────────────────────────────────────

 The final picture

 ```text
                          ONE ABC MACHINE
                     A/B operands, explicit C state
                                 │
                          ONE SEMANTIC CORE
                                 │
                    proven facts + symbolic cache
                                 │
                 ┌───────────────┼────────────────┐
                 ▼               ▼                ▼
            residual ABC    copied stencils    portable C
                                 │
                       caller-owned regions
                       bounded realizations
                                 │
                   explicit guards and continuations

   Operand roles:
       selected stack first; the other stack is its symmetric partner
       C reads select a destination; C writes select a source

   Call transport:
       CALL.X selects arguments and caller results
       RET.Y selects the callee's result source
       the explicit continuation connects them

   Observing-site state:
       shared by original instruction identity, without opcode rewriting

   Bytecode quickening:
       deferred; no internal opcode budget reserved

   Placement:
       owned by the existing symbolic cache

   Dynamic behavior:
       shared checked computations and explicit effects

   Execution policy:
       decides when compilation occurs, not what ABC means
 ```

 The redesign is not about making the compiler more general by adding machinery. It is about making ownership, proofs and effects precise enough that the fast existing machinery can do more work directly.

 That is the base on which dynamic operations should return.
