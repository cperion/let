# Native residualizer architecture review 
Independent grounded assessment of native residualizer quality and gaps.
**Workflow ID**: wf-da4aee3a
**Started**: 2026-10-07 10:18:17
---

## Scout Output — 2026-10-07 10:22:38

## Files Retrieved

1. `src/residualize.c` (lines 1-837) — Complete native residualizer: placement, register/home management, block versions, lazy activation, calls, indirect caches, dynamic/foreign fallbacks, and image lifecycle.
2. `src/residualize.h` (lines 1-19) — Native image observability: code size, site transitions, virtual/real-call counts, compiled-version count.
3. `src/vm.c` (lines 89-141) — VM image creation invokes `abc_residualize_module`; native site statistics are exposed through the public API.
4. `include/abc.h` (lines 1-90) — Public execution-policy and site-statistics contracts.
5. `gen/stencils.lua` (lines 55-225) — Register-addressed stencil families, dynamic fallback, indirect calls, continuations, and lazy-entry stencil.
6. `gen/semantics.lua` (lines 1-121) — Shared symbolic transfer definitions for arithmetic, stacks, branches, checks, `SWITCH`, abort, and `HALT`.
7. `tools/validate.lua` (lines 1-750) — Principal interpreted/eager/lazy differential suite, with explicit oracles and public-opcode occurrence coverage.
8. `tools/validate_api.c` (lines 1-70) — Direct native-image, lazy activation/reuse, callable resolution, foreign ABI, and forced-GC checks.
9. `tools/validate_dynamic.lua` (lines 1-554) — Three-policy profile-5 differential tests for boxing, calls, words, aggregates, managed storage, and traps.
10. `tools/validate_symbolic.c` (lines 1-140) — Unit-level shared symbolic-dispatch, folding, context, and continuation tests.
11. `frontend/tests/lowering.lua` (lines 120-347) — Cross-policy generated-module tests for arithmetic, memory, aggregates, callables, dynamic values, managed captures, and floats.
12. `frontend/tests/optimize.lua` (lines 585-749) — Optimized modules re-executed in all three policies, including recursion, path-sensitive control, dynamic operations, indirect calls, traps, checks, and `SWITCH`.
13. `frontend/tests/staging.lua` (lines 1-120) — Compile-time VM policy agreement and byte-identical staging output.
14. `frontend/tests/compiler.lua` (representative cross-policy ranges: 82-119, 161-246, 293-316, 447-574, 677-886, 977-1084) — Extensive source-level execution across interpreted/eager/lazy staging.
15. `examples/callables.abcasm` (lines 1-56) — Raw callable fixture used by API validation.
16. `examples/virtual.abcasm` (lines 1-82) — Deep acyclic direct-call chain used for eager and lazy native smoke testing.
17. `examples/foreign.abcasm` (lines 1-24) — Mixed integer/float, wide-argument, and void foreign calls.
18. `examples/dynamic_gc.abcasm` (lines 1-48) — Module and managed-interior roots under requested collection.
19. `Makefile` (lines 19-148) — Residualizer build dependency and complete `validate` target.
20. `.github/workflows/test.yml` (lines 1-13) — CI configuration.
21. `README.md` (lines 5-10, 55-92) — Public claims about policies, residualizer scope, and validation.
22. `docs/symbolic-vm.md` (lines 1-72) — Current symbolic VM, versioning, sink, and implementation-boundary description.
23. `docs/architecture.md` (lines 58-77) — Current implementation claims and acknowledged unfinished quickening/tag-token work.
24. `docs/spec.md` (lines 384-526) — Authoritative compiled-tier and versioning specification.
25. `docs/dynamic-profile.md` (lines 1-35, 64-76, 119-174) — Dynamic specialization status, layout-token contract, block-version requirements, and required tests.
26. `docs/callable-profile.md` (lines 1-51, 98-104) — Callable cache contract and claimed smoke-test coverage.
27. `research/experiments/engines/README.md` (lines 1-120) — Native quality/performance measurements and caveats.
28. `research/experiments/engines/runlet.c` (lines 1-53) — Benchmark harness exposing native code size and eager/lazy timing.
29. `.pi/workflows/wf-da4aee3a.md` (lines 1-4) — Review workflow context.

## Key Code

### Native architecture actually present

`src/residualize.c` is a real direct stencil backend, not a wrapper around residual IR:

```c
static int place(Compiler *c,unsigned id,uint64_t immediate,Version *taken) {
    ...
    memcpy(at,s->code,s->len);
    ...
}
```

Its symbolic stack cache implements spills, materialization, copy-on-write, and home conformance in `spill_reg`, `materialize_mask`, `writable`, `flush_context`, and `conform_generic` (`src/residualize.c:256-313`).

`compile_version()` configures the generated symbolic dispatcher with native callbacks rather than switching manually over opcodes (`src/residualize.c:763-787`):

```c
machine.emit_binary=native_emit_binary;
machine.emit_control=native_emit_control;
machine.emit_memory=native_emit_memory;
machine.emit_call=native_emit_call;
machine.emit_dynamic=native_emit_dynamic;
...
abc_symbolic_exit symbolic_exit=abc_symbolic_dispatch(&machine);
```

### Versioning and lazy activation

`version_for()` keys versions by symbolic context, enforces `ABC_BLOCK_VERSION_LIMIT`, allocates stable lazy entries, and queues eager versions (`src/residualize.c:537-548`). `edge()` materializes constants on backedges and generalizes near the cap (`src/residualize.c:550-557`).

`lazy_prepare()` compiles and patches a version on entry; its stable stub is rewritten to a jump, and `compiled_versions` is incremented (`src/residualize.c:571-580`).

However, all function-entry `Version` objects and lazy stubs are created during module residualization (`src/residualize.c:814-825`). Lazy execution delays body compilation, not entry-version/stub allocation.

### Dynamic specialization boundary

There is limited native specialization:

- `ANY_BOX` can become a raw dynamic representation.
- Matching `ANY_CAST` can disappear.
- Some known 32-bit binary operations become typed stencil operations.
- Known 64-bit dynamic arithmetic is folded.

Everything else flushes to generic homes and calls `vm_dynamic_native()` (`src/residualize.c:634-653`):

```c
if(!conform_generic(c,x) ||
   !place_dynamic(c,p,pc,...))
    return 0;
```

`materialize_dynamic()` only emits `ABC_STENCIL_DYNAMIC_ENCODE` for proven integer representations (`src/residualize.c:284-290`). The stencil itself masks to a 40-bit immediate payload (`gen/stencils.lua:178-179`); there is no wide-integer heap-box materialization path here. This is consistent with the dynamic profile’s explicit “compiled escape-based wide integers ... remain in progress” status, but not with the completed behavior required later in the normative text.

### Calls

- Acyclic direct calls virtualize based on recursion and local continuation-version capacity: `inline_candidate()` and `native_emit_call()` (`src/residualize.c:524-535,713-740`).
- Recursive calls use native C-stack continuation cells and canonical register return where applicable.
- Tail calls remain symbolic transfers (`native_emit_tail`, lines 742-748).
- Raw callable-profile indirect calls resolve directly and deliberately do not transition site knowledge (`native_emit_indirect`, lines 680-711).
- Dynamic-profile indirect calls have observing → specific → final-generic patching (`ic_select`, lines 190-202).

The image records `virtual_calls`, `virtual_returns`, `virtual_tails`, and `real_calls`, but no test reads those fields.

## Validated Behavior

### Strongest evidence: opcode-level three-policy differential testing

`tools/validate.lua:38-46` runs every case under:

```lua
--interpreted
--compiled
--lazy
```

It compares output and success status, usually against an independent literal oracle. Named fixtures cover:

- `arithmetic` (`lines 47-57`): every two-stack integer binary operation and both destinations with runtime inputs.
- `floats`, `float-nan`, `float-conversion-trap`, `float-load` (`58-118`): float arithmetic, comparisons, NaN ordering, conversions, traps, and loads.
- `more` (`123-141`): unary, immediate, C-operand, power, and masks.
- `context`, `cold-forms` (`143-201`): C-stack renaming, range access, copy/move/dup/drop.
- `branches`, `dynamic-branches` (`203-260`): two-stack, zero, immediate, signed, and unsigned branches.
- `switch` (`222-245`): unknown and folded `SWITCH`, including default.
- `memory` (`262-389`): frame/global/pointer/indexed loads and stores, all widths, signed loads, addresses, `MEMCPY`, `CALLOC`/`CFREE`.
- `errors` (`391-443`): division, power, checks, and explicit abort reasons with byte offsets.
- Stack guards: `overflow`, `virtual-limit`, `tail-limit`, `recursive-limit`, `indirect-limit`, and `indirect-tail-limit` (`445-485,571-635`).
- Recursion and real continuations: `mutual-recursion`, `real-b` (`486-569`).
- Local version pressure: `version-cap` (`637-669`).
- `HALT`, direct tail transfer, virtual calls, and a 65,535-byte frame (`674-726`).
- Legacy Fibonacci, partial application, and closure fixtures (`728-737`).

The script tracks decoded opcode names and ends by asserting that every public opcode occurred in some assembled fixture (`lines 739-748`). This is occurrence coverage, not exhaustive behavioral coverage for every opcode.

### Direct residualizer-policy checks

`tools/validate_api.c:34-47`, using `examples/virtual.abcasm`, verifies:

- eager mode creates a native image and computes `42`;
- lazy load leaves `compiled_versions == 0`;
- first call produces the correct result and activates at least one version;
- repeating the same call does not increase the version count.

This directly validates stable lazy activation/reuse rather than only semantic parity.

### Native ABI and runtime boundaries

`tools/validate_api.c:49-69` executes in all three modes:

- unbound foreign symbols fail at load;
- mixed integer/float foreign calls;
- ten-argument mixed ABI calls;
- void foreign calls;
- requested Whippet collection;
- module-root and managed-interior-root survival.

`tools/validate.lua` separately validates raw `CALLI.A`, `CALLI.B`, `TCALLI`, invalid targets, and stack limits. `tools/validate_dynamic.lua` exercises dynamic calls and tails through the generic runtime boundary.

### Dynamic/profile-5 breadth

Named `tools/validate_dynamic.lua` fixtures include:

- `scalar`, `loop-home`, `dynamic-i32`, `dynamic-u64`;
- `word`, `supplied-word`, `method-word`, `word-churn`;
- direct, captured, adjusted, partial, and tail dynamic calls;
- aggregates and aggregate results;
- managed storage and string keys;
- missing terminal, overapplication, result-contract failures, frozen mutation, and type mismatch;
- verifier rejection of noncanonical NaN and unmanaged-borrow boxing.

Most use the `same()` helper and therefore compare all three execution policies.

### Frontend-generated workload breadth

`frontend/tests/lowering.lua:137-347` runs generated modules under all policies and adds realistic combinations absent from hand-written opcode fixtures: aggregate layouts, borrowed slices, bounds checks, captured managed callables, generic `any` calls, strings, and float lowering.

`frontend/tests/compiler.lua` contains many more interpreted/eager/lazy staging loops for records, arrays, methods, pointers, deferred calls, recursive words, sums, closures, partial applications, open words, managed views, dynamic conversions, recursion, imports, and interfaces.

These are valuable integration tests, although many primarily validate source lowering and generic runtime behavior rather than native specialization quality.

### Shared symbolic core

`tools/validate_symbolic.c` directly checks:

- generated dispatch and constant folding;
- immediate and C-operand folding;
- known control transfer;
- dynamic fact propagation;
- direct-call and virtual-return transitions;
- backend result propagation;
- context copying/equality/family equality;
- signed/unsigned branch and integer/float edge semantics;
- `ABC_BLOCK_VERSION_LIMIT == 8`.

This supports the common semantics feeding `residualize.c`, but does not test stencil placement itself.

### Performance evidence

`research/experiments/engines/README.md` reports eager native within roughly 1.01–1.17× generated C on `skip`, `loop`, and `sum2`, and roughly native speed on `skip`. It also exposes larger gaps for multiply, divide, and recursive Fibonacci.

This is meaningful code-quality evidence, but:

- it is a manual research suite, not part of `make validate`;
- workloads are eight small scalar-integer programs;
- results are host-specific medians, not CI regression thresholds;
- no assembly/code-shape assertion enforces the claimed one-stencil/one-operation quality.

## Relationships

1. CLI/API loading reaches `vm_image()` in `src/vm.c:92-121`.
2. Eager/lazy modes invoke `abc_residualize_module()`.
3. The residualizer builds block metadata, function-entry contexts, and versions.
4. `compile_version()` drives the generated dispatcher from `gen/symbolic.lua`/`gen/semantics.lua`.
5. Native callbacks maintain symbolic register/home placement and select stencils generated by `gen/stencils.lua`.
6. Eager versions are queued and compiled during load; lazy versions retain stable stubs and compiler state.
7. CLI differential tests compare those native paths with the generated banked interpreter.
8. Dynamic operations either use limited static specialization or synchronize homes and enter `vm_dynamic_native()`.
9. Foreign operations synchronize state and use generated ABI bridges.
10. Public `abc_vm_site_stats()` delegates to `abc_native_site_stats()` for native images.

## Specified but Unimplemented or Weakly Tested

### Explicitly unfinished in documentation

`docs/dynamic-profile.md:3` and `docs/architecture.md:58,77` acknowledge these remain in progress:

- constant-key/layout-token caches;
- same-length dynamic quickening;
- escape-based compiled wide-integer lowering;
- lazy tag/layout-token propagation;
- quickening/cache/lazy-fact validation.

That status accurately describes `src/residualize.c`: it has no layout-token cache or token guard, no generic-operation site state, and no runtime-tag-derived lazy version selection.

### Lazy tag/token block versions are absent

Normative claims in `docs/spec.md:448-492` and `docs/dynamic-profile.md:119-127` say first-arrival contexts can include observed tags and checked layout tokens, with guard failure selecting another capped version.

Actual lazy stubs carry a prebuilt `Version *`; `lazy_dispatch()` only chooses between compiling that existing version and jumping to its body (`src/residualize.c:571-580`). It does not inspect runtime cells, tags, or tokens to choose/create a contextual version. Generic dynamic operations return unknown facts after `conform_generic()`.

Existing tests validate timing and reuse only. No test creates multiple lazy versions from distinct runtime tags or tokens, exercises guard failure, or checks local cap behavior for such facts.

### Wide dynamic escape materialization is incomplete

The specification requires a proven wide integer to stay raw until escape, then materialize a canonical box. Native code only has immediate encoding in `materialize_dynamic()`, and the generated encoding stencil masks to 40 bits. Tests cover constant wide values that are cast back to typed values before an observable dynamic escape; they do not:

- send an unknown wide integer around a loop;
- store an out-of-immediate-range raw result into an `any` home/object;
- instrument allocation count;
- prove no per-iteration box before escape;
- prove correct canonical boxing at escape.

### Dynamic operation matrix is sparse

The required tests call for every generic operation against typed equivalents over every valid and invalid tag combination (`docs/dynamic-profile.md:163-174`). Current direct dynamic tests concentrate on addition, boxing/casting, words, and calls. Frontend tests add conversions and realistic cases, but there is no systematic operation × tag matrix.

### Site specialization is poorly observed

`abc_native_image` exposes site transitions and call counters, but tests do not inspect:

- dynamic-profile observing → specific → final-generic transitions;
- patch sharing across block versions;
- a newly compiled lazy version inheriting current site phase;
- virtual versus real call counts;
- virtual-tail or canonical-register-return counts.

For raw callable profile, `tools/validate_api.c:23-32` specifically expects all transition counters to remain zero. That validates the new direct-resolver design, not the older callable-profile cache contract.

### Version-cap testing is semantic, not structural

`version-cap` proves results under branch pressure, and `validate_symbolic` fixes the cap at eight. There is no assertion of:

- exact version count;
- which edge generalized;
- “most specific compatible” selection;
- preservation of register-resident nonconstant values at generalization;
- lazy context-family behavior across repeated runtime calls.

### Native code shape is effectively untested

No committed validation disassembles current native output or asserts:

- constants/renames emit no machine code;
- `ZX32` fusion occurred;
- an acyclic call was actually virtualized;
- a recursive call used the intended continuation path;
- stencil relocations are correct for every hole/kind combination;
- stack-cache spills/copy-on-write are minimal.

The counters needed for some of these assertions exist but are unused.

### Error-path and resource testing gaps

Weak or absent coverage includes:

- executable mapping exhaustion;
- relocation-range failure;
- allocation failures in version/context/fixup growth;
- lazy compilation failure after first entry;
- `mprotect` failure and recovery;
- repeated lazy compilation after an activation error;
- very large modules approaching the mapping cap.

### GC/safepoint requirements are only partially tested

Forced collection validates roots, but there is no direct native test for:

- pending collection across a verified allocation-free loop;
- collection immediately at the next eligible generic/allocating boundary;
- root visibility for every dynamic allocating instruction;
- allocation instrumentation promised by the dynamic profile.

## Documentation–Code/Test Discrepancies

1. **Lazy tag/token specialization is described as implemented behavior in `spec.md`, but is marked “in progress” elsewhere and is absent from `residualize.c`.** The current lazy implementation compiles predeclared symbolic contexts; it does not derive new contexts from observed runtime tags or tokens.

2. **“All reachable functions” versus actual eager setup.** `abc_residualize_module()` creates an entry version for every module function (`src/residualize.c:814-825`), not a root-reachability-selected subset. It then compiles the resulting queue. Dead functions are therefore prepared too.

3. **Callable-profile documentation is stale.**
   - `docs/callable-profile.md:35-36` says `SWITCH` is not implemented; `native_emit_control()` handles it, and named `switch` tests exercise compiled and lazy execution.
   - `docs/callable-profile.md:39-51` specifies observing/specific/final caching for callable-profile sites. Current native raw callable-profile paths intentionally use `place_raw_indirect()` without transitions, consistent instead with `docs/symbolic-vm.md`.
   - Its line 104 claims tests for transitions and a 100,000-iteration indirect tail loop. No such loop exists in the current repository, and API tests assert zero native transitions.

4. **`MEMCPY` code-quality claim does not match stencil implementation.** `docs/spec.md:193` says copies up to 32 bytes become a few inline moves and larger copies call `memcpy`. `gen/stencils.lua:174-175` emits a byte-at-a-time loop for every constant size. The only direct test copies eight bytes and checks correctness, not instruction selection.

5. **Dynamic representation ownership is blurred.** `docs/dynamic-profile.md:33` says generated helpers centralize tag arithmetic. `gen/stencils.lua:178-179` hardcodes the `any` immediate tag layout in `dynamic_encode`, rather than calling a shared helper.

6. **Validation prose is more candid than the main specification.** `docs/architecture.md:77` explicitly says quickening, cache, and lazy-fact suites remain in progress. That caveat should qualify stronger statements in `README.md` and `spec.md` about complete eager/lazy dynamic behavior.

7. **CI does not invoke the repository’s actual validation target.** `.github/workflows/test.yml:9-10` runs `make ... test`, but `Makefile` defines `validate`, not `test`. Running `make -n test` produced:

```text
make: *** No rule to make target 'test'.  Stop.
```

Thus the rich local validation suite is currently not wired to the checked-in CI workflow.

## Observations

- Semantic breadth is strong: core arithmetic, floats, memory, calls, foreign ABI, profile-5 generic behavior, GC roots, recursion, stack limits, and every public opcode occur in cross-policy tests.
- The tests have useful literal oracles, not only interpreter equivalence, especially in `tools/validate.lua`.
- Architectural/native-quality evidence is much thinner than semantic evidence. Most tests establish “same answer in three modes,” not that the native residualizer performs the advertised specialization or placement.
- The most important unfinished areas are already acknowledged in profile-status prose: runtime tag/token contexts, dynamic quickening caches, and wide-integer escape materialization.
- The manual benchmark suggests excellent scalar-loop code quality, but it is not a regression gate and reveals material gaps for multiplication, division, and recursion.
- The broken CI target significantly reduces confidence that any of this evidence is continuously enforced.

## Reviewer Output — 2026-10-07 11:26:00

## Files Reviewed
- `src/residualize.c` (lines 1-846)
- `src/symbolic.c` (lines 1-663)
- `src/symbolic.h` (lines 1-169)

## Strengths
- `src/symbolic.h:60-146`, `src/residualize.c:763-785` - The callback-based symbolic machine cleanly centralizes opcode semantics while allowing the native sink to retain target-specific register placement. `compile_version()` is notably free of a duplicate opcode switch.
- `src/symbolic.c:473-516` - Virtual calls and returns enforce explicit A/B/C shape invariants, restore C-frame origin/bias, and model continuations without host-language recursion.
- `src/residualize.c:256-313` - Register aliases, copy-on-write handling, spilling, dynamic representation materialization, and generic conformance form a compact and generally coherent stack cache.
- `src/residualize.c:524-556` - Recursive callees are excluded from natural inlining, continuation variants are bounded, backedges shed constants, and the final version is generalized. These mechanisms give finite local specialization.
- `src/residualize.c:173-218`, `src/residualize.c:667-710` - Indirect calls receive strong runtime validation: accepted target forms are constrained, signatures and `HALT` are checked, and stack capacity is verified. Both raw callable resolution and adaptive inline-cache paths are present.
- `src/residualize.c:166-171`, `src/residualize.c:571-578` - Generated code follows a W^X transition rather than remaining permanently writable and executable.

## Critical (must fix)
- `src/residualize.c:550-556`, `src/residualize.c:583-618` - Edge preparation can corrupt unknown branch operands and successor register state. `native_emit_control()` materializes popped predicates into registers that are no longer represented in `Context`, then calls `edge()` before emitting the branch. On a backedge or version-limit generalization, `edge()` emits materialization/conformance code whose allocator sees those predicate registers as free and may overwrite them. More generally, preparation for both successors is emitted unconditionally while each target context models only its own preparation. Unknown loop branches or switches with live constants can therefore branch on a clobbered value or enter a target with incompatible registers. Predicate registers must be reserved, and path-specific conformance should execute in edge trampolines or be reduced to one common pre-branch state.
- `src/residualize.c:815-822` - `entries = calloc(...)` is never checked before `entries[f] = v`. An allocation failure causes a null dereference instead of returning `ABC_NOMEM`.
- `src/residualize.c:804` - `m->code_size * 4096` is evaluated with 32-bit unsigned arithmetic before assignment to `size_t`. Valid modules larger than roughly 1 MiB can wrap the requested mapping size; an exact 1 MiB code section can effectively request only the extra page. `reserve()` prevents an overwrite, but valid compiled modules can fail unpredictably with an undersized arena. Cast before multiplication and check overflow before applying the cap.
- `src/residualize.c:572`, `src/residualize.c:779` - Lazy compilation uses an uninitialized local `abc_error` when the public call supplies no error object. Failure paths inspect `error->status`, producing undefined or arbitrary status results. Eager compilation also overwrites an already meaningful `c->status` with `ABC_NOMEM` whenever `c->error == NULL`. Initialize the local error and preserve compiler status independently of diagnostic storage.

## Warnings (should fix)
- `src/symbolic.c:118-119`, `src/symbolic.c:395-516` - `machine_fail()` reports every structural failure as `ABC_NOMEM`, including stack-shape mismatches, invalid dynamic contracts, and underflows. These indicate invalid bytecode or violated sink invariants, not allocation failure. This obscures regressions in the shared machinery.
- `src/residualize.c:524-556`, `src/residualize.c:804-806` - Termination is locally bounded but not globally budgeted. Acyclic natural inlining can duplicate large callees across up to eight continuation shapes, and each context family can independently consume eight versions. The only global stop is exhaustion of a large fixed mapping, which rejects the module rather than degrading to real calls or generic blocks.
- `src/residualize.c:634-653`, `src/symbolic.c:564-571` - The shared dynamic contract supports conversion of a dynamic call to a direct call through `effect.direct`, but the native dynamic sink never sets it. Consequently `EXT_DCALL`/`EXT_DTCALL` always reach `vm_dynamic_native()` unless another scalar specialization applies. This is a concrete optimization gap compared with the robust native indirect-call machinery.
- `src/residualize.c:166-171`, `src/residualize.c:571-578` - Lazy compilation and inline-cache rewriting mutate the entire executable mapping and shared compiler/site state without synchronization. This is acceptable only if VM/image execution is explicitly single-threaded; otherwise concurrent calls can race with `mprotect`, patching, version creation, and statistics.
- `src/residualize.c:575` - Every lazy activation rescans and repatches all historical fixups. This makes incremental compilation potentially quadratic in the number of reached edges.

## Suggestions (consider)
- `src/residualize.c:75-77`, `src/symbolic.c:80-83` - Add checked doubling and multiplication to generic growth helpers. Current practical verifier limits reduce exposure, but the helpers themselves are not overflow-safe.
- `src/residualize.c:1-846`, `src/symbolic.c:1-663` - Break up densely packed one-line functions, especially call/dynamic transitions and initialization/cleanup. Named helpers for frame layout, capacity arithmetic, and status propagation would make the invariants substantially easier to audit.
- `src/symbolic.c:459-580` - Document sink postconditions for `direct`, `virtualize`, `residualize`, and result arrays. The shared machine trusts callbacks to set these fields only for compatible instruction contracts.

## Summary
The architecture is strong: shared symbolic semantics, explicit virtual continuations, bounded block specialization, and a direct register-addressed stencil sink are well chosen and avoid a redundant native IR. However, the pre-branch edge-emission problem is a real miscompilation risk, and the allocation, arena-sizing, and null-error defects make the current implementation insufficiently robust. Overall verdict: promising and sophisticated, but not production-safe until the critical control-edge and failure-path issues are resolved.
