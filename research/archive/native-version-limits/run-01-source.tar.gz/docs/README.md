# Design documents

- **`syntax.md`:** the unified Let language contract for SLet `.slet` files and progressively typed Let `.let` files.
- **`spec.md`:** machine contracts and stable decisions, with implemented behavior separated from architectural targets and known conformance gaps.
- **`symmetric-isa.md`:** authoritative revision-6 selected-stack semantics and instruction encoding.
- **`architecture.md`:** current repository responsibilities, execution/tooling boundaries and remaining architectural gaps.
- **`module-format.md`:** implemented revision-6 profiles 1–4 and verifier/ownership constraints; no old-format compatibility.
- **`memory-profile.md`:** selected frame/image/pointer operations and native-pointer obligations.
- **`callable-profile.md`:** checked indirect ABI, immutable signatures, shared observations and source-support limits; no bytecode rewriting.
- **`foreign-profile.md`:** typed externs, VM-local binding, C-ABI bridges and selected `FCALL.X`.
- **`dynamic-profile.md`:** future managed/profile-5 design obligations, not active executable support. Earlier quickening proposals are superseded by the revision-6 decision.
- **`slet-subset.md`:** the production Let/SLet frontend's supported source paths and deliberate limits.
- **`frontend-completion-plan.md`:** active specification-driven frontend backlog, audit probes, dependencies, detailed acceptance tests and performance gates.
- **`remaining-work.md`:** concise restart index into the active frontend completion plan.
- **`frontend-gap-analysis.md`:** implementation audit of the reused ASDL frontend, required compilation boundaries, completed foundation, and detailed source roadmap.
- **`compiler-continuations.md`:** continuation-directed production lowering, local `CALL`/`TCALL` selection, defunctionalization, recursion as cyclic control flow, and the restricted tail-call-modulo-accumulation optimization.
- **`symbolic-vm.md`:** generated musttail abstract ABC execution shared by the native, canonical-ABC, and portable-C peer sinks.
- **`abc-opt.md`:** the standalone C ABC-to-ABC symbolic optimizer, canonical stack re-projection, frontend-fact contract, provenance, fixpoint and differential guarantees.
- **`four_lane_fork_v3.md`:** the four-lane stack-register design, an alternative that was compiled, measured and not adopted. The pre-alignment specification archive preserves the historical comparison.
